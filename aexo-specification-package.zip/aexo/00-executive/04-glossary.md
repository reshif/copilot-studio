# 04 — Glossary

Terms are capitalised throughout the specification when used in their AEXO-specific sense.

| Term | Definition |
|---|---|
| **Action** | The smallest recorded unit of agent activity: one tool call, one shell command, one file mutation. |
| **Actor** | Whoever performed an Action: a named agent, a subagent, a human, a CI job, a daemon. |
| **Agent** | One reasoning entity within a Run. Has its own context lifetime and its own Knowledge State. |
| **Anatomy** | The structural view of a repository: files, symbols, ranges, hashes. Derived, never authoritative. |
| **Bitemporal** | Storing two time axes: *valid time* (when a fact was true of the world) and *transaction time* (when AEXO learned it). Enables "what did we believe on date X". |
| **Cache-hostile** | A context modification that changes a prefix already cached by the provider, forcing a re-write at premium rate. |
| **Claim** | A proposition AEXO holds about the system under development, with a scope, a confidence, supporting Evidence, and a status. |
| **Confidence** | A bounded score on a Claim derived deterministically from evidence count, independence, recency of verification and contradiction pressure. Never assigned freehand by a model. |
| **Context Epoch** | The span of an Agent's context between resets. A compaction or clear ends one epoch and begins the next. |
| **Contradiction** | A detected relationship where two Claims cannot both be true within an overlapping Scope. |
| **Delta Injection** | Supplying only what changed in an artefact since the Agent last saw it, rather than the artefact or a denial. |
| **Directive** | A statement that is permitted to shape agent behaviour as an instruction. Requires trusted provenance. |
| **Dispute** | An Agent-initiated challenge to an injected Claim, carrying counter-evidence. Routes to the contradiction pipeline. |
| **Episode** | A bounded, coherent stretch of work: an attempt at a goal, with a beginning, an outcome, and constituent Actions. |
| **Evidence** | A durable, addressable artefact that supports or contradicts a Claim: a failing test, a commit, a stack trace, a tool output, a human statement. |
| **Evidence Graph** | The typed, directed graph linking Claims to Evidence to Episodes to Events, including support, contradiction, derivation and supersession edges. |
| **Evidence Receipt** | The manifest returned alongside injected context listing every Claim ID it contains. |
| **ESK** | Evidence Sufficiency per Kilotoken. The north-star metric. |
| **Fail loud** | Emitting a visible health signal on internal failure, while still failing open behaviourally. |
| **Gate** | The deterministic pre-action check that warns (or, in strict mode, requires acknowledgement) before a risky Action. |
| **Knowledge State** | AEXO's model of what evidence has been *delivered* to a specific Agent in a specific Context Epoch. Deliberately not a model of cognition. |
| **Mission** | A unit of intent spanning potentially many Runs and Agents: "ship the OAuth migration". |
| **Net Savings** | Tokens avoided, valued at their true rate, minus cache invalidation cost, minus the cost of the injected context that produced the avoidance. |
| **Observability Completeness** | The measured fraction of real repository/system activity that appears in the Event log. An SLO. |
| **Policy** | A Directive with organisational force: reviewed, owned, and enforceable by the Gate. |
| **Projection** | Any derived view built by folding the Event log. Includes the Experience Model, indexes and context bundles. |
| **Projection Engine** | The component that assembles a query-aware, budget-bounded context bundle for a specific Agent and intent. |
| **Provenance Depth** | The number of derivation hops between a Claim and its nearest non-model-derived Evidence. Bounded by policy. |
| **Run** | One execution of a harness against a Mission. Contains one or more Agents. |
| **Scope** | The bounded applicability of a Claim: component, path glob, environment, language, dependency version range, architecture generation, and validity interval. |
| **Supersession** | An explicit relationship where a newer Claim or Decision replaces an older one within a Scope. |
| **Taint** | A propagating label marking content whose origin is untrusted. Tainted content may be quoted as Evidence, never rendered as a Directive. |
| **Trust Lattice** | The partial order over provenance sources determining what a piece of content may become. |
| **Verifier** | An executable check attached to a Claim which, when it passes, refreshes the Claim's validity, and when it fails, opens a contradiction. |
