# 01 — Problem Statement

## 1.1 The observed failure modes

These are the behaviours AEXO exists to eliminate. Each is documented in the empirical
literature on agentic software engineering, and each is independently reproducible in any team
running coding agents at volume.

**F1 — Context re-derivation.** Every new session begins by re-reading the same orientation
files. Independent estimates put the cost of re-establishing project context at roughly five
to twenty thousand tokens per session, before any productive work begins.

**F2 — Repeated failed fixes.** The most expensive failure. An agent attempts a fix that a
previous session already tried and abandoned. Studies of failed agentic pull requests report
exactly this pattern: the same remedy applied repeatedly without evolution or test-driven
disconfirmation.

**F3 — Cascading root-cause propagation.** A single early misunderstanding propagates through
every subsequent decision in a run. Agents can attribute and recover from this — but only
retrospectively, after the run has already failed.

**F4 — Convention amnesia.** Project-specific conventions, architectural decisions and
"we deliberately do it the weird way here" knowledge are re-litigated every session.

**F5 — Compaction loss.** When a context window compacts, some facts survive into the summary
and some do not. Neither the agent nor the harness knows which. Downstream steps trust the
summary and cannot recover what it dropped — a summary that loses a critical fact is worse
than no summary, because it is confidently incomplete.

**F6 — Cross-agent blindness.** A subagent discovers something; the parent never learns it. A
reviewer agent flags a pattern; the implementer agent repeats it next week.

**F7 — Stale guidance.** A rule that was true under last quarter's architecture is still being
injected into context. Nobody notices, because nothing in the system is responsible for
noticing.

**F8 — Belief hardening.** An agent's speculative conclusion is written to a memory file, is
injected into the next session as a fact, shapes that session's behaviour, and the resulting
behaviour is then recorded as evidence for the original conclusion. Confidence rises; grounding
does not.

## 1.2 Why first-generation memory layers do not fix this

The OpenWolf review that motivated this project identified seventeen gaps. They collapse into
five structural causes, and every current tool in the category exhibits at least three of them.

**C1 — Partial observability.** Capture is bound to a specific harness's tool names. Shell
commands, ripgrep, compilers, language servers, MCP filesystem tools, CI runs and other agents
are invisible. Capability makes this worse, not better: a more capable agent uses *more* tools,
so the fraction of activity the memory layer sees monotonically declines as models improve.

**C2 — Silent degradation.** Failing open is correct — a memory layer must never block the
agent. Failing open *silently* is not, because the operator's mental model of "memory is on"
survives long after memory has actually stopped recording. False confidence in a control
system is worse than a known absence of one.

**C3 — Untyped memory.** Observation, experience, knowledge, decision, policy, instruction and
preference all get flattened into the same Markdown. They have completely different lifecycles:
an observation is permanently true about the past; a policy must be revisited whenever the
architecture changes. Storing them in one bucket makes correct expiry impossible.

**C4 — No provenance.** "Why does the system believe this?" cannot be answered. Without an
evidence graph there is no basis for confidence, no basis for expiry, no basis for
contradiction resolution, and no basis for audit.

**C5 — Wrong objective function.** Measuring tokens avoided rather than outcomes improved.
Compounded by measuring *gross* rather than *net* savings, and by ignoring that the model
provider's prompt cache already solves a large part of the re-read problem more cheaply than
any external layer can.

## 1.3 The economic reframing

A memory layer's value used to be obvious: context windows were small and expensive, so not
re-sending things was pure profit. Three changes have moved the goalposts.

1. **Prompt caching.** Cached reads bill at roughly a tenth of standard input on current
   frontier models across providers, and on Anthropic's API cached reads are excluded from
   input-token-per-minute rate limits. Cache *writes* carry a premium (roughly 1.25× base input
   for the short TTL, 2× for the extended one), so the cost model is now non-linear in a way
   naive de-duplication does not model.
2. **Cache TTL volatility.** The default cache lifetime is short and has changed without notice
   before; teams observed cost swings on the order of 20–30% from a TTL default change alone.
   A memory layer that assumes stable cache behaviour is building on sand.
3. **Provider-side context management.** Compaction, context editing, and memory tools are now
   platform primitives. Vendor-reported evaluations attribute substantial performance lift to
   context editing alone, more when paired with a memory tool, and very large token reductions
   on long-horizon runs. An external layer that duplicates these primitives adds cost without
   adding capability.

The conclusion is not that memory layers are obsolete — it is the opposite. It means the
remaining value has moved *up the stack*, from **"don't resend bytes"** to **"supply exactly the
evidence this reasoning step needs, and nothing else."** Bytes are now cheap. Wrong bytes, and
missing bytes, are expensive.

## 1.4 The security reframing

Persistent agent memory introduces a threat class that session-scoped defences do not cover.
The distinction is now formalised: prompt injection is bounded by the conversation; memory and
context poisoning survives session restarts, context resets and model upgrades, and is retrieved
later as the agent's *own prior experience* — which gives it more influence over reasoning than
an external input would have. It appears in the 2026 OWASP Agentic AI Top 10 as its own
category (ASI06) precisely because the controls differ.

Two properties make this acute for a system like AEXO:

- **Temporal decoupling.** Content written today can fire months later, triggered by an unrelated
  query. Incident scoping becomes nearly impossible without provenance.
- **Detection difficulty.** Poisoned entries look benign in isolation; published results show
  LLM-based detectors missing a large majority of them when examined entry-by-entry, with
  reported attack success rates against production-shaped agent memory in the 80–99% range.

Any system that writes model output to durable, later-injected storage **is** a memory-poisoning
surface. AEXO's response is architectural rather than detective: a trust lattice that makes
untrusted content structurally incapable of becoming a directive, plus provenance-depth limits
that prevent self-derived belief from compounding. Detection is a second line, not the first.

## 1.5 Success definition

AEXO is successful if, on a fixed corpus of repositories and tasks, an agent operating with
AEXO:

- attempts previously-failed remedies measurably less often (primary),
- resolves tasks in fewer turns and fewer tool calls (secondary),
- consumes fewer *net* tokens after cache-invalidation accounting (secondary),
- and never acts on a claim that the system could have known was stale, contradicted, or
  derived from untrusted input (constraint, not tradeable).

It is *not* successful if it saves tokens and loses on the first bullet. That trade is
explicitly rejected in `00-executive/03-scope-and-non-goals.md`.
