# 02 — Thesis, North Star and Design Principles

## 2.1 The thesis

> **Never make an agent rediscover experience the system can already prove; never inject an old
> conclusion without its scope, its provenance, and its current validity.**

Both halves are load-bearing. The first half is the value. The second half is the safety
constraint that lets the value compound instead of decay.

## 2.2 The north-star metric

**Evidence Sufficiency per Kilotoken (ESK).**

For a given reasoning step, ESK measures: of the facts the agent needed to act correctly, what
fraction were present in context, divided by the context cost in thousands of tokens.

```
ESK = (needed_facts_present / needed_facts_total) / (context_tokens / 1000)
```

`needed_facts_total` is established by post-hoc annotation of the trace against the correct
resolution — expensive, so it is measured on the evaluation corpus, not in production. Its
production proxies are defined in `04-delivery/44-evaluation-and-benchmarks.md`.

ESK is deliberately a ratio, so that neither "stuff everything in" nor "starve the agent"
scores well. It replaces "tokens saved" as the number the team steers by.

## 2.3 The transformation

| From (OpenWolf generation) | To (AEXO) |
|---|---|
| `READ MEMORY` | `OBSERVE → CAPTURE → EVIDENCE → EPISODE → CANONICAL EXPERIENCE → VERIFY/SUPERSEDE/CONTRADICT → PROJECT → AGENT` |
| Recency-bounded digest | Relevance-bounded projection |
| Mutable Markdown as both record and state | Immutable event log; Markdown as a rendered view |
| Suppress duplicate reads | Supply the delta since last seen |
| Gross tokens saved | Net tokens saved, cache-adjusted |
| Silent fail-open | Fail open operationally, fail loud observably |
| Permanent rules | Scoped claims with verifiers and validity intervals |
| Session → reads | Project → Mission → Run → Agent → Context Epoch → Action |
| One harness | Any harness, plus telemetry-based capture |
| Trust everything in the repo | Trust lattice: evidence never becomes directive |

## 2.4 Design principles

These are the tie-breakers. When two designs are otherwise equal, the one that better satisfies
the higher-numbered principle wins.

**P1 — The event log is the only source of truth.** Everything else — indexes, summaries,
claims, digests — is a derived projection that can be dropped and rebuilt. If a piece of state
cannot be reconstructed by replaying the log, it is a bug.

**P2 — Never consolidate the source; consolidate views.** Compression that destroys the original
makes "absent" and "discarded" indistinguishable, permanently. Summaries are cheap and
disposable; events are not.

**P3 — Deterministic core, LLM at the edges.** Any path that produces an authoritative answer
must be a pure function of stored data. Language models may propose, classify, rank, and
summarise. They may never be the last step before something becomes a governing rule.

**P4 — Nothing enters context without provenance.** Every injected assertion carries a claim ID
resolvable to its evidence. If it cannot be attributed, it is not injected.

**P5 — Evidence and directives are different kinds.** Repository content, dependency
documentation, third-party code and prior model output are evidence. Only human-approved or
machine-verified artefacts are directives. There is no promotion path that does not pass through
verification or a human.

**P6 — Fail open operationally, fail loud observably.** AEXO must never block or slow the agent
because of its own internal failure. It must also never allow an operator to believe it is
working when it is not. Health is a first-class, injected signal.

**P7 — Measure outcomes, not proxies.** Any metric that can improve while the agent gets worse
is a reporting metric, not a steering metric. Steering metrics must be outcome-anchored.

**P8 — Cache-aware by construction.** Context assembly is ordered by volatility so that stable
content forms a stable prefix. Every saving is reported net of the cache cost it caused.

**P9 — Harness-agnostic by interface, not by adapter count.** Prefer ingesting standard
telemetry (OpenTelemetry GenAI spans) and standard protocols (MCP) over writing a bespoke
adapter per tool. Adapters exist for coverage gaps, not as the primary strategy.

**P10 — Local-first, server-optional.** The full value must be available offline on one machine
with no network egress. Enterprise features are additive, never load-bearing.

**P11 — Claims expire by verification, not by calendar.** A date-based TTL is a guess. A claim
that carries an executable verifier can be re-checked, and its confidence can move on evidence.

**P12 — Human authority is explicit and recorded.** Every promotion, override, suppression and
deletion has a named actor and a recorded reason. "The system decided" is never an acceptable
provenance value for a directive.

## 2.5 The anti-goals that follow from the principles

- AEXO does not build a semantic code database. Program structure belongs to tree-sitter, SCIP,
  LSP, CodeQL and git. AEXO owns *experience* and joins against structure.
- AEXO does not replace the model provider's compaction or memory primitives. It supplies them
  with better inputs and records what they discarded.
- AEXO does not attempt to model the agent's cognition. It models **delivered evidence** — what
  the system put in front of the agent — because that is observable and the other is not.
- AEXO does not silently rewrite its own rules. Every rule change is a reviewable diff.

## 2.6 The two-sentence pitch to a sceptical engineer

"You already know your agents repeat mistakes and re-read the same files. What you can't do
today is prove it, explain why the agent believed something, or tell whether a rule you wrote
in March is still true. AEXO is an append-only record of what your agents actually did, a typed
model of what that taught you, and a retrieval layer that gives the next agent exactly the
evidence it needs with a citation attached — and it can show you, on a fixed corpus, how many
repeat failures it prevented."
