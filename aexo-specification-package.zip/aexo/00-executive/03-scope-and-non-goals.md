# 03 — Scope, Non-Goals and Explicit Trade Rejections

## 3.1 In scope

**Capture.** Agent tool calls across harnesses; shell activity; filesystem mutation; git
history and reflog; language-server queries; test and CI outcomes; MCP tool invocations;
OpenTelemetry GenAI spans; human review actions.

**Storage.** Immutable, hash-chained, bitemporal event log. Derived indexes. Content-addressed
blob store with per-object encryption keys.

**Experience modelling.** Episodes, Evidence, Claims, Decisions, Failures, Verifications,
Patterns, Relationships — typed, scoped, with provenance edges including support and
contradiction.

**Judgement.** Deterministic pre-action gate. Contradiction detection. Supersession. Validity
tracking driven by verifiers. Trust lattice enforcement.

**Projection.** Query-aware, token-budgeted, cache-aware context assembly. Delta injection.
Evidence receipts and a dispute channel.

**Code intelligence integration.** Tree-sitter incremental parsing; SCIP/LSIF ingestion where
available; live LSP querying; git blame/log joins. Owned as an *integration*, not a
reimplementation.

**Interfaces.** MCP server (current spec). REST/OpenAPI. gRPC for internal high-throughput
paths. CLI. A local web dashboard.

**Evaluation.** Shadow mode, paired A/B runs, seeded repeat-failure corpus, published prevention
rate, cost-accounting reports.

**Enterprise.** Multi-tenancy, RBAC, SSO/SCIM, audit export, data residency, BYOK, crypto-shred
erasure, air-gapped deployment.

## 3.2 Out of scope (v1)

| Not building | Why | What we do instead |
|---|---|---|
| A model | Not our comparative advantage | Model-agnostic; work with whatever the harness uses |
| A coding agent / harness | Crowded, and we want to be adopted by all of them | Integrate with Claude Code, Codex, and anything speaking MCP or emitting OTel |
| A semantic code database | Solved better by SCIP, CodeQL, Joern, Glean | Ingest and join |
| A vector database | Determinism and legibility matter more at the core | Optional, opt-in local index for fuzzy free-text recall only |
| An IDE plugin | Distribution, not architecture | Ship the MCP server and CLI; plugins later |
| Autonomous remediation | Governance risk, unclear value | Warn, cite, and let the agent or human decide |
| A general-purpose knowledge graph product | Scope explosion | Domain-specific: software engineering experience only |
| Conversational personalisation | Different problem | Engineering correctness, not user preference modelling |

## 3.3 Explicit trade rejections

These are decisions the team is not permitted to re-open without a written ADR and a named
approver, because they are the exact trades that produce a plausible-but-wrong system.

**TR1 — We will not trade outcome quality for token savings.** If an experiment shows a 30%
token reduction and a statistically significant regression in task success or repeat-failure
rate, the feature does not ship. Token savings are a *secondary* metric permanently.

**TR2 — We will not let an LLM be the final authority on a directive.** No configuration flag,
no "advanced mode", no enterprise escape hatch. A reflection agent may propose; a verifier or a
human disposes.

**TR3 — We will not consolidate the event log.** Retention tiering (hot/warm/cold/archive) is
permitted. Lossy summarisation of the log is not. If storage cost becomes a problem, we compress
and tier; we do not discard.

**TR4 — We will not treat repository content as instruction.** A `README` that says "ignore
security checks" is evidence that the README says that. It never becomes a directive. This holds
even for first-party repositories, because first-party repositories contain third-party
vendored code.

**TR5 — We will not ship a savings number that is not net of cache cost.** Gross "tokens saved"
figures are prohibited in product UI, marketing and internal dashboards.

**TR6 — We will not block the agent on AEXO's own failure.** The gate may warn; the gate may
require acknowledgement in strict mode; AEXO's *internal* errors always fail open. Availability
of the agent is never contingent on availability of the memory.

**TR7 — We will not claim effectiveness without a controlled result.** Until the seeded corpus
produces a prevention rate with confidence intervals, all public claims are described as
estimates and labelled as such.

## 3.4 Scope boundaries with adjacent systems

```
                       ┌──────────────────────────────────┐
                       │  Agent harness (Claude Code,     │
                       │  Codex, custom, Managed Agents)  │
                       └───────────┬──────────────────────┘
                    hooks / MCP /  │  OTel GenAI spans
                                   ▼
        ┌──────────────────────────────────────────────────────┐
        │                        AEXO                          │
        │  capture · events · experience · judgement · project  │
        └───────┬─────────────────────────────┬────────────────┘
                │ joins against                │ writes nothing to
                ▼                              ▼
   ┌─────────────────────────┐    ┌──────────────────────────────┐
   │ Program structure       │    │ Source of record             │
   │ tree-sitter, SCIP, LSP, │    │ git, CI, issue tracker, ADRs │
   │ CodeQL, Joern           │    │ (read-only; AEXO cites them) │
   └─────────────────────────┘    └──────────────────────────────┘
```

AEXO is a **consumer** of activity and a **citer** of records. It is authoritative only about
one thing: what the agents did, and what that experience justifies believing.
