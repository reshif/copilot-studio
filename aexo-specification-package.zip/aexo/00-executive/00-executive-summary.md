# 00 — Executive Summary

## The problem in one sentence

Coding agents are getting dramatically more capable at *doing* work and have made almost no
progress at *retaining* what that work taught them, so every session pays again for knowledge
the organisation already bought.

## Why the obvious fix is the wrong fix

The intuitive response — "cache what the agent read, and stop it re-reading" — is the design
OpenWolf and most first-generation memory layers implement. It has four defects that only
become visible at scale:

1. **It optimises a proxy.** Tokens avoided is not outcome improved. A system can cut token
   spend 30% while making agents 5% worse and still report success.
2. **It fights the provider's own optimisation.** Anthropic bills cached prompt reads at
   roughly one tenth of standard input, and cached reads do not count against input rate
   limits. Any memory layer that *mutates the prompt prefix* to save a re-read can invalidate
   a cache segment and cost more than the read it prevented. Naive de-duplication is
   cache-hostile. This is the single most under-appreciated fact in the category.
3. **It records what happened, not what was learned.** File-read history cannot answer "why do
   we believe retries are unsafe here?" — and that is the question that actually compounds.
4. **It creates a belief-amplification loop.** When an LLM's own conclusions are written to a
   file that is injected into the next LLM's context, hypotheses harden into instructions with
   no new evidence. Security research now treats this as a distinct, named risk class
   (persistent memory poisoning, OWASP ASI06), because the attack and its effect are
   temporally decoupled by weeks or months.

## The AEXO thesis

> Never make an agent rediscover experience the system can already prove — and never inject an
> old conclusion without its scope, its provenance, and its current validity.

Concretely, that turns a bookkeeping layer into a five-plane system:

| Plane | Owns | Property |
|---|---|---|
| **Capture** | Harness adapters, shell/FS/git/LSP/CI telemetry, OTel GenAI ingest | Complete, measured, harness-agnostic |
| **Event** | Append-only, hash-chained, bitemporal event log | Immutable, replayable, tamper-evident |
| **Experience** | Episodes, Evidence, Claims, Decisions, Policies | Typed, scoped, provenance-carrying |
| **Judgement** | Verification, contradiction, supersession, trust lattice | Deterministic, auditable, human-gated |
| **Projection** | Query-aware, budget-bounded, cache-aware context assembly | Relevance-bounded, citation-carrying |

Around all five sits a **control plane** that fails open operationally and fails loud
observably — the inverse of OpenWolf's silent fail-open.

## What is genuinely new here

Most of the category is converging on "event-sourced plain text + MCP + a pre-action gate."
That convergence is real and AEXO adopts it. The differentiated surface is eleven things the
existing literature and shipping tools do **not** combine:

1. **Cache-aware savings accounting.** Net savings = tokens avoided × rate − cache
   invalidation cost − injection cost. Reported per session, never as a gross figure.
2. **Delta injection instead of read suppression.** The agent saw `parser.rs@a91f`; the file is
   now `@c30d`; AEXO supplies the three changed hunks, not the file and not a denial.
3. **Evidence receipts and a dispute channel.** Every injected claim carries an ID; the agent
   can call `aexo.dispute(claim_id, counter_evidence)`, which routes into the contradiction
   engine instead of silently disagreeing.
4. **Verification-driven expiry.** Claims do not expire on a date; they expire when their
   attached verifier stops passing or can no longer be run. Staleness becomes measurable.
5. **Provenance-depth limits on reflection.** A claim may not cite another LLM-derived claim as
   its sole evidence. This structurally breaks the belief-amplification loop.
6. **A hard trust lattice.** Repository text, third-party code, dependency READMEs and prior
   model output are *evidence* (quotable, never executable). Only human-approved or
   machine-verified artefacts become *directives*. Untrusted content cannot cross the line.
7. **Crypto-shredding on an immutable log.** Per-event content keys let AEXO honour erasure
   requests without breaking the hash chain — the standard immutability-vs-GDPR deadlock,
   resolved.
8. **Observability completeness as an SLO.** AEXO continuously reconciles filesystem and git
   state against its own event record and reports the fraction of real activity it actually
   saw. If coverage drops, the agent is told its memory is degraded.
9. **OTel GenAI as a capture transport.** Ingesting `invoke_agent` / `chat` / `execute_tool`
   spans makes AEXO harness-agnostic by construction rather than by adapter proliferation.
10. **A first-class counterfactual eval harness.** Shadow mode, paired runs, and a seeded
    repeat-failure corpus, shipped as product, not as an afterthought. The category currently
    has no accepted "failures prevented per N commits" metric; AEXO defines and publishes one.
11. **Bitemporal audit.** "What did the system believe on 3 March, and on what basis?" is a
    first-class query — the record-keeping shape that AI-assisted-development reproducibility
    and EU AI Act Article 12 both point toward.

## Shape of the build

- **Three planes, three languages, on purpose.** A Rust capture agent (hooks sit in the agent's
  critical path and must answer in single-digit milliseconds), a Python control plane
  (FastAPI or Litestar; ecosystem and Pydantic-shaped schemas win here), and SQL-first storage
  (SQLite/WAL local, PostgreSQL enterprise) with DuckDB for analytics.
- **Deterministic core, LLM at the edges.** Every authoritative path is a pure fold over the
  event log. LLM calls only ever produce *candidates*.
- **Local-first, server-optional.** A solo developer runs it with no network. An enterprise runs
  the same binaries against a shared control plane with RBAC, tenancy and BYOK.

## Timeline and cost, at a glance

| Phase | Duration | Team | Outcome |
|---|---|---|---|
| P0 Foundations | 6 weeks | 3 | Event layer, capture for one harness, replay, CLI |
| P1 Experience | 6 weeks | 4 | Typed experience model, provenance graph, MCP server |
| P2 Judgement | 8 weeks | 5 | Verification, contradiction, supersession, trust lattice |
| P3 Projection | 6 weeks | 5 | Query-aware assembly, cache-aware accounting, delta injection |
| P4 Proof | 6 weeks | 5 | Eval harness, seeded corpus, published prevention rate |
| P5 Enterprise | 10 weeks | 6 | Multi-tenant, RBAC, SSO, crypto-shred, audit export |

Approximately 9–10 months to enterprise GA with a peak team of six. Detail in
`04-delivery/40-roadmap-and-phases.md` and `04-delivery/47-estimates-and-budget.md`.

## The single most important thing to build first

Not the memory. **The measurement.** Phase 4's eval harness is specified in Phase 0 and stood
up in shadow mode from the first week, because the category's defining weakness right now is
that nobody can demonstrate their memory layer makes agents better — only that it makes them
cheaper, and only by estimate. AEXO's competitive moat is being the first system that can
prove the claim.
