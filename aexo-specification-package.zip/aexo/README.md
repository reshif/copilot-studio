# AEXO — Agent Experience System

**A canonical, provenance-carrying experience layer for autonomous and semi-autonomous coding agents.**

Version: 1.0 (Research + Specification Package)
Date: 2026-08-20
Status: Ready for engineering kickoff

---

## What this package is

This is the complete pre-build artifact set for AEXO: the research that grounds it, the
architecture that follows from that research, a component-by-component specification, a
task-level work breakdown, and an acceptance-test catalog written in plain natural language
so that non-engineers, QA, and AI coding agents can all execute against the same contract.

It is written to be handed directly to:

- an engineering team starting from zero,
- a fleet of AI coding agents executing the backlog,
- a procurement/security reviewer asking "is this enterprise grade?",
- and a founder deciding what to build first.

Nothing is left as "TBD by the implementer" without an explicit decision record explaining
why the decision is deferred and what evidence would close it.

---

## How to read it (recommended order)

| If you are... | Read, in order |
|---|---|
| Deciding whether to build this | `00-executive/` then `01-research/13-token-economics.md` |
| The architect | `00-executive/` → `01-research/` → `02-architecture/` |
| An engineer picking up a ticket | `02-architecture/20-architecture-overview.md` → the relevant file in `03-specs/` → your task in `04-delivery/42-task-backlog.md` |
| QA / test engineering | `04-delivery/43-acceptance-test-catalog.md` |
| Security / compliance review | `02-architecture/2H-security-architecture.md` + `01-research/16-security-threat-landscape.md` + `01-research/17-standards-and-compliance.md` |
| Migrating from OpenWolf | `05-operations/52-migration-from-openwolf.md` |

---

## Directory map

```
00-executive/     Why this exists, the thesis, scope boundaries, vocabulary
01-research/      The landscape survey: prior art, economics, standards, threats
02-architecture/  The system design and every cross-cutting decision
03-specs/         Component specifications, each with its own acceptance criteria
04-delivery/      Roadmap, WBS, task backlog, acceptance tests, risks, budget
05-operations/    Setup, runbooks, SLOs, migration path
06-appendix/      Machine-readable schemas and document templates
```

---

## The one-paragraph version

Today's agent-memory tools optimise for *not re-reading files*. That is a proxy metric, and
in a world of prompt caching it is sometimes a negative-value one. AEXO optimises for
**evidence sufficiency per unit of context**: the agent should never rediscover something the
system can already prove, and should never receive an old conclusion without its scope, its
provenance, and its current validity. AEXO achieves this with an immutable, tamper-evident
event layer fed by harness-agnostic capture adapters; a canonical experience model of typed
Episodes, Evidence, Claims, Decisions and Policies with bitemporal validity; a deterministic
contradiction and supersession engine; a strict trust lattice that prevents untrusted
repository text from ever becoming a trusted instruction; and a query-aware Projection Engine
that assembles cache-friendly, budget-bounded, citation-carrying context for whichever agent
is asking. Everything an LLM produces is a *proposal*; only deterministic verification or a
human promotes a proposal to a governing rule.

---

## Document conventions

- **MUST / SHOULD / MAY** follow RFC 2119 severity.
- Every specification file ends with an **Acceptance Criteria** section in natural language.
- Every architectural choice with a real alternative is recorded as an **ADR** block:
  Context → Options → Decision → Consequences → Revisit-when.
- Task IDs are stable: `AEXO-<AREA>-<NNN>`. They are referenced by acceptance tests.
- Acceptance test IDs are stable: `AT-<AREA>-<NNN>`.
- Citations in the research section are numbered and resolved in `01-research/19-bibliography.md`.

---

## Package contents at a glance

| Section | Files | Contains |
|---|---|---|
| `00-executive/` | 5 | Summary, problem, thesis, principles P1–P12, trade rejections TR1–TR7, glossary |
| `01-research/` | 10 | Landscape, competitors, 33-row prior-art matrix, token economics, harnesses, code intelligence, threats, standards, open questions, bibliography |
| `02-architecture/` | 19 | Five-plane architecture, domain model, all cross-cutting specs, ADR-001…014, deployment, observability, security, performance budgets |
| `03-specs/` | 21 | Component map plus 20 component specifications |
| `04-delivery/` | 8 | Roadmap, WBS, **240 tasks**, **212 acceptance tests**, evaluation design, risks, RACI, budget |
| `05-operations/` | 4 | Setup, 11 runbooks, OpenWolf migration, SLOs |
| `06-appendix/` | 12 | 5 JSON Schemas, full SQL DDL, Policy DSL grammar, 5 templates |
| **Total** | **81** | ~80,500 words |

`INDEX.md` is the full annotated table of contents.

---

## What is deliberately uncomfortable in here

Four things in this package are stated plainly rather than smoothed over, because smoothing
them is how the previous generation of these tools got into trouble:

1. **The plan does not fit its calendar.** `04-delivery/47-estimates-and-budget.md` shows the
   backlog exceeding capacity in every phase, and gives four corrective options rather than
   adjusting the estimates until they close.
2. **Warn-only duplicate prevention is predicted to be net-negative**, and that prediction is
   pre-registered as PR1 in `44-evaluation-and-benchmarks.md` so it can be shown to be wrong.
3. **Token savings are expected to look better than outcome improvement** (PR6). Publishing that
   gap is the point.
4. **Effectiveness is unproven until P4.** No claim in this package asserts otherwise, and TR7
   forbids making one.

The system is designed so that each of these can be measured, and so that the measurement is
published whichever way it goes.
