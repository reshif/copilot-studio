# 53 — SLOs and Health

## 53.1 Service level objectives

| SLO | Target | Window | Consequence of breach |
|---|---|---|---|
| **Agent non-interference** | 100% of hooks exit 0 | Always | P0 incident |
| **Hook latency** | p99 ≤10ms gated, ≤8ms capture-only | 7 days | Investigate; block release if regressed |
| **Capture completeness** | ≥98% of capturable actions recorded | 7 days | Investigate drops |
| **Log durability** | 100% of acknowledged events durable | Always | P0 incident |
| **Chain integrity** | 100% INTACT | Always | P0 incident |
| **Derived freshness** | fold lag ≤50ms p95 | 24 hours | Investigate |
| **Bundle latency** | p99 ≤400ms | 7 days | Investigate |
| **Gate availability** | ≥99.9% non-degraded verdicts | 7 days | Investigate |
| **Daemon idle cost** | ≤1% CPU, RSS within ceiling | 24 hours | Investigate |
| **Net token delta** | >0 on the default configuration | 30 days | **Change the default** |
| **False-warning rate** | ≤15% | 30 days | Retune signatures/policies |
| **Dispute rate** | ≤10 per 100 injections | 30 days | Review claim quality |

Two of these are unusual as SLOs and deliberately so:

**Net token delta as an SLO.** If the default configuration measures net-negative for 30 days, the
default is wrong and must change. This is the operational expression of TR5 — a system that costs
more than it saves, and does not know it, is the failure mode this whole design is built to avoid.

**Agent non-interference at 100%.** Not 99.9%. A hook that fails the agent even rarely trains the
developer to uninstall it.

## 53.2 Health event taxonomy

| Kind | Severity | Surfaces where |
|---|---|---|
| `health.capture.dropped` | warning | doctor, dashboard, agent notice |
| `health.capture.malformed` | info | doctor, dashboard |
| `health.capture.degraded` | warning | doctor, dashboard, agent notice |
| `health.queue.backpressure` | warning | doctor, dashboard |
| `health.write.slow` | warning | doctor, dashboard |
| `health.chain.break` | **critical** | everywhere, immediately |
| `health.fold.lag` | warning | doctor, dashboard |
| `health.fold.unhandled_kind` | info | doctor |
| `health.structure.stale` | info | doctor, dashboard |
| `health.verifier.broken` | warning | doctor, dashboard |
| `health.verifier.timeout` | info | doctor |
| `health.gate.degraded` | warning | doctor, dashboard, agent notice |
| `health.projection.budget_exceeded` | warning | receipt, dashboard |
| `health.redaction.quarantine` | warning | doctor, dashboard |
| `health.policy.stale` | warning | doctor, agent notice |
| `health.reflection.budget_exhausted` | info | doctor |
| `health.import.rejected` | info | import report |
| `health.anomaly.retrieval` | warning | dashboard, review queue |

## 53.3 The injected health notice

When a degradation is active, the next injection carries a notice within 60 tokens:

```
⚠ aexo degraded: 340 events dropped (backpressure, 12m ago) · coverage may be incomplete
```

**Why this is injected rather than merely logged.** An agent operating on incomplete memory while
believing it is complete will act with unearned confidence. Telling the agent that its picture has
holes is worth 25 tokens. This directly answers gap 2 of the OpenWolf critique: silent fail-open
becomes loud fail-open, at the one place where it changes behaviour.

The notice is a reserved section — it ships even when the budget is tight (`3A.3`).

## 53.4 `aexo doctor` reference output

```
aexo doctor                                              v0.9.2 · project: acme/platform

daemon            running · pid 48213 · uptime 6d 4h · rss 187MB · cpu 0.4%
log               2,847,193 events · 14 segments · 1.9GB · chain INTACT (anchor 2,840,000)
derived           fresh · lag 12ms · schema v7 · last checkpoint seq 2,750,000
structure         syntactic ✓  indexed ✓ (scip, 2h old)  live ✗ (no language server)
                  312,847 symbols · 48,201 files · last reindex 4m ago

capture
  claude-code     31/31 events · 99.7% complete · 0 dropped (7d)
  codex           5/5 events  · 61.2% complete · non-Bash tools unsupported
  otel            not configured

knowledge
  claims          1,847 total · 94 verified · 612 supported · 1,048 observed · 93 imported
  stale           38 claims past verification interval
  contradictions  4 unresolved · oldest 12d
  policies        11 active · 0 stale

projection (7d)
  injections      284 · avg 612 tokens · 3 degraded
  avoided         148,200 tokens (gross)
  injected         42,100 tokens
  cache cost        6,800 tokens
  net              +99,300 tokens
  disputes        6 per 100 injections

gate (7d)
  verdicts        18,402 · allow 17,914 · warn 488 · block 0
  duplicate read  312 · repeat remedy 41 · policy 98 · claim conflict 37
  false-warning   9.2% (measured on 130 resolved cases)
  degraded        0.3%

issues
  ⚠ 38 claims past verification interval
    → aexo claims --stale     then     aexo verify-claims --run
  ⚠ 4 unresolved contradictions, oldest 12 days
    → aexo contradictions --unresolved
  ℹ codex non-Bash tool coverage unavailable (harness limitation, not a fault)
```

Note what this output does that a typical status screen does not: it prints **gross and net side by
side**, prints **false-warning rate** next to warning counts, and labels the Codex coverage gap as a
harness limitation rather than a green tick. Every number that could flatter the system is
accompanied by the number that qualifies it.

## 53.5 Alerting (team and enterprise)

| Condition | Severity | Route |
|---|---|---|
| Chain break | critical | Page |
| Log write failure sustained >30s | critical | Page |
| Capture completeness <90% for 1h | high | Ticket |
| Hook p99 >budget for 1h | high | Ticket |
| Net token delta negative for 7d | high | Ticket to the product owner, not ops |
| False-warning rate >15% for 7d | medium | Ticket to the product owner |
| Unresolved contradictions >30d | low | Digest |
| Stale claims >20% of total | low | Digest |

Two of these route to the product owner rather than to operations, because they are design defects
expressed as metrics. Paging an on-call engineer about a negative net token delta would be a
category error; nothing is broken, the system is simply not worth its cost in that configuration,
and that is a decision for whoever owns the defaults.
