# 52 — Migration from OpenWolf

## 52.1 Gap-by-gap resolution

The 17 gaps identified in the OpenWolf critique, and where each is addressed.

| # | Gap | Resolution | Spec |
|---|---|---|---|
| 1 | Incomplete observability — shell invisible | Shell command parser mandatory for Codex; OTel GenAI ingest; completeness measured and injected as an SLO | `31.5`, `28`, `2G` |
| 2 | Silent fail-open | Every drop, degradation and quarantine is counted by kind and surfaced in `doctor`, the dashboard and the agent's health notice | `32.3`, `2G` |
| 3 | AI→memory→AI belief amplification | Provenance depth cap at 2; a Claim citing a Claim can never exceed `supported`; independence scoring collapses correlated evidence | `37.6`, `24` |
| 4 | No provenance or evidence model | Full evidence graph extending PROV-DM with SUPPORTS/CONTRADICTS edge types | `24`, `PROV-002` |
| 5 | Weak concurrency, skipped writes | Single-writer daemon, total sequence order, no skipped writes possible | `32.1`, `2C` |
| 6 | Shallow anatomy index | tree-sitter mandatory tier with SCIP/LSP/CodeQL optional tiers, every answer precision-labelled | `27`, `35` |
| 7 | Lossy memory consolidation | The log is never consolidated (TR3); consolidation produces new derived records, never edits | `33.7` |
| 8 | Harness coupling | Adapter isolation plus OTel ingest as the harness-independent path | `28`, `31.5` |
| 9 | Token savings ≠ task improvement | ESK as north star; paired A/B; seeded-defect benchmark; PR6 predicts the gap explicitly | `44` |
| 10 | Static digest | Query-aware projection with lifetime-cost scoring and per-Epoch delta computation | `26`, `3A` |
| 11 | Duplicate prevention in warn mode is unreachable savings | Delta injection replaces denial; PR1 predicts warn-only is net-negative and tests it | `3A.4`, `44.6` |
| 12 | Partial subagent/session model | Context Epoch as a first-class identity level; knowledge state is per-Epoch, making subagent exemption structural | `2B`, `3B` |
| 13 | Compaction approximation | `PreCompact` capture plus a dedicated post-compaction re-anchor bundle | `31.5`, `3A.3` |
| 14 | Weak security and trust boundaries | Hard trust lattice enforced at write; declarative-only Claims; capability-free Policy DSL; injection fuzz gate | `2A`, `2H`, `3J` |
| 15 | No expiry or supersession | Verification-driven decay computed at read time; supersession as a classified relationship, not deletion | `38.5`, `39.3` |
| 16 | No contradiction engine | Four-tier detection, deterministic tiers 1–3, semantic tier review-only | `39` |
| 17 | Effectiveness unproven | P4 exists for this; harness and corpus published; nulls published | `44` |

**Plus eleven additions** beyond the critique: cache-aware net accounting, delta injection, evidence
receipts with a dispute channel, verification-driven expiry, provenance-depth limits, the hard trust
lattice, crypto-shredding on an immutable log, observability completeness as an SLO, OTel GenAI as
capture transport, content-keyed remedy signatures, and bitemporal audit.

## 52.2 The migration principle

**Nothing imported becomes authority.**

OpenWolf's artefacts were produced by a model with no evidence trail. Importing them at face value
would reproduce, in AEXO, exactly the failure AEXO exists to prevent. Every imported record
therefore enters at trust `imported`, which sits below `observed` and is never rendered as a
directive.

| OpenWolf artefact | Becomes | Trust | Rendered as a directive? |
|---|---|---|---|
| `memory.md` entries | Claims | `imported` | No |
| `cerebrum.md` rules | **Inactive** candidate Policies | — | No, until a human activates |
| `anatomy.md` index | Discarded | — | — |
| Read-tracking state | Discarded | — | — |
| Session records | Episodes, outcome `unknown` unless a signal exists | `imported` | No |

Discarding `anatomy.md` is deliberate: a model-written index competing with a tree-sitter index
computed from source produces two disagreeing structural answers, and the shallower one is not the
one to keep.

## 52.3 Procedure

```bash
# 1. Verify the source
ls -la .wolf/
aexo import --from wolf --path .wolf --dry-run

# 2. Review what will be created
#    dry-run prints counts by artefact type and the trust each will receive

# 3. Import
aexo import --from wolf --path .wolf
# → prints an import ID; keep it

# 4. Review imported claims
aexo claims --trust imported --sort-by scope_breadth

# 5. Review staged policies — none are active
aexo policy list --inactive

# 6. Promote selectively
aexo attest <claim-id> --yes --reason "confirmed still true, 2026-08"
aexo policy activate <policy-id>      # requires tests to be added and to pass

# 7. If it went badly
aexo import --undo <import-id>        # retires via events; deletes nothing
```

## 52.4 Review guidance

Imported Claims are not free — they occupy retrieval candidacy and can be selected for injection at
low band. Review them, in this order:

1. **Broadest scope first.** `--sort-by scope_breadth`. An OpenWolf ledger entry with no scope
   metadata will have been assigned the broadest defensible scope from mentioned paths; over-broad
   entries are the most likely to be wrong and the most expensive to keep.
2. **Anything phrased as an instruction.** These were written to be obeyed and will read oddly as
   Claims. Either rewrite as a declarative Claim with evidence, or promote to a Policy with tests,
   or retire.
3. **Anything unverifiable.** If you cannot state what would falsify it, retire it. A Claim with no
   possible verifier decays to `observed` permanently and will never earn its retrieval cost.

Retire freely. `aexo claim retire <id> --reason "..."` is an event and is reversible. Retiring 80%
of an imported ledger is a normal outcome and a healthy one.

## 52.5 Running both systems in parallel

Supported and recommended for the first two weeks.

```toml
[projection]
enabled = false
shadow  = true
```

AEXO captures and computes but injects nothing, so OpenWolf's behaviour is unaffected. After two
weeks:

```bash
aexo budget --shadow          # what injection would have cost, net
aexo gate stats --shadow      # what would have fired, and how often
aexo completeness             # what AEXO saw that OpenWolf did not
```

Then decide, with numbers, whether to switch. Disable OpenWolf's hooks before enabling AEXO
projection — two systems injecting into the same prefix will both mutate it, and the cache cost
compounds.

## 52.6 Migrating from projectmem

Structurally easier, because projectmem is already event-sourced with typed records.

```bash
aexo import --from projectmem --path .projectmem/events.jsonl
```

Typed records preserve their type and trust where the source distinguishes them; untyped records
enter at `imported`. The deterministic pre-action gate concept maps directly onto AEXO's Gate, with
two differences worth knowing before you migrate:

- AEXO's remedy signatures are **content-keyed** (alpha-renamed AST shape), so a repeat attempt is
  recognised even when paths and identifiers changed.
- AEXO records every verdict including `allow`, which is what makes the counterfactual analysis in
  `44` possible.

## 52.7 Acceptance criteria

**AC-MIG-1.** Given a `.wolf/` directory, when imported, then no imported record is ever rendered
as an imperative in any bundle.

**AC-MIG-2.** Given `cerebrum.md` rules, when imported, then all are inactive and require both
tests and explicit human activation before they can fire.

**AC-MIG-3.** Given a dry-run import, when it completes, then no records are created and the
printed counts match exactly what a real import subsequently creates.

**AC-MIG-4.** Given an import followed by `--undo`, when both complete, then no Claim from that
import is live, the log contains no deletions, and verification reports INTACT.

**AC-MIG-5.** Given shadow mode during parallel running, when a session completes, then the agent's
context is byte-identical to a run with AEXO absent.

**AC-MIG-6.** Given each of the 17 gaps, when the mapping in `52.1` is audited, then each names a
specific mechanism in a specific spec, and each named mechanism has at least one acceptance test in
`43`.
