# 51 — Runbooks

Each runbook: symptom → diagnosis → action → verification.

## RB-01 · Daemon will not start

**Symptom.** `aexo start` exits non-zero.

**Diagnose.**
```bash
aexo doctor
aexo status --json | jq .daemon
```

| Cause | Signal | Action |
|---|---|---|
| Another daemon holds the lock | Exit message names a PID | Confirm the PID is AEXO; if stale, `aexo start --break-stale-lock` |
| Derived state corrupt | Start-up reports fold error | `aexo rebuild` — safe, the log is authoritative |
| Chain break | Start-up reports integrity failure | See RB-02 — **do not rebuild yet** |
| Permissions | EACCES on `$AEXO_HOME` | Fix ownership to the invoking user, mode 0700 |
| Port in use (OTLP) | Bind error on 4317 | Change `capture.otel_port` or disable the receiver |

**Verify.** `aexo status` reports running; `aexo doctor` is clean.

## RB-02 · Chain verification fails

**Symptom.** `aexo verify` exits 3 naming a sequence.

**This is a serious signal. Do not rebuild, do not delete, do not restart in a loop.**

**Diagnose.**
```bash
aexo verify --full --json > /tmp/verify.json
jq '.break' /tmp/verify.json      # sequence, expected hash, computed hash
```

| Likely cause | Distinguishing signal |
|---|---|
| Disk corruption | Break at a segment boundary; filesystem errors in system logs |
| Interrupted seal | Break at the last sequence of a segment; a temp file present |
| Tampering | Break mid-segment with no I/O errors and no crash record |
| Software defect | Reproducible on a fresh rebuild from the same segments |

**Action.**
1. Preserve everything: `cp -a $AEXO_HOME /secure/backup/`.
2. Determine the last good anchor: `aexo verify --range 0:<break_seq>`.
3. If corruption is confirmed and the break is recent, `aexo recover --from-anchor <seq>` seals a
   new chain from the last verified anchor and **records a `CHAIN_BREAK` event** documenting what
   was lost. It never silently re-chains.
4. If tampering is suspected, escalate before touching anything further.

**Verify.** `aexo verify --full` is INTACT and a `CHAIN_BREAK` event is present and explains itself.

## RB-03 · Events are being dropped

**Symptom.** `aexo doctor` reports drops; health notices appear in agent context.

**Diagnose.**
```bash
aexo completeness --json | jq '.dropped_by_kind'
aexo status --json | jq '.queue'
```

| Cause | Action |
|---|---|
| Sustained burst above capacity | Raise `daemon.queue_capacity`; confirm disk write throughput |
| Slow disk | Move `$AEXO_HOME` to faster storage; check fsync latency |
| Spool at cap with daemon down | Start the daemon; spool drains automatically |
| A pathological event kind flooding | Identify via `dropped_by_kind`; add a capture filter for that kind |

**Verify.** Drop counters stop increasing; completeness returns to expected levels.

## RB-04 · Hook latency is high

**Symptom.** Sessions feel sluggish; `aexo doctor` reports hook p99 above budget.

**Diagnose.**
```bash
aexo doctor --bench-hook
```

| Cause | Action |
|---|---|
| Daemon saturated | Check queue depth and CPU; see RB-03 |
| Gate slow due to stale derived state | `aexo rebuild`; check fold lag |
| Antivirus scanning the binary on every exec | Add an exclusion for the AEXO binary directory |
| Config fast path stale | `aexo config refresh` |
| Very large repository, structure queries in gate path | Confirm structure tier; consider disabling `live` tier |

**Verify.** `aexo doctor --bench-hook` reports p99 within budget.

## RB-05 · Too many Gate warnings

**Symptom.** Agents warned constantly; developers disable the Gate.

**This is a product failure, not a user error. Treat it as such.**

**Diagnose.**
```bash
aexo gate stats --window 7d          # fire rate, by check, by rule
aexo gate stats --false-warning      # where the warned action was subsequently correct
```

**Action.**
| Cause | Action |
|---|---|
| Remedy signature too coarse | Raise the signature specificity threshold; re-measure against the corpus |
| A policy is over-broad | `aexo policy test <name>` against recent actions; narrow its scope |
| Duplicate-read check firing across legitimate re-reads | Confirm Epoch boundaries are correct; a subagent misattributed to the parent Epoch causes this |
| Claims over-scoped | `aexo claims --scope-audit` lists claims whose scope exceeds their evidence |

**Verify.** Fire rate falls; false-warning rate under 15%; developers stop disabling it.

## RB-06 · Claims are noisy or wrong

**Diagnose.**
```bash
aexo claims --band observed --sort-by retrieval_count
aexo claims --scope-audit
aexo disputes --window 30d
```

**Action.**
1. Inspect the highest-retrieval low-band Claims first — they cost the most and are supported the
   least.
2. Retire bad Claims: `aexo claim retire <id> --reason "..."` (an event; reversible).
3. If a whole cohort is bad, find its prompt version: `aexo claims --prompt-version <hash>` and
   retire in bulk with a reason.
4. Tighten admission if the pattern recurs — narrower scope inference or a higher evidence
   threshold. Loosening is never the fix.

**Verify.** Dispute rate falls; injection precision rises.

## RB-07 · A credential was captured

**Symptom.** A secret is found in stored payloads, or a redaction false negative is suspected.

**Act quickly and in this order.**
1. **Rotate the credential.** Nothing else matters until this is done.
2. Locate it: `aexo search --raw "<fragment>" --scope payloads`.
3. Shred: `aexo forget --subject <blob-or-subject> --reason "credential exposure"`.
4. Verify: `aexo verify` reports INTACT; the payload no longer decrypts.
5. Fix the gap: add the pattern to the redaction TP corpus, confirm it does not break the FP corpus,
   ship it.

**Verify.** The credential is rotated, the payload is unrecoverable, and CI now catches the pattern.

## RB-08 · Rebuild takes too long

**Diagnose.** `aexo rebuild --dry-run` reports event count and estimated time.

**Action.**
| Cause | Action |
|---|---|
| No recent checkpoint | Confirm checkpointing is enabled; it should run every 250k events |
| Very large log | Rebuild from the latest checkpoint rather than genesis |
| Slow disk | Rebuild to a faster volume, then move |
| Structure re-derivation dominating | Rebuild derived state first, structure second (`--defer-structure`) |

**Verify.** Rebuild completes within the budget in `2I`.

## RB-09 · Contradiction backlog is growing

**Diagnose.** `aexo contradictions --unresolved --age-sort`

**Action.** Resolve oldest first. If the backlog is systemic rather than incidental, the cause is
usually over-scoped Claims producing false overlaps — run `aexo claims --scope-audit`.

**Never bulk-resolve.** There is no such command, deliberately (`3G.4`).

## RB-10 · Upgrading

```bash
aexo verify --full            # before anything
aexo stop
# install new version
aexo start                    # rebuilds derived state if the schema version changed
aexo doctor
aexo verify
```

The log format is versioned and backward-compatible; derived state is disposable. A failed upgrade
is recovered by reinstalling the previous binary — the log is untouched.

## RB-11 · Control plane unreachable (enterprise)

**Expected behaviour:** everything keeps working. Org policy goes stale and this is reported
locally.

**Diagnose.** `aexo status --control-plane`

**Action.** If staleness exceeds the configured tolerance, the daemon reports it in the health
notice. Restore connectivity; policy bundles resync automatically. **Do not disable policy
enforcement to work around an outage** — the last known good bundle stays active by design.
