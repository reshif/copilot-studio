# 50 — Setup Guide

## 50.1 Install

```bash
# macOS / Linux
curl -fsSL https://get.aexo.dev | sh          # verifies signature before executing

# Windows
irm https://get.aexo.dev/install.ps1 | iex

# Offline / air-gapped
tar xzf aexo-<version>-<platform>.tar.gz
./aexo-install --offline --verify-sbom
```

The installer performs no network access beyond fetching the signed archive, runs no post-install
scripts, and installs a single binary plus grammars.

## 50.2 Initialise

```bash
cd /path/to/your/repository
aexo init
```

`aexo init` will:
1. Detect installed harnesses.
2. Print exactly what it will write and where.
3. Ask for confirmation.
4. Write hook configuration idempotently, preserving unrelated settings.
5. Fire a synthetic hook and verify capture end to end.
6. Print coverage — including what it *cannot* capture.

Expected output includes a coverage section like:

```
coverage
  claude-code   31/31 hook events        full
  codex          5/5 hook events         partial — tool hooks fire for Bash only
                                         non-Bash tool calls will not be captured
  otel           listening :4317         optional, no harness configured
```

**Read the coverage section.** A memory system whose coverage you have not checked is a memory
system that will confidently tell you things based on a partial picture.

## 50.3 Start

```bash
aexo start
aexo status
```

The daemon starts on demand if `aexo init` configured autostart. It is safe to leave running; idle
cost is ≤1% CPU and its RSS ceiling is enforced.

## 50.4 Connect the MCP server

For Claude Code, `aexo init` writes the MCP configuration. To verify:

```bash
aexo status --mcp
```

Manual configuration, if needed:

```json
{
  "mcpServers": {
    "aexo": { "command": "aexo-mcp", "args": ["--project", "."] }
  }
}
```

## 50.5 First session

Run a normal coding session. Then:

```bash
aexo status          # what was captured
aexo doctor          # is anything degraded
aexo claims          # what has been learned (likely nothing yet — claims need episodes)
aexo budget          # net token accounting so far
```

**Do not expect Claims after one session.** Claims require Episodes with outcomes, and outcomes
require signals — a test run, a commit, an attestation. A quiet first day is correct behaviour, not
a fault.

## 50.6 Recommended first configuration

```toml
# $AEXO_HOME/config.toml

[gate]
mode = "warn"                  # never "block" until you have measured false-warning rate

[projection]
session_start_budget = 900
enabled = true

[reflection]
enabled = true
daily_token_budget = 50_000
model_tier = "small"

[capture]
otel_receiver = false          # enable only if a harness emits GenAI spans

[retention]
log_days = 365
blob_days = 180
```

**Start in shadow mode if you want a baseline first:**

```toml
[projection]
enabled = false
shadow = true                  # compute everything, inject nothing
```

Run for a week, then compare `aexo budget --shadow` against what injection would have cost. This is
the honest way to decide whether to turn it on.

## 50.7 Team setup

```bash
aexo server start --config team.toml    # REST + dashboard
aexo policy add ./policies/*.aexo       # human-authored only
```

Policies must carry tests and are compiled at activation. See `06-appendix/templates/policy.aexo`.

## 50.8 Verify integrity at any time

```bash
aexo verify                # from the last anchor, <500ms
aexo verify --full         # genesis to head
```

## 50.9 Uninstall

```bash
aexo uninstall
```

Removes hook configuration from every harness it configured, stops the daemon, and **leaves your
data alone**. To remove data:

```bash
aexo uninstall --purge     # requires explicit confirmation; describes what is destroyed
```
