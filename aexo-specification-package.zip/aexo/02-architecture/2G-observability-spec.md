# 2G — Observability, Health and the Control Plane

The direct answer to silent fail-open. **Fail open operationally; fail loud observably.**

## 2G.1 Health states

| State | Definition | Agent impact | Signal |
|---|---|---|---|
| `HEALTHY` | All adapters reporting, completeness ≥95%, queue <50%, derived lag <100 events | Full function | Nothing injected beyond the normal receipt line |
| `DEGRADED` | Any adapter erroring, completeness 85–95%, queue 50–80%, derived lag 100–10,000 | Full function, lower confidence | A notice in every bundle naming the degradation |
| `FAILED` | Capture stopped, completeness <85%, chain verification failed, or queue saturated | Capture may be incomplete; Gate may be stale | A prominent notice; `aexo doctor` explains |
| `OFF` | Explicitly disabled | None | Stated at session start |

The state is written atomically to `.aexo/health.json` on every transition, so any process — the
CLI, the dashboard, a shell prompt integration, another tool — can read it without an RPC.

## 2G.2 The injected health notice

Reserved budget in every bundle (`26` §26.5):

```
[aexo] memory DEGRADED · coverage 88.2% (24h) · shell adapter erroring since 14:02
       Treat absence of a warning as weak evidence.
```

That last line is the point. An agent told nothing assumes completeness. An agent told coverage is
88% can calibrate. This is roughly 25 tokens and it is the highest-integrity spend in the bundle.

## 2G.3 Metrics

### Capture
`aexo.capture.events_total{adapter,verb}` · `aexo.capture.latency_us{adapter,percentile}` ·
`aexo.capture.errors_total{adapter,class}` · `aexo.capture.queue_depth` ·
`aexo.capture.coverage_gaps_total` · **`aexo.capture.completeness_ratio`** ·
`aexo.capture.last_success_timestamp`

### Hook path (the critical one)
`aexo.hook.duration_us{event,percentile}` · `aexo.hook.fallback_total` ·
`aexo.hook.timeout_total` · `aexo.hook.exit_nonzero_total` *(must always be zero)*

### Experience
`aexo.episodes_total{outcome}` · `aexo.claims_total{band,status}` ·
`aexo.claims.scope_unresolved_total` · `aexo.verifications_total{result}` ·
`aexo.contradictions_open` · `aexo.claims.provenance_depth{percentile}`

### Gate
`aexo.gate.checks_total{decision}` · `aexo.gate.latency_us{percentile}` ·
`aexo.gate.warnings_total{class}` · **`aexo.gate.acceptance_rate{class}`** ·
**`aexo.gate.vindication_rate{class}`** · `aexo.gate.suppressed_classes`

### Economics (all net)
`aexo.tokens.prevented` · `aexo.tokens.injected` · `aexo.tokens.invalidated` ·
`aexo.tokens.reheat` · **`aexo.tokens.net_saved`** · `aexo.cost.net_usd` ·
`aexo.cache.hit_ratio` · `aexo.cache.invalidations_caused`

### Outcome (the steering metrics)
**`aexo.outcome.repeat_failures_prevented`** · `aexo.outcome.turns_to_resolution{percentile}` ·
`aexo.outcome.tool_calls_per_episode` · `aexo.outcome.esk` · `aexo.outcome.rework_rate`

## 2G.4 OpenTelemetry integration

AEXO both **ingests** GenAI spans (`28` §A5) and **emits** its own traces using the same
conventions, so agent activity and AEXO activity appear in one trace tree in whatever backend the
organisation already runs.

Span shape:
```
invoke_agent (from the harness)
 ├── execute_tool: Read
 │    └── aexo.gate.check            (AEXO span, gen_ai.operation.name = "plan")
 ├── execute_tool: mcp__aexo__recall
 │    └── aexo.projection.assemble   (gen_ai.operation.name = "retrieval")
 └── aexo.capture.append             (internal)
```

Convention version is pinned and reported by `aexo doctor`. Emission is **off by default** in the
local topology (Principle: no telemetry without opt-in) and on by default in T3–T5.

## 2G.5 Alerting

| Condition | Severity | Action |
|---|---|---|
| `hook.exit_nonzero_total > 0` | Critical | Page. This should be structurally impossible |
| `hook.duration_us p99 > 25ms` | Critical | The product is being slowed; investigate immediately |
| `completeness_ratio < 0.85` | High | Health `FAILED`; notice injected |
| Chain verification failure | Critical | Health `FAILED`; capture halted; investigate integrity |
| `queue_depth > 80%` | High | Health `DEGRADED` |
| `last_success_timestamp` older than 15 min during an active session | High | Health `FAILED` |
| `contradictions_open` growing week over week | Medium | Review queue is not being worked |
| `gate.acceptance_rate < 0.15` for an active class | Medium | Auto-suppression will fire; review the class |
| `tokens.net_saved < 0` over 7 days | **High** | **AEXO is costing more than it saves. Investigate or disable.** |

The last row is unusual and deliberate: the product alerts when it is not worth running. That is
what Principle P7 and Trade Rejection TR5 look like in operation.

## 2G.6 The doctor command

```
$ aexo doctor

AEXO 1.0.0                                                    state: DEGRADED

Capture
  claude-code adapter    healthy    last event 3s ago      184,201 events
  codex adapter          not configured
  shell parser           healthy    last event 3s ago       12,884 events
  filesystem watcher     healthy    last event 1s ago       41,002 events
  git                    healthy    last event 4m ago          891 events
  otel receiver          ERROR      last event 2h11m ago         — connection refused
  test/ci                healthy    last event 22m ago         340 events

Coverage
  observability completeness (24h)   88.2%   ▼ target 95%
  unexplained mutations (24h)           41
  top gap source: EXEC events with unresolved resources (scripts)

Storage
  log head seq        1,043,829       chain: INTACT (verified 6m ago)
  derived lag                 4 events
  queue depth              0.3%
  disk                   2.1 GB  (log 1.4 · blobs 0.6 · derived 0.1)

Structure
  python  tree-sitter + LSP (live)     typescript  tree-sitter + SCIP (indexed)
  go      tree-sitter only (syntactic)  ← symbol-scoped claims unavailable

Economics (30d)
  net saved      412,880 tokens  ($6.19)
    prevented    701,220 · injected −188,410 · invalidated −92,140 · reheat −7,790
  cache hit ratio    0.91      invalidations caused by aexo: 3

Gate (30d)
  warnings 142 · accepted 61 (43%) · vindicated 11 · suppressed classes: 1

Action required
  · otel receiver down 2h11m — `systemctl status aexo-otel` or disable in config.toml
  · go support is syntactic-only — install gopls for symbol-scoped claims
```

Every line answers a question an operator would otherwise have to guess at. This screen is the
product's integrity made visible.

## 2G.7 Acceptance criteria

**AC-OBS-1.** Given any transition between health states, when it occurs, then `.aexo/health.json`
is updated atomically and a health event is appended to the log.

**AC-OBS-2.** Given health state `DEGRADED` or `FAILED`, when any bundle is assembled, then the
notice is present, names the specific degradation, and is never dropped for budget.

**AC-OBS-3.** Given an adapter that has produced no events for longer than its expected interval
during an active session, when the health sweep runs, then that adapter is marked erroring and
`aexo doctor` names it with the duration.

**AC-OBS-4.** Given `aexo doctor` on any installation, when it runs, then it completes in under
two seconds and requires no network access.

**AC-OBS-5.** Given a hook that exits non-zero for any reason, when the metric is scraped, then
`aexo.hook.exit_nonzero_total` is greater than zero and a critical alert fires — this metric must
be zero in all normal operation.

**AC-OBS-6.** Given net savings below zero over a rolling seven days, when the sweep runs, then a
high-severity alert fires and the dashboard shows it prominently rather than hiding it.

**AC-OBS-7.** Given the local topology with default configuration, when the system runs for a full
day, then no OpenTelemetry data leaves the machine and no network connection is opened.

**AC-OBS-8.** Given OTel emission enabled, when an agent session runs, then AEXO's spans appear
as children in the same trace as the harness's `invoke_agent` span, correlated by trace id.

**AC-OBS-9.** Given the chain verification detects a break, when it is detected, then capture
halts, health becomes `FAILED`, the exact breaking sequence number is reported, and the agent's
next bundle says memory integrity is compromised.

**AC-OBS-10.** Given a fresh installation with no activity, when `aexo doctor` runs, then it
distinguishes "no activity yet" from "capture broken" and says which.
