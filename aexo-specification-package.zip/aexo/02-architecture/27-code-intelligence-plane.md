# 27 — Code Intelligence (Structure) Plane

## 27.1 Position

AEXO owns experience. Structure is integrated, never reimplemented. See
`01-research/15-code-intelligence-landscape.md` for the survey that grounds this.

## 27.2 The provider interface

One interface, four backends, one precision label on every answer.

```
StructureProvider:
  symbols_in(path, commit)            → [Symbol]
  symbol_at(path, line, col, commit)  → Symbol?
  definition_of(symbol, commit)       → Location?
  references_to(symbol, commit)       → [Location]
  callers_of(symbol, commit)          → [Symbol]
  callees_of(symbol, commit)          → [Symbol]
  implementors_of(interface, commit)  → [Symbol]
  type_of(symbol, commit)             → TypeRef?
  imports_of(path, commit)            → [ModuleRef]
  owns(path)                          → [Owner]          # CODEOWNERS
  tests_covering(symbol, commit)      → [TestRef]        # coverage data when present
  capabilities()                      → CapabilitySet

Every return value is wrapped:
  Answer<T> { value: T, precision: syntactic|indexed|live|deep, provider, commit, built_at }
```

| Backend | Precision | Availability | Latency class |
|---|---|---|---|
| tree-sitter | `syntactic` | always | sub-millisecond after warm index |
| SCIP / LSIF index | `indexed` | when an index exists | milliseconds |
| Live LSP | `live` | when a server is running | tens–hundreds of ms |
| CodeQL / CPG | `deep` | opt-in, CI-produced | seconds–minutes |

**Resolution policy:** answer from the highest-precision backend that can respond within the
caller's latency class. Gate lookups may use only `syntactic` and `indexed`. Claim verification
may use all four.

## 27.3 Why precision labels matter

They flow into the confidence function (`24-provenance-and-evidence-graph.md` §24.4). A Claim
whose structural grounding is `syntactic` gets a lower `precision_factor` than one grounded in a
`live` LSP answer. Without this, a system with a weak index produces confident nonsense, which is
exactly how memory layers lose trust.

## 27.4 Indexing strategy

**Tier 1 — tree-sitter, file-incremental, always on.**
The daemon's filesystem watcher triggers a reparse of exactly the changed files. This is the only
tier that survives a broken build, an unfamiliar language, a partial checkout or a mid-edit file.
It is also the tier that makes the write-path symbol refresh cheap enough to do on every edit,
which is what prevents stale line ranges — a mechanism the OpenWolf design got right and which is
preserved here.

**Tier 2 — SCIP, repository-scale, slow cadence.**
Refreshed in CI, on explicit command, or during idle. The known cost is that SCIP requires full
graph reconstruction on repository update, which is why it cannot be the hot path. Snapshots are
keyed by commit so an answer is always attributable to a specific tree state.

**Tier 3 — LSP, on demand.**
The daemon holds a pool of language-server clients for the repository's detected languages, warm
but idle. Queried during Episode consolidation, Claim verification and scope resolution — never
in the hook path.

**Tier 4 — CodeQL/CPG, opt-in.**
Produced by CI, ingested as evidence artefacts. Attached to Verifiers for Claims that warrant deep
analysis (reachability, taint, dataflow).

## 27.5 Storage

Structural facts are derived and disposable, keyed so that reproducibility is preserved:

```
derived/structure/<commit_sha>/<provider>@<provider_version>/
    symbols.db          # SQLite: symbol id, kind, path, range, container, signature hash
    edges.db            # calls, implements, imports, references
    manifest.json       # provider, version, built_at, coverage stats, languages
```

Retained for the last N commits (default 20) plus every commit referenced by an active Claim's
grounding. This bounds disk while keeping historical answers reproducible.

**Never stored in the event log.** The log records the *event* "a structure snapshot was built
from commit X by provider Y version Z, covering N files" — the snapshot itself lives in the
derived tier.

## 27.6 The join

The queries only AEXO can answer, and how they are computed:

```sql
-- "Which callers of this symbol have historically broken when it changed?"
WITH changed AS (
  SELECT episode_id FROM episode_artefacts
  WHERE symbol_id = :sym AND change_kind IN ('modify','remove')
)
SELECT c.symbol_id, COUNT(*) AS break_count
FROM structure_edges e
JOIN episode_artefacts a ON a.symbol_id = e.src
JOIN episodes ep ON ep.id = a.episode_id
JOIN changed ch ON ch.episode_id = ep.id
JOIN symbols c ON c.id = e.src
WHERE e.rel = 'calls' AND e.dst = :sym AND ep.outcome = 'failed'
GROUP BY c.symbol_id
ORDER BY break_count DESC;
```

Other joins in the same shape:

- **Test provenance.** "Which test demonstrated this Claim, and does it still exist and still
  cover this symbol?" — joins Claim verifiers against coverage data and the current symbol table.
- **Scope liveness.** "Do this Claim's symbols still resolve?" — the mechanism behind
  `scope_unresolved` (see `25`).
- **Co-change coupling.** "Which files change together in failure Episodes more often than
  chance?" — pure event-log statistics, used to generate G2 Claim candidates.
- **Config-to-branch.** "Which config key enables the branch this failing test covers?" — requires
  `deep` precision; opt-in.
- **Blast radius.** "What does this proposed change reach?" — structure plane forward closure,
  intersected with Policy scopes to decide whether the Gate should fire.

## 27.7 Language coverage strategy

| Priority | Languages | Backends targeted |
|---|---|---|
| P0 (Phase 1) | Python, TypeScript/JavaScript, Go, Rust | tree-sitter + LSP; SCIP where an indexer exists |
| P1 (Phase 3) | Java, Kotlin, C#, Ruby | tree-sitter + LSP; `scip-java` covers the JVM trio |
| P2 (Phase 5) | C/C++, PHP, Swift, Scala | tree-sitter + LSP |
| Always | anything tree-sitter supports | `syntactic` only |

**Graceful degradation is a feature.** A language with only `syntactic` support still gets
Episodes, remedy signatures (with coarser normalisation), the Gate on path scope, and full
provenance. It loses precise cross-references and symbol-scoped Claims. This must be visible in
`aexo doctor`, not discovered.

## 27.8 Acceptance criteria

**AC-STRUCT-1.** Given a repository with no SCIP index and no running language server, when
structural queries are made, then answers are returned with precision `syntactic`, and no query
fails for lack of a backend.

**AC-STRUCT-2.** Given the same repository with a language server available, when a
`definition_of` query is made, then the answer is returned with precision `live`, and a Claim
grounded in that answer receives a higher precision factor than one grounded in the syntactic
answer.

**AC-STRUCT-3.** Given a single file edited in a 100,000-file repository, when the incremental
index updates, then only that file's symbols are reparsed, and the update completes within 50ms
at p95.

**AC-STRUCT-4.** Given a structure snapshot keyed to commit `X`, when a query is made specifying
commit `X` after the working tree has moved to commit `Y`, then the answer reflects `X`.

**AC-STRUCT-5.** Given the entire `derived/structure/` directory is deleted, when the daemon
restarts, then indexes rebuild and every previously-answerable query is answerable again with at
least the same precision.

**AC-STRUCT-6.** Given a symbol renamed in a commit, when the structure index rebuilds and git
history is consulted, then the rename is detected and any Claim scoped to the old symbol has its
scope updated with an event recording the change.

**AC-STRUCT-7.** Given a repository in a language with only tree-sitter support, when
`aexo doctor` is run, then it reports the reduced capability set explicitly, naming which query
kinds are unavailable.

**AC-STRUCT-8.** Given a Gate lookup, when it consults the structure plane, then it uses only
`syntactic` or `indexed` backends and completes within the Gate's latency budget, never blocking
on an LSP round trip.
