# 22 — Event Layer Specification

## 22.1 Purpose

The Event Layer is the only source of truth. Everything else is a fold over it. If a piece of
state cannot be rebuilt by replay, that is a defect.

## 22.2 The Canonical Activity Event

Harness-neutral by design. Nothing in this schema references a specific tool name.

```jsonc
{
  "v": 1,
  "id": "evt_01J8...",              // ULID: sortable, unique, no coordination
  "chain": {
    "prev": "blake3:9f2c…",         // hash of the previous event's canonical form
    "hash": "blake3:31ab…",         // blake3(JCS(envelope) || prev)
    "seq": 1043821                  // monotonic per stream
  },
  "time": {
    "observed_at": "2026-08-20T09:14:03.112Z",   // valid time — when it happened
    "recorded_at": "2026-08-20T09:14:03.119Z",   // transaction time — when we learned
    "clock": { "node": "n1", "lamport": 90321 }  // for merge ordering
  },
  "identity": {
    "project_id": "prj_…", "mission_id": "msn_…", "run_id": "run_…",
    "agent_id": "agt_…",   "epoch_id": "epo_…",  "actor": "agent:claude-code",
    "actor_kind": "agent|subagent|human|job|ci|daemon",
    "process": { "pid": 4412, "host": "…", "session_ref": "…" }
  },
  "operation": {
    "verb": "READ|WRITE|EDIT|DELETE|MOVE|SEARCH|EXEC|QUERY|TEST|BUILD|
             COMMIT|MERGE|REVERT|REVIEW|PROMPT|RESPOND|COMPACT|INJECT|
             GATE_DECISION|HEALTH|COVERAGE_GAP|DISPUTE",
    "tool": "Read",                 // as reported, for forensics only
    "transport": "hook|mcp|otel|shell|fs|git|lsp|ci|api"
  },
  "resource": {
    "kind": "file|symbol|url|command|test|package|service|claim|none",
    "ref": "src/payment/client.py",
    "range": { "start_line": 40, "end_line": 118 },
    "content_hash_before": "blake3:…",
    "content_hash_after": "blake3:…",
    "size_bytes": 8412
  },
  "result": {
    "status": "ok|error|blocked|timeout|skipped",
    "error_class": null,
    "tokens": { "estimated": 2140, "measured": null }
  },
  "causality": {
    "caused_by": ["evt_01J7…"],     // DAG, not a tree
    "correlation_id": "…"           // OTel trace id when available
  },
  "trust": {
    "source_trust": "trusted|system|untrusted",
    "taint": ["repo_content"],      // propagating labels
    "model_derived": false
  },
  "payload": {
    "enc": "aes-256-gcm",
    "key_id": "key_repo_prj_…",     // crypto-shred unit
    "blob_ref": "blob:blake3:…",    // content-addressed, may be inline if small
    "redactions": [{ "kind": "anthropic_api_key", "count": 1 }]
  },
  "meta": { "aexo_version": "1.0.0", "schema_version": 1, "adapter": "claude-code@31" }
}
```

### Design notes on specific fields

**`chain`** — Hashing uses RFC 8785 canonical JSON of the *envelope only* (payload is referenced
by content hash, not inlined), so payload shredding cannot break the chain. Blake3 for speed;
the field is algorithm-tagged so migration is possible.

**Two timestamps** — Bitemporality is not optional. `observed_at` answers "when was this true";
`recorded_at` answers "when did we learn it". Without both, "what did we believe on 3 March"
cannot be answered, and late-arriving evidence (a CI result that lands twenty minutes after the
commit) corrupts the timeline.

**`causality.caused_by` is an array** — Real agent activity is a DAG. A file write may be caused
by a prompt *and* a prior test failure. A tree loses this.

**`operation.verb` is closed; `operation.tool` is free** — The verb set is the stable vocabulary
projections are written against. The tool name is retained for forensics and adapter debugging
and is never used in query logic. This is the fix for harness coupling.

**`resource.content_hash_before/after`** — This is what makes delta injection and honest
reconciliation possible. Without it, "has this changed since the agent saw it" is a guess.

**`result.tokens` keeps estimate and measurement side by side** — Never overwrite an estimate
with a measurement or vice versa; store both and reconcile. Inherited from OpenWolf's genuinely
good token accounting.

## 22.3 The single append path

**Every** write — CLI, hook, adapter, MCP tool, worker, import — funnels through one function.
Centralising this guarantees that redaction, hashing, taint assignment, timestamp hygiene and
key assignment apply uniformly and cannot be bypassed by any entry point. This discipline is
lifted directly from the closest prior art and is non-negotiable.

```
append(raw) →
   1. validate against schema (reject, never coerce)
   2. normalise timestamps to UTC ISO-8601, assign recorded_at
   3. assign identity path (fill from ambient session context)
   4. REDACT payload  ← before anything touches disk
   5. assign trust + taint from the lattice (see 2A)
   6. content-address and encrypt payload; write blob
   7. compute chain hash over the canonical envelope
   8. fsync-append envelope to the log
   9. update derived indexes (async, best-effort)
  10. emit to the subscriber bus (async, best-effort)
```

Steps 1–8 are synchronous and transactional. Steps 9–10 are best-effort: if they fail, the log is
still correct and the index can be rebuilt.

## 22.4 Redaction

Patterns are anchored to recognisable, minimum-length prefixes so that ordinary debugging prose is
never altered. Covered by default: provider API keys (`sk-`-style), GitHub tokens, AWS access key
IDs, Google API keys, Slack and Stripe tokens, JWTs, bearer tokens, PEM private-key headers,
connection strings with embedded credentials, and a configurable pattern list.

Every redaction replaces the match with `[REDACTED:<kind>]`, records a counted entry in
`payload.redactions`, and emits a notice.

Redaction is **wrapped defensively**: a scrubber fault must never block the primary write. If the
scrubber throws, the payload is stored with `payload.redaction_status = "failed"` and the event is
quarantined from projection until reviewed.

**Test requirement:** the redactor is pinned by both true-positive tests (real-shaped credentials
are scrubbed) and false-positive tests (prose containing `sk` or `AKIA` as words is untouched).
Both suites are required to pass in CI on every commit.

## 22.5 Storage layout

### Local (default)

```
.aexo/
  events/
    000001.jsonl.zst        # segment, sealed at 64MB or 24h
    000002.jsonl.zst
    current.jsonl           # open segment, uncompressed, fsync-appended
    ANCHORS                 # periodic chain anchors (seq, hash, timestamp, optional signature)
  blobs/
    ab/cd/abcd1234…         # content-addressed, encrypted
  keys/
    keyring.json            # wrapped content keys (never plaintext at rest)
  derived/                  # ALL rebuildable; safe to delete
    index.sqlite            # events index, episodes, claims, graph, knowledge state
    structure/<commit>/     # tree-sitter + SCIP snapshots
    analytics.duckdb        # optional, for reporting
  config.toml
  health.json               # current health state, written atomically
  queue/                    # hook fallback when the daemon is unreachable
```

`derived/` carries a marker file listing the log sequence it was built from. On start, if the log
has advanced beyond the marker, the daemon catches up incrementally. If the marker is missing or
the schema version changed, it rebuilds from zero. **Rebuild from zero must always be safe and
must be exercised in CI.**

### Enterprise

The same logical model on PostgreSQL 16+: `events` as an append-only partitioned table with a
`BEFORE UPDATE OR DELETE` trigger that raises, blobs in object storage, keys in a KMS/HSM,
derived state in the same database or a read replica. The event schema is byte-identical, so an
export/import round-trip between local and enterprise is lossless.

## 22.6 Replay and rebuild

```
aexo replay --to-seq N            # rebuild all derived state as of sequence N
aexo replay --as-of 2026-03-03    # transaction-time rebuild: "what did we believe then"
aexo replay --valid-as-of 2026-03-03  # valid-time rebuild: "what was true then"
aexo verify                        # walk the chain, verify every hash and anchor
aexo verify --deep                 # also verify blob content addresses
```

Replay is a pure fold. **Requirement:** replaying the same log twice produces byte-identical
derived state, verified by hashing the derived database's logical dump. This is asserted in CI
against the fixture corpus.

## 22.7 Retention and crypto-shredding

| Tier | Contents | Default retention |
|---|---|---|
| Hot | Envelope + payload, uncompressed index | 90 days |
| Warm | Envelope + payload, compressed segments | 1 year |
| Cold | Envelope + payload in archive storage | 7 years (configurable) |
| Tombstone | Envelope only, payload key destroyed | forever |

**Crypto-shred** (`aexo forget --subject <ref> --reason <text> --actor <who>`):
1. Identify every payload encrypted under the target content key.
2. Destroy the key from the keyring and from every backup keyring.
3. Append a `FORGET` event recording subject, reason, actor, and the count of affected payloads.
4. Rebuild derived state, which now omits the shredded content.

Result: envelopes, chain, sequence and relations survive; content is permanently unrecoverable.
The `FORGET` event is itself part of the chain, so erasure is auditable.

**Key granularity** is configurable: per repository (default), per author, per session, or per
subject identifier. Finer granularity means more keys and more precise erasure.

## 22.8 Acceptance criteria

**AC-EVT-1.** Given a fresh repository, when a developer initialises AEXO and an agent performs
one file read, then exactly one event with verb `READ` appears in the log, its chain hash
validates, and its payload is retrievable and decryptable.

**AC-EVT-2.** Given a log of any size, when `aexo verify` is run, then it reports either
`INTACT` with the verified sequence range, or the exact sequence number where the chain first
breaks — and it never reports `INTACT` for a log where any envelope byte has been altered.

**AC-EVT-3.** Given a log and its derived state, when the entire `derived/` directory is deleted
and the daemon restarts, then derived state is rebuilt and a logical dump of it hashes
identically to the dump taken before deletion.

**AC-EVT-4.** Given an event whose payload contained a credential-shaped string, when the event is
read back, then the credential does not appear anywhere on disk in plaintext, and the event
records a redaction of the correct kind.

**AC-EVT-5.** Given prose that merely mentions token-like words in ordinary sentences, when it is
captured, then no redaction is applied and the text is byte-identical to the input.

**AC-EVT-6.** Given a request to forget a subject, when `aexo forget` completes, then no payload
belonging to that subject can be decrypted, `aexo verify` still reports the chain `INTACT`, and a
`FORGET` event records who requested it, when, and why.

**AC-EVT-7.** Given a log containing events with out-of-order `observed_at` values relative to
`recorded_at` (late-arriving CI results), when a valid-time replay is run for a date before those
results arrived, then the rebuilt state does not include them; when a transaction-time replay is
run for a date after they arrived, then it does.

**AC-EVT-8.** Given the daemon is stopped, when the hook fires, then the hook exits 0 within its
latency budget, the payload lands in the queue directory, and when the daemon restarts the queued
events are appended in their original order with their original `observed_at` values.

**AC-EVT-9.** Given the same sequence of raw inputs replayed on two different machines, when both
logs are compared, then every event's canonical envelope hash matches, proving serialisation is
deterministic and platform-independent.

**AC-EVT-10.** Given an attempt to `UPDATE` or `DELETE` a row in the enterprise `events` table,
when the statement executes, then the database rejects it and the attempt is logged.
