# 25 — Validity, Supersession and Contradiction

This is the plane that stops permanent memory from becoming a pile of advice.

## 25.1 The three failure modes it addresses

**The stale rule.** January: "never retry HTTP 504." March: payments move behind a durable queue.
June: a new provider explicitly requires transient 504 retry. August: the rule is still being
injected. Nobody noticed because nothing was responsible for noticing.

**The unqualified conflict.** Three statements that look contradictory and are actually
compatible once scoped: "never retry 504"; "provider A requires 504 retry"; "retries allowed only
after durable queue insertion." A system that cannot reconcile these accumulates advice rather
than understanding.

**The frozen truth.** A rule that was right, is still right, and is treated with the same
confidence as one nobody has checked in a year.

## 25.2 Validity is driven by verification, not by calendar

A date-based TTL is a guess. AEXO's model:

```
Claim validity state machine

   candidate ──admit──► unverified ──verifier passes──► verified
        │                   │                              │
        │                   │ ≥2 indep. supports           │ reverify_after elapses
        │                   ▼                              ▼
        │              supported ───────────────────► due_reverification
        │                   │                              │
        │                   │                    ┌─────────┴─────────┐
        │                   │              passes│                   │fails / cannot run
        │                   │                    ▼                   ▼
        │                   │                verified            contested
        │                   │                                        │
        │                   └────────contradiction opened────────────┤
        ▼                                                            ▼
     rejected                                              resolved: specialised
                                                            | superseded | retired
                          scope stops resolving at any point
                                        │
                                        ▼
                               scope_unresolved  (excluded from projection,
                                                  not retired — still true elsewhere)
```

### Verifiers

A Verifier is an executable check attached to a Claim.

```
Verifier {
  kind      : test | command | query | static_analysis | structural | manual
  spec      : e.g. "pytest tests/payment/test_retry_idempotency.py::test_no_double_charge"
  expects   : pass | fail | matches(pattern) | count(op, n)
  environment : which env it must run in
  cost_class  : cheap | moderate | expensive   # governs scheduling
  timeout
}
```

| Kind | Example | Notes |
|---|---|---|
| `test` | A named test must pass | Strongest. Preferred. |
| `command` | An exit code from a sandboxed command | Sandboxed, no network by default |
| `query` | A structure-plane query returns a nonempty set | e.g. "no caller of `charge()` is inside a retry block" |
| `static_analysis` | A CodeQL/CPG query returns zero results | Deep precision, expensive |
| `structural` | The Claim's scope still resolves | Free; runs on every index build |
| `manual` | A human re-attests | Requires an actor and a reason |

**Scheduling.** `structural` verifiers run on every structure build. `cheap` verifiers run
nightly. `moderate` run weekly or on relevant commits. `expensive` run on demand or when a
Claim is about to be injected into a high-stakes decision. Verifier runs are themselves Episodes
producing Evidence — the system verifies itself through its own machinery.

**Failure to run is not failure.** A Verifier that errors (infrastructure down, environment
missing) sets `last_verification_result: error` and does **not** open a contradiction. After
`error_tolerance_window` (default 14 days) of consecutive errors, the Claim degrades to
`unverified` and its band drops. This distinguishes "we checked and it's wrong" from "we could
not check."

## 25.3 Scope algebra

Contradiction detection is meaningless without a scope algebra. AEXO's scope is a conjunction of
independent dimensions; two scopes overlap iff every dimension overlaps.

```
overlap(A, B) = ∀ d ∈ dimensions : dim_overlap(A.d, B.d)

dim_overlap for:
  components / environments / languages  → set intersection non-empty
                                            (empty set on either side = universal = overlaps)
  paths                                   → glob intersection non-empty
  symbols                                 → set intersection non-empty after alias resolution
  dependencies                            → semver range intersection non-empty
  architecture_generation                 → equal, or either is null
  validity interval                       → Allen interval intersection non-empty
```

Three relations follow:

- **`disjoint(A,B)`** — no overlap. Both can be true. Nothing to do.
- **`A ⊑ B`** (A specialises B) — A's scope is a strict subset of B's on every dimension.
- **`conflicting(A,B)`** — scopes overlap, neither specialises the other, and polarity opposes.

## 25.4 The contradiction engine

### Detection

Runs incrementally on every Claim admission, verification result and scope resolution.

```
for each new/changed claim C:
   candidates = claims with overlapping scope AND (semantically related)
   for each D in candidates:
      if polarity_opposes(C, D) or verifier_conflict(C, D):
         classify(C, D)
```

`polarity_opposes` is deterministic when the Claims are *structurally* comparable (same predicate
over the same subject, opposite polarity — detectable because Claim statements are normalised at
admission into a subject-predicate-object triple where possible). Where they are not, an LLM
performs **triage only**: it proposes a candidate contradiction which a deterministic check or a
human confirms. The LLM never *closes* a contradiction.

### Classification and resolution

| Class | Condition | Automatic resolution |
|---|---|---|
| **Specialisation** | `A ⊑ B` and polarities oppose | Auto: A qualifies B. B is annotated "except within A's scope." Both remain active. Recorded. |
| **Temporal supersession** | Overlapping scope, different architecture generation, newer has passing verification | Auto: newer `SUPERSEDES` older; older → `superseded`. Recorded. |
| **Evidence conflict** | Same scope, same generation, both verified, opposite polarity | **No auto-resolution.** Both → `contested`. Human review queue. Both still injected, both flagged. |
| **Stale conflict** | One side fails verification | Auto: failing side → `contested`, then `retired` after grace period with a recorded reason |
| **False conflict** | Triage proposed it; deterministic check disagrees | Dismissed; the triage model's precision is scored |

**The design bias is toward specialisation, not deletion.** The three-statement retry example
resolves as: "retries allowed only after durable queue insertion" (general, current generation)
specialised by "provider A requires transient 504 retry" (narrower dependency scope), superseding
"never retry 504" (previous architecture generation, verifier now fails). All three histories
survive; only one governs.

### Alert discipline

Contradiction detection that fires constantly is ignored. Controls:

- Contradictions in the `contested` state are surfaced at most once per Claim pair until resolved
  or until new evidence arrives.
- Auto-resolved classes are logged, not alerted.
- The review queue is ranked by (injection frequency × confidence delta), so the contradictions
  that actually affect agent behaviour surface first.
- Detector precision is measured against the hand-labelled corpus (Open Question Q5) and reported.

## 25.5 Supersession

```
SUPERSEDES { src_claim, dst_claim, scope (may be narrower than either),
             reason, effective_from, actor, evidence[] }
```

Supersession is **scoped**: Claim B may supersede Claim A only within `checkout/payment`, leaving
A governing elsewhere. This is what makes a monorepo tractable.

Superseded Claims are never deleted. They are excluded from projection by default but remain
queryable, because "we used to believe X, and here is when and why we stopped" is exactly what a
post-mortem needs.

## 25.6 The audit question

> What did the system believe on 3 March, and on what basis?

Answered by a bitemporal query against the log:

```
aexo believe --as-of 2026-03-03 --scope checkout/payment
```

Returns every Claim whose transaction-time interval contained that date, with the band it held
then, the evidence it had then, and the weight-set version its score was computed under. This
query is the compliance deliverable (`01-research/17-standards-and-compliance.md`, CR-10) and it
is only possible because the event layer is bitemporal from day one.

## 25.7 Acceptance criteria

**AC-VAL-1.** Given a Claim with an attached passing test verifier and a `reverify_after` of 7
days, when 8 days elapse without a run, then its band drops from `verified` to `supported` and it
is scheduled for re-verification.

**AC-VAL-2.** Given the same Claim, when re-verification runs and the test fails, then the Claim
becomes `contested`, a `CONTRADICTS` edge is created from the failing test evidence, and the
Claim is still injected but with its contested status visible in the receipt.

**AC-VAL-3.** Given the same Claim, when re-verification cannot run because the test runner is
unavailable for three consecutive attempts, then the Claim is **not** marked contested, the
result is recorded as `error`, and only after the error tolerance window does the band drop.

**AC-VAL-4.** Given Claim A scoped to `checkout/**` asserting a property and Claim B scoped to
`checkout/payment/**` denying it, when contradiction detection runs, then the relationship is
classified as specialisation, both Claims remain active, and A is annotated with the exception.

**AC-VAL-5.** Given two Claims with identical scope, identical architecture generation, both
`verified`, and opposite polarity, when detection runs, then neither is auto-resolved, both become
`contested`, and a human review item is created.

**AC-VAL-6.** Given a Claim learned under architecture generation `g1` and a component whose
generation moves to `g2`, when a newer Claim with a passing verifier covers the same scope under
`g2`, then the older Claim is superseded automatically and the supersession records the reason.

**AC-VAL-7.** Given a superseded Claim, when a projection is assembled, then it does not appear;
and when it is queried directly by id, then it is returned with its full history and the id of
the Claim that superseded it.

**AC-VAL-8.** Given a query `aexo believe --as-of <past date>`, when it executes, then it returns
exactly the Claims whose transaction-time interval contains that date, with the confidence bands
they held at that time — not their current bands.

**AC-VAL-9.** Given a contradiction that an LLM triage step proposed, when the deterministic check
disagrees, then the contradiction is dismissed, no Claim status changes, and the triage step's
precision counter is decremented.

**AC-VAL-10.** Given a contradiction pair that has been surfaced and not resolved, when nothing
changes about either Claim, then it is not surfaced again until new evidence arrives on either
side.

**AC-VAL-11.** Given a Claim in `scope_unresolved` because its symbols no longer exist, when a
later commit reintroduces those symbols and the structure index rebuilds, then the Claim returns
to its prior status rather than remaining excluded.

**AC-VAL-12.** Given the contradiction detector running against the labelled corpus, when
precision and recall are computed, then both are reported in the release notes and precision
below the configured floor blocks the release.
