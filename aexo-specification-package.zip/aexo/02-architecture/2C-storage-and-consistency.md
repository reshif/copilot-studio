# 2C — Storage, Consistency and Sync

## 2C.1 Storage tiers

| Tier | Local | Enterprise |
|---|---|---|
| Event log | Segmented JSONL + zstd, fsync-append | PostgreSQL 16+, append-only partitioned table |
| Blobs | Content-addressed files, encrypted | S3-compatible object storage, SSE-KMS |
| Keys | Local keyring, OS keychain-wrapped | KMS / HSM, BYOK supported |
| Derived index | SQLite WAL | PostgreSQL (same or replica) |
| Structure snapshots | SQLite per commit | PostgreSQL or object storage |
| Analytics | DuckDB over exported Parquet | Warehouse export (Parquet/Iceberg) |
| Optional vectors | LanceDB or SQLite-VSS | pgvector or existing customer store |

**One logical schema, two physical backends.** The event envelope is byte-identical in both, so
export/import round-trips losslessly and a team can move from local to enterprise without
rewriting history.

## 2C.2 ADR: why SQLite locally

**Context.** The local deployment must run with no server, no configuration, no daemon
dependencies beyond AEXO's own, on macOS, Linux and Windows, in an air-gapped environment.

**Options considered.**
| Option | Verdict |
|---|---|
| Plain files only (JSONL + Markdown) | Chosen for the *log*; insufficient for the derived index — no indexes, no joins, no transactions |
| SQLite (WAL) | **Chosen for derived state.** Ubiquitous, embedded, transactional, excellent read concurrency under WAL, single-file, no ops |
| DuckDB | Chosen for *analytics* only. Excellent columnar scans; poor fit for the transactional derived index |
| RocksDB / LMDB | Rejected. Key-value forces query logic into application code, hurting the recursive-graph traversals |
| Embedded graph engine (Kùzu-class) | Deferred. The graph is small enough for recursive CTEs; revisit only if traversal latency exceeds budget |
| Turso/Limbo (Rust SQLite reimplementation) | Watching. Async I/O and deterministic simulation testing are attractive, but it was still beta as of mid-2026 |

**Decision.** JSONL segments for the log (grep-able, diff-able, git-native, human-legible),
SQLite WAL for derived state, DuckDB for analytics.

**Consequences.** Zero-ops locally; the derived index can always be rebuilt; the log survives
independently of any database format change.

**Revisit when:** derived-index size exceeds 20GB on a typical repository, or graph traversal p99
exceeds 100ms.

## 2C.3 ADR: why PostgreSQL for enterprise

**Context.** Multi-tenant, RBAC, row-level security, backup/PITR, HA, existing operational
familiarity.

**Decision.** PostgreSQL 16+ with:
- `events` as a declaratively partitioned, append-only table with a `BEFORE UPDATE OR DELETE`
  trigger raising an exception (defence in depth beyond permissions),
- row-level security on `tenant_id` for every table,
- `pgvector` if and only if optional semantic recall is enabled,
- logical replication for read replicas serving projections.

**Rejected:** a distributed database. There is no workload here that needs one; the write rate is
bounded by human and agent activity, and partition tolerance would buy complexity, not
availability.

## 2C.4 Consistency model

**Within one machine:** strict serialisability for the log (single writer, fsync), read-committed
for derived state. Derived state may lag the log; every derived read reports the sequence it was
built from, so a caller can detect staleness.

**Explicit staleness contract.** Every API response carries:

```
{ "data": …, "built_from_seq": 1043821, "log_head_seq": 1043829, "stale_by": 8 }
```

A Gate verdict computed from a stale index sets `degraded: true` (`29` §29.2). **Nothing in AEXO
silently serves stale data as fresh.** This is the storage-layer expression of Principle P6.

**Across machines:** eventual, via explicit merge. There is no distributed transaction.

## 2C.5 The no-skipped-writes rule

OpenWolf skipped index updates when a lock could not be acquired quickly, assuming a later writer
would converge state. Final state converged; history did not. That is acceptable for bookkeeping
and unacceptable for experience, because the missing operation is exactly the one a post-mortem
needs.

AEXO's rule: **writes queue; they never skip.**

```
append() → bounded MPSC queue (capacity 100,000) → single writer thread → fsync batch
```

- Queue depth is a monitored metric with a warning threshold at 50% and a health event at 80%.
- At 100%, the overflow policy applies. Default: **block the producer** (the daemon, never the
  hook — hooks are already decoupled by the socket + queue-file fallback). Alternative policies
  (`spill_to_disk`, `drop_lowest_priority`) exist but require explicit configuration and emit a
  loud health event.
- Batched fsync: up to 1,000 events or 10ms, whichever comes first. This keeps durability while
  keeping throughput above 50,000 events/second on commodity hardware.

## 2C.6 Team sync without a central server

**Goal:** a team shares one project memory over their existing git remote, with no server, in the
spirit of local-first software.

**Design:**
1. The event log is append-only with **content-addressed event IDs** and hybrid logical clocks.
2. Each contributor's log is a separate segment stream identified by a node ID, so two people
   appending simultaneously never write the same file.
3. Merge is a **deterministic interleave**: order by (hybrid logical clock, node ID, event hash).
   Identical events (same content address) deduplicate.
4. **All derived state is recomputed after merge.** Nothing derived is merged. Slower, obviously
   correct, and it sidesteps every CRDT subtlety in the derived layer.
5. Chain hashes are per-stream, so a merge does not invalidate any contributor's chain. A
   post-merge **merge anchor** records the merged head.

```
alice/events/000004.jsonl.zst  ┐
bob/events/000002.jsonl.zst    ├── deterministic interleave ──► merged view
carol/events/000007.jsonl.zst  ┘                                     │
                                                                     ▼
                                                       full derived recompute
```

**Conflict cases and resolution:**

| Case | Resolution |
|---|---|
| Both contributors recorded the same event (same content address) | Deduplicate |
| Contradictory Claims from different contributors | The contradiction engine handles it — this is exactly what it is for |
| Divergent Policy edits | Git's own conflict resolution on the Policy DSL files; Policies are code |
| Divergent architecture-generation bumps | Later timestamp wins; both recorded; flagged for review |

**What is not synced:** blobs by default (they may contain source content), keys ever, and local
health state. Blob sync is opt-in with an explicit acknowledgement of what it means.

## 2C.7 Backup and recovery

| Artefact | Backup | RPO | RTO |
|---|---|---|---|
| Event log | Continuous (it is append-only files; any file backup works) | seconds | minutes |
| Blobs | Continuous | seconds | minutes |
| Keys | Separate, encrypted, with a documented escrow procedure | — | — |
| Derived state | **Not backed up.** Rebuilt from the log | n/a | minutes to hours by corpus size |

**Rebuild time is a tracked metric** with a target of under 10 minutes per million events on
commodity hardware. If it exceeds that, the fold has a performance defect.

**Key loss is unrecoverable data loss.** This is stated prominently in the setup guide and in the
CLI on first key generation. It is the cost of crypto-shredding and it is the right trade.

## 2C.8 Acceptance criteria

**AC-STOR-1.** Given a log of one million events, when derived state is rebuilt from scratch, then
it completes within ten minutes on the reference hardware and the resulting logical dump hashes
identically to the pre-rebuild dump.

**AC-STOR-2.** Given an `UPDATE` or `DELETE` issued against the enterprise `events` table by any
role including the owner, when it executes, then the database rejects it via the trigger and the
attempt is recorded.

**AC-STOR-3.** Given a derived-state read, when the response is returned, then it names the log
sequence it was built from and the current log head, and a caller can compute staleness without
another request.

**AC-STOR-4.** Given the write queue at 80% capacity, when the threshold is crossed, then a health
event is emitted and the health state becomes `DEGRADED`.

**AC-STOR-5.** Given the write queue at 100% capacity with the default overflow policy, when a
producer attempts to append, then the producer blocks and no event is dropped.

**AC-STOR-6.** Given three contributors' logs with overlapping and interleaved events, when they
are merged, then the merged order is identical regardless of the order in which the logs were
supplied to the merge, and duplicate events appear once.

**AC-STOR-7.** Given a merged log, when derived state is recomputed, then contradictory Claims
from different contributors appear as detected contradictions rather than as silently overwritten
state.

**AC-STOR-8.** Given a local deployment, when it runs for a full session, then no outbound network
connection is opened by any AEXO process, verified by a network-namespace test.

**AC-STOR-9.** Given an export from a local deployment and an import into an enterprise
deployment, when the round trip completes, then every event envelope hash matches and
`aexo verify` reports the chain intact in both.

**AC-STOR-10.** Given a repository of 100,000 files and 5,000,000 events, when the p99 latency of
a Gate lookup and a graph traversal is measured, then both remain within their budgets stated in
`2I-performance-budgets.md`.
