# 2F — Deployment Topologies

## T1 — Solo local (the default, and the one that must be perfect)

```
developer machine
  ├── agent harness ──hooks──► aexo-hook ──socket──► aexo-daemon
  │                                                      │
  │                        ◄────MCP stdio──── aexo-server┤
  │                                                      ▼
  └── .aexo/  (log, blobs, keys, derived, health)
```

- One command to install. Zero configuration required. No network egress. No telemetry.
- Backfills from git history on init, so day one is not empty.
- Everything in this package works in this topology except tenancy, SSO and central audit.

**This is the topology that determines adoption.** If it is not frictionless, nothing else matters.

## T2 — Team, git-synced

Same as T1 on each machine, plus:
- `.aexo/events/<node-id>/` committed to the repository (log only, not blobs, not keys)
- Merge on pull via the deterministic interleave (`2C` §2C.6)
- Full derived recompute after merge
- Policies live in the repository as DSL files with their tests, reviewed like code

No server. This is the highest-value/lowest-cost topology for most teams and should be the
documented recommendation for anyone under ~50 engineers.

## T3 — Team, shared server

```
developers ──► aexo-daemon (local) ──replicate──► aexo-server (shared)
                                                        │
                                              PostgreSQL + object storage
                                                        │
                                              dashboard, admin, audit export
```

- Local capture and local Gate remain local, so latency and offline capability are preserved.
- Replication is asynchronous; a network outage degrades sharing, never capture.
- The shared server owns cross-repository Claims, the review queue, org-wide policies and
  reporting.

## T4 — Enterprise multi-tenant

T3 plus: tenancy, RBAC, SSO/SCIM, BYOK, data residency pinning, audit export, HA, PITR backup.
Tenant isolation enforced at the storage layer via row-level security (`2A` §2A.6).

## T5 — Air-gapped / regulated

T3 or T4 with:
- an offline installer bundling every dependency (no package-manager resolution at install time)
- reflection disabled, or pointed at an on-premises model endpoint
- no outbound anything, verified by a network-namespace test in CI
- signed release artefacts with a documented verification procedure

## T6 — CI-embedded

`aexo` runs in CI to:
- ingest test and build results as attested evidence
- run scheduled verifiers and re-verification sweeps
- run Policy tests and block merges on failure
- produce SCIP and CodeQL indexes for the structure plane
- emit the governance report as a build artefact

This topology is how AEXO gets attested evidence, which is what makes Claims reach `authoritative`.
It should be set up in Phase 1, not treated as an enterprise add-on.

## Sizing guidance

| Scale | Events/day | Derived index | Daemon RSS | Server | Notes |
|---|---|---|---|---|---|
| Solo | 5k–50k | < 500MB | < 150MB | 1 process | Laptop-friendly |
| Team of 10 | 50k–500k | 2–8GB | < 250MB | 2 replicas | T2 or T3 |
| Org of 200 | 1M–10M | 50–300GB | < 400MB | 4+ replicas, PG primary + replica | T4 |
| Agent fleet | 10M+ | 300GB+ | < 512MB | Horizontal; partition by project | Consider a broker for fan-out |

**Hard constraint:** the daemon's resident set must stay under 512MB on the largest supported
repository. Memory growth is a defect, not a scaling characteristic.
