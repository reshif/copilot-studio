# 2H — Security Architecture

Controls for the threat model in `01-research/16-security-threat-landscape.md`.

## 2H.1 Control summary

| # | Control | Threats | Layer |
|---|---|---|---|
| S1 | Trust lattice + taint propagation | T1, T2, T3 | Data model, enforced at write |
| S2 | Provenance-depth limits + independence scoring | T3 | Admission |
| S3 | Declarative-only Claim schema | T1, T6 | Schema |
| S4 | Policy DSL: total, pure, no egress verbs, human-write-only | T6, T4 | Language + authz |
| S5 | Single append path with mandatory redaction | T7 | Ingestion |
| S6 | Hash-chained log + anchoring + optional signing | T8 | Storage |
| S7 | Content-addressed, per-payload-encrypted blobs | T6, T8, erasure | Storage |
| S8 | Row-level tenant isolation | cross-tenant | Storage |
| S9 | Deterministic Gate (no inference in the gating path) | injection into gating | Judgement |
| S10 | Attestation weighting | T4, T5 | Confidence |
| S11 | Retrieval anomaly detection | T5, T9 | Detective |
| S12 | Sandboxed verifier execution | T4, malicious verifiers | Runtime |
| S13 | Credential isolation from the execution environment | exfiltration | Runtime |
| S14 | Injection fuzz suite in CI | T1, T2, T6 | Test |

## 2H.2 S1–S3: the structural core

Specified fully in `2A-trust-and-taint-model.md`. The three properties a reviewer should verify:

1. Trust is the minimum across inputs; no operation raises it except human attestation or machine
   verification, each recorded as new evidence rather than a transformation.
2. A Claim's statement field cannot express an imperative — the schema has no such field. Only
   Policies carry imperatives, and Policies are human-write-only.
3. Untrusted content, when rendered at all, is enclosed in a labelled quotation naming its source
   and trust level. There is no code path that emits it otherwise.

## 2H.3 S4: Policy DSL security properties

- **Total.** No loops, no recursion. Every evaluation terminates in bounded time.
- **Pure.** No I/O. The evaluator has no filesystem, network or process capability. A Policy
  physically cannot exfiltrate.
- **Typed and compiled at admission.** A malformed Policy is rejected whole; there is no partial
  application.
- **Human-write-only.** Enforced by authorisation, not by convention. A `POST /v1/policies` from a
  non-human identity is rejected regardless of role.
- **Tested.** Every Policy carries example cases that must pass in CI before promotion.

## 2H.4 S5: redaction

Detailed in `22-event-layer-spec.md` §22.4. The security-relevant properties:

- Runs **before** anything touches disk, on the single append path, so no entry point bypasses it.
- Prefix-anchored, minimum-length patterns so ordinary prose is never altered.
- Wrapped defensively: a scrubber fault never blocks the write; the event is quarantined instead.
- Pinned by both true-positive and false-positive suites in CI. A regression in either fails the
  build.

## 2H.5 S6–S7: integrity and confidentiality

**Chain.** `hash(n) = BLAKE3(JCS(envelope(n)) || hash(n−1))`. Envelope only — the payload is
referenced by content hash — so payload shredding never breaks the chain.

**Anchors.** Every 10,000 events or hourly, an anchor record `{seq, hash, timestamp}` is written.
Anchors may optionally be signed (Sigstore) or timestamped (RFC 3161). Verification can start from
the most recent trusted anchor rather than from genesis, so `aexo verify` stays fast on large
logs.

**Encryption.** Payloads are AES-256-GCM under a content key. Content keys are wrapped by a master
key held in the OS keychain (local) or KMS/HSM (enterprise, BYOK supported). Key granularity is
configurable — per repository, author, session or subject — trading key count against erasure
precision.

**Crypto-shred.** `aexo forget` destroys the content key, appends a `FORGET` event recording
subject, actor and reason, and rebuilds derived state. The chain stays intact and verifiable; the
content becomes permanently unrecoverable. This is the property no competitor offers.

## 2H.6 S11: retrieval anomaly detection

The second line against delayed-trigger poisoning (T5) and noise flooding (T9).

Signals, all deterministic:
- A Claim dormant for >90 days suddenly matching an intent
- A Claim whose scope is unusually broad relative to its evidence count
- A burst of Claim candidates from one source within a short window
- A Claim whose statement embeds URLs, paths outside the project, or base64-shaped runs
- Retrieval frequency far exceeding the Claim's band

Anomalies raise a review flag; they never auto-retire, because auto-retirement is itself an attack
surface (an adversary who can trigger anomaly detection can erase inconvenient rules).

## 2H.7 S12–S13: runtime isolation

**Verifier sandbox.** Verifiers execute commands. They run with: no network by default, a
read-only repository mount plus a writable temp directory, CPU and memory limits, a wall-clock
timeout, and no access to AEXO's keys or configuration. A Verifier that requires network must
declare it, and that declaration is visible on the Claim.

**Credential isolation.** AEXO never holds provider credentials in the same process as
agent-generated content evaluation. Reflection worker credentials live in the worker's
environment; the Gate, projection and capture paths have none. This mirrors the structural fix a
frontier lab arrived at for the same reason: a prompt injection that reaches an agent should not
be one step away from tokens that could spawn fresh, unrestricted work.

## 2H.8 S14: the injection fuzz suite

A CI suite that attempts to smuggle instruction-shaped content into an agent's context through
**every** ingestion route:

| Route | Payload shape |
|---|---|
| Repository file content | Comments, docstrings, README, changelog, license text |
| Commit message | Imperative instructions |
| Dependency manifest | Package descriptions and metadata |
| MCP tool output | Structured and unstructured responses |
| Web fetch | HTML, markdown, JSON |
| Test output | Assertion messages, stack traces |
| Human statement channel | Attempted privilege claims |
| Imported memory | Migrated Claims from another system |
| Unicode | Bidi overrides, homoglyphs, zero-width joiners, tag characters |
| Encoding | Base64, ROT13, hex, unicode escapes |

**Pass criterion: zero.** No payload appears as an unlabelled imperative in any generated bundle.
Any failure blocks the release. The corpus grows every time a new evasion is found, and the suite
is run against the release candidate, not just against main.

## 2H.9 Supply chain

- Reproducible builds; artefacts signed; SBOM (CycloneDX) published per release.
- Dependency budget enforced in CI (`2E`).
- No post-install scripts. No network access at install time in the offline installer.
- Release artefacts verifiable with a documented, single-command procedure.

## 2H.10 Acceptance criteria

**AC-SEC-1.** Given the full injection fuzz corpus, when bundles are generated for every payload,
then zero payloads appear as unlabelled imperatives, and any occurrence fails the build.

**AC-SEC-2.** Given a Policy that attempts any I/O operation, when it is compiled, then compilation
fails with a message naming the prohibited operation.

**AC-SEC-3.** Given a Policy evaluation with adversarial input, when it runs, then it terminates
within its bounded time, because the language admits no unbounded construct.

**AC-SEC-4.** Given a credential-shaped string in a captured payload, when the event is written,
then the credential is absent from disk in plaintext and a redaction of the correct kind is
recorded.

**AC-SEC-5.** Given prose containing token-like words used ordinarily, when it is captured, then it
is stored byte-identically with no redaction.

**AC-SEC-6.** Given a modified byte anywhere in any envelope, when `aexo verify` runs, then it
reports the exact sequence where the chain first breaks.

**AC-SEC-7.** Given a crypto-shred of a subject, when it completes, then no payload for that
subject decrypts, `aexo verify` still reports INTACT, and a `FORGET` event names the actor and
reason.

**AC-SEC-8.** Given a verifier that attempts a network connection without declaring it, when it
runs, then the connection fails and the verification result is `error` with the reason recorded.

**AC-SEC-9.** Given the Gate path, when it is traced under load, then no inference call, no
network call and no credential access occurs.

**AC-SEC-10.** Given a Claim dormant 120 days that suddenly matches a new intent, when it is
selected, then a review flag is raised, and the Claim is still injected rather than being silently
withheld.

**AC-SEC-11.** Given a `POST /v1/policies` from a service account with the highest available role,
when it executes, then it is rejected because the actor is not human, and the attempt is logged.

**AC-SEC-12.** Given a release candidate, when the security suite runs, then the injection fuzz
suite, the redaction suites, the tenancy-isolation test and the chain-integrity test all pass, and
the release is blocked if any fails.
