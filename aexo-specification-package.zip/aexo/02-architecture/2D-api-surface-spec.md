# 2D — API Surface

Four surfaces, one core. Every surface is a thin adapter over the same service layer; no surface
has private capability.

## 2D.1 MCP server (primary agent interface)

Built against MCP **2026-07-28**. Stateless core — every call carries the identifiers it needs;
no server-side session affinity. Transports: stdio (local) and Streamable HTTP (remote).

### Read tools

| Tool | Purpose |
|---|---|
| `aexo_orient` | The session-start bundle: policies, health, mission context. Small. |
| `aexo_recall` | Query-aware, budgeted projection for a stated intent |
| `aexo_why` | Explanation for a Claim at summary / evidence / full depth |
| `aexo_history` | Episodes, failures and decisions touching a resource |
| `aexo_check` | Gate verdict for a proposed change, without performing it |
| `aexo_evidence` | Supporting and contradicting sets for a Claim |
| `aexo_delta` | What changed in a resource since this Epoch last saw it |
| `aexo_structure` | Structural query with a precision label |
| `aexo_budget` | Remaining context estimate and AEXO's cost contribution so far |
| `aexo_health` | Current health, observability completeness, degraded subsystems |

### Write tools

| Tool | Purpose |
|---|---|
| `aexo_note` | Record a durable gotcha or observation |
| `aexo_issue` | Open a tracked problem |
| `aexo_attempt` | Record an attempt with outcome `worked` / `failed` / `partial` |
| `aexo_fix` | Record a confirmed resolution closing an issue |
| `aexo_decide` | Propose a Decision (requires human approval to become one) |
| `aexo_dispute` | Challenge an injected Claim with counter-evidence |
| `aexo_focus` | Set explicit intent for subsequent projections |

### Engineering requirements (from prior art, non-negotiable)

- Every tool body runs under a wrapper that catches all exceptions and returns readable text
  rather than crashing the host session.
- Every tool runs inside a stdout-suppression context so that stray `print` or subprocess output
  cannot corrupt the JSON-RPC stdio stream.
- Tool parameters carry real JSON-Schema descriptions and constraints, so malformed calls are
  rejected at the schema layer rather than in application code. Examples: `aexo_recall.budget`
  bounded to [100, 20000]; `aexo_attempt.outcome` pattern-checked against
  `worked|failed|partial`; `aexo_history.limit` bounded to [1, 100].
- The project root resolves deterministically: `--root` → `AEXO_ROOT` → parent-directory walk for
  `.aexo/`, mirroring how git locates `.git/`.
- The initialiser prints an MCP configuration block with the absolute interpreter path baked in,
  because hosts launch servers from non-interactive shells that do not inherit an interactive
  `PATH`.

### MRTR for approvals

Promotion of a Claim to a Decision or Policy requires human approval. Under the 2026-07-28
spec, this uses Multi Round-Trip Requests: the server returns `resultType: "input_required"` with
the approval request in `inputRequests`; the client retries with `inputResponses`. The server
encodes its own correlation identifier in `requestState`, since the completion notification and
its identifier were removed.

Credential-shaped elicitation must use URL mode, never form mode.

### Explicitly not used

- **Sampling** — deprecated. Reflection calls a provider API directly.
- **Roots** — deprecated. Scope comes from tool parameters.
- **Logging** — deprecated. AEXO emits OpenTelemetry.

## 2D.2 REST / OpenAPI 3.1

For dashboards, CI integration, enterprise administration and third-party tooling.

```
GET    /v1/health
GET    /v1/projects/{p}/claims?scope=&band=&status=&as_of=
GET    /v1/claims/{id}
GET    /v1/claims/{id}/explain?depth=
POST   /v1/claims/{id}/dispute
POST   /v1/claims/{id}/attest
GET    /v1/episodes?mission=&outcome=&resource=
GET    /v1/events?from_seq=&to_seq=&verb=&actor=
POST   /v1/gate/check
POST   /v1/projections/recall
GET    /v1/contradictions?status=
POST   /v1/contradictions/{id}/resolve
GET    /v1/policies
POST   /v1/policies                 # requires human identity + passing tests
GET    /v1/metrics/savings?window=
GET    /v1/metrics/completeness?window=
GET    /v1/metrics/gate?window=
POST   /v1/export/prov              # PROV-O
POST   /v1/export/governance        # compliance report
POST   /v1/admin/forget             # crypto-shred
POST   /v1/admin/replay
```

Every response carries `built_from_seq`, `log_head_seq` and `stale_by` (`2C` §2C.4).

## 2D.3 gRPC (internal)

Daemon ↔ server ↔ worker. Not exposed externally. Protobuf definitions in
`06-appendix/schemas/`. Used for the hot paths: gate lookups, event streaming, structure queries.

## 2D.4 CLI

```
aexo init [--backfill] [--harness claude-code|codex|all]
aexo doctor                       # health, coverage, adapter status, capability report
aexo verify [--deep]              # chain integrity
aexo replay [--to-seq N|--as-of D|--valid-as-of D]
aexo status                       # one-screen summary
aexo recall "<intent>" [--budget N]
aexo why <claim-id> [--depth …]
aexo history <path|symbol>
aexo check <path> [--diff <file>]
aexo believe --as-of <date> [--scope …]
aexo claims [--band …] [--status …] [--scope …]
aexo contradictions [--open]
aexo policy new|test|promote|disable <name>
aexo note|issue|attempt|fix|decide|attest
aexo mission start|end|list
aexo arch bump <component> --reason "…"
aexo savings [--window 30d]       # NET, with components broken out
aexo gate report                  # acceptance and vindication rates
aexo export prov|governance|parquet
aexo forget --subject <ref> --reason "…" --actor "…"
aexo import projectmem|openwolf <path>
aexo eval run|report              # the evaluation harness
```

`aexo doctor` is the most important command in the product. It answers, in one screen: is capture
working, what fraction of activity am I seeing, which adapters are healthy, which capabilities are
degraded, when did I last successfully record an event, and what is my current health state. It is
the antidote to silent fail-open.

## 2D.5 Dashboard

A local, self-contained HTML page (no server dependency, no CDN) with five views:

1. **Health** — coverage over time, adapter status, degraded subsystems, last successful event
2. **Failure heatmap** — files and symbols by recorded failure density
3. **Claims** — filterable by band, scope, status; contradiction highlights
4. **Economics** — net savings with components broken out; never a gross figure
5. **Gate report** — warnings issued, acceptance rate, **vindication rate**, suppressed classes

The economics and gate views are the ones that justify the product's existence to a budget holder.

## 2D.6 Versioning and stability

- MCP tool names and schemas: semantic versioning; a removed tool has a twelve-month deprecation
  window, matching the protocol's own policy.
- REST: `/v1` frozen at GA; breaking changes only in `/v2`.
- Event schema: `schema_version` on every event; readers must handle older versions forever, since
  the log is never rewritten.
- Policy DSL: versioned; a Policy records the DSL version it was written against.

## 2D.7 Acceptance criteria

**AC-API-1.** Given an MCP tool that raises an internal exception, when it is invoked, then the
host session receives readable error text and continues, and the host process does not terminate.

**AC-API-2.** Given an MCP tool whose implementation writes to stdout, when it is invoked over
stdio transport, then the JSON-RPC stream is not corrupted and the tool result is delivered
correctly.

**AC-API-3.** Given an `aexo_recall` call with a budget of 999999, when it is validated, then it is
rejected at the schema layer with a clear bound message, before any application code runs.

**AC-API-4.** Given an MCP server started with no `--root` and no `AEXO_ROOT`, when it runs from a
subdirectory of a project, then it locates the project root by walking parents for `.aexo/`.

**AC-API-5.** Given a promotion of a Claim to a Policy, when it is requested via MCP, then the
server returns `resultType: "input_required"` carrying the approval request, and the promotion
only completes after the client retries with an approval response from a human identity.

**AC-API-6.** Given any REST response, when it is inspected, then it carries `built_from_seq`,
`log_head_seq` and `stale_by`.

**AC-API-7.** Given `aexo doctor` on a healthy installation, when it runs, then it reports the
current observability completeness, per-adapter health, the capability set for the detected
languages, and the timestamp of the last successful event — in one screen, without scrolling on an
80×40 terminal.

**AC-API-8.** Given `aexo doctor` on an installation where the daemon has been stopped for an
hour, when it runs, then it reports `FAILED`, names the daemon as the cause, states how long, and
gives the exact command to restart it.

**AC-API-9.** Given `aexo savings`, when it runs, then the output contains net savings with
prevented, injected, invalidated and reheat components broken out, and contains no gross figure
anywhere.

**AC-API-10.** Given a `POST /v1/policies` request from a non-human authenticated identity, when
it executes, then it is rejected, regardless of the identity's other permissions.

**AC-API-11.** Given the MCP server, when it negotiates with a client, then the negotiated
protocol version is reported by `aexo doctor` and a version outside the supported range produces
a clear, actionable error rather than a protocol-level failure.

**AC-API-12.** Given the dashboard opened from the filesystem with no network access, when it
loads, then all five views render fully with no external request.
