# 24 — Provenance and the Evidence Graph

## 24.1 The question the graph exists to answer

> Why does AEXO believe this, and should it still?

A memory that cannot answer this is a rumour mill. The graph is what converts "cerebrum.md says
so" into "RULE ← because ← EVIDENCE".

## 24.2 Vocabulary: PROV-DM plus two missing relations

AEXO's graph is W3C PROV-DM with four extensions. The 2026 survey of agent provenance establishes
precisely this gap: PROV covers derivation and revision but has **no vocabulary for support or
justification**, and no way to say that a tool output *contradicts* a memory item — that requires
semantic comparison, not provenance bookkeeping.

### Node types
| AEXO node | PROV class |
|---|---|
| Evidence, Artefact, Blob | `prov:Entity` |
| Action, Episode, Verification, Projection, ReflectionRun | `prov:Activity` |
| Agent, Subagent, Human, Job, CI | `prov:Agent` |
| Claim, Decision, Policy, Pattern | `prov:Entity` (specialised) |

### Edge types
| Edge | PROV | Semantics |
|---|---|---|
| `USED` | `prov:used` | An Activity consumed an Entity |
| `GENERATED_BY` | `prov:wasGeneratedBy` | An Entity was produced by an Activity |
| `DERIVED_FROM` | `prov:wasDerivedFrom` | An Entity was derived from another |
| `REVISION_OF` | `prov:wasRevisionOf` | A newer version of the same thing |
| `ATTRIBUTED_TO` | `prov:wasAttributedTo` | Responsibility |
| `INFORMED_BY` | `prov:wasInformedBy` | Activity ordering |
| **`SUPPORTS`** | *(extension)* | Evidence → Claim, with a weight |
| **`CONTRADICTS`** | *(extension)* | Evidence/Claim → Claim, with a weight |
| **`VERIFIES`** | *(extension)* | Verification → Claim, refreshing validity |
| **`SUPERSEDES`** | *(extension)* | Claim/Decision → Claim/Decision, scoped |

Anchoring on PROV rather than inventing a vocabulary is a material enterprise advantage: an
auditor's existing provenance tooling consumes an AEXO PROV-O export without a custom parser.

## 24.3 Graph invariants (enforced at write time)

**I-1 — No orphan Claims.** Every Claim has at least one `SUPPORTS` edge. A Claim with zero
support is a rejected write, not a stored row.

**I-2 — Evidence is terminal-grounded.** Every Evidence node traces to at least one Event via
`GENERATED_BY`. There is no free-floating evidence.

**I-3 — Provenance depth is bounded.** For every Claim, the shortest path to a non-`model_derived`
Evidence node is ≤ `max_provenance_depth` (default 1, configurable to 2, hard ceiling 3).

**I-4 — Taint is monotone downward.** A node's trust is the *minimum* trust across all its
inbound `USED`/`DERIVED_FROM`/`SUPPORTS` sources. Derivation can lower trust; it can never raise
it. This is the structural defence against reflection laundering.

**I-5 — Independence is ancestry-based.** Two `SUPPORTS` edges count as independent only if their
sources share no common ancestor within `independence_horizon` hops (default 3).

**I-6 — Acyclic in derivation.** `DERIVED_FROM`, `SUPPORTS` and `SUPERSEDES` together must not
form a cycle. `CONTRADICTS` may be mutual — that is exactly what a contradiction is.

**I-7 — No cross-tenant edges.** Enforced at the storage layer, not the application layer.

## 24.4 The confidence function

Deterministic, explainable, and used for **ranking only**. Gating uses bands, never the score.

```
raw =   w_e · log2(1 + independent_support_weight)
      − w_c · log2(1 + contradiction_weight)
      + w_v · verification_recency_factor
      + w_a · attested_fraction
      + w_p · precision_factor            # syntactic .3 | indexed .6 | live .9 | deep 1.0
      − w_d · (provenance_depth − 1)
      − w_s · scope_unresolved_fraction

confidence_score = clamp(sigmoid(raw), 0, 1)
```

Bands are assigned by rule, not by threshold on the score:

| Band | Requirement |
|---|---|
| `unverified` | Admitted, has support, no passing verification |
| `supported` | ≥2 independent supports, ≥1 non-model-derived, no open contradictions |
| `verified` | A verifier exists and passed within `reverify_after`, no open contradictions |
| `authoritative` | `verified` **and** human-approved, or promoted to Policy |

**Why bands rather than thresholds:** a band is explainable in one sentence to a user and to an
auditor. A float is not. And a float invites the failure mode where a model's confidence becomes
the system's confidence — exactly the poisoned-confidence-calibration risk the security
literature warns about, where a system treats a false strategy as increasingly authoritative
without ground truth.

Weights are configuration, versioned, and every stored score records the weight-set version so
that historical scores remain interpretable.

## 24.5 The explanation API

Any injected assertion must be explainable on demand, at three depths.

```
GET /v1/claims/{id}/explain?depth=summary|evidence|full
```

**summary** — one paragraph, deterministic template:
> Verified 3 days ago. Supported by 2 independent items: one failing test
> (`test_retry_idempotency`, CI-attested) and one commit (`a8193`). Scoped to
> `checkout/payment` in production with `stripe@^12`. No open contradictions.
> Nearest non-model-derived evidence: 1 hop.

**evidence** — the full supporting and contradicting sets with kinds, actors, timestamps,
attestation and precision.

**full** — the complete subgraph as PROV-O, plus every Event id, replayable.

**Requirement:** the summary rendering is a pure template over graph facts. No LLM. If a
non-technical reader cannot follow it, the template is wrong — not the reader.

## 24.6 The dispute channel

An agent that receives an injected Claim it believes is wrong currently has no recourse; it
either obeys or silently ignores. Both are bad. AEXO gives it a third option.

```
aexo.dispute(claim_id, reason, counter_evidence_refs[])
```

Effect:
1. A `DISPUTE` event is appended (the agent's reasoning is itself evidence, marked
   `model_derived`).
2. The referenced counter-evidence is ingested and evaluated against the trust lattice.
3. If the counter-evidence is non-model-derived and material, a `CONTRADICTS` edge is created and
   the Claim moves to `contested`.
4. `contested` Claims are still injected — but with their contested status visible in the
   receipt, so the next agent sees the disagreement rather than inheriting one side of it.
5. Disputes are surfaced in the human review queue.

**Why this matters:** it is the only mechanism in the design by which the system can learn that it
is wrong from the entity best positioned to notice. And because a dispute alone (model output)
cannot retire a Claim, it cannot be used to erase inconvenient rules.

## 24.7 Storage

SQL, not a graph database. The graph per repository is thousands to low millions of nodes;
recursive CTEs handle the traversals within budget.

```sql
CREATE TABLE prov_node (
  id TEXT PRIMARY KEY, kind TEXT NOT NULL, tenant_id TEXT NOT NULL,
  trust TEXT NOT NULL, model_derived INTEGER NOT NULL,
  created_seq INTEGER NOT NULL, attrs JSON NOT NULL);

CREATE TABLE prov_edge (
  src TEXT NOT NULL, dst TEXT NOT NULL, rel TEXT NOT NULL,
  weight REAL DEFAULT 1.0, tenant_id TEXT NOT NULL,
  created_seq INTEGER NOT NULL, attrs JSON,
  PRIMARY KEY (src, dst, rel));

CREATE INDEX prov_edge_dst_rel ON prov_edge(dst, rel);
CREATE INDEX prov_edge_src_rel ON prov_edge(src, rel);
```

Both tables are **derived**: rebuilt by replay, never edited in place. An embedded property-graph
engine is an optimisation to evaluate only if traversal latency exceeds budget on a real corpus.

## 24.8 Acceptance criteria

**AC-PROV-1.** Given any Claim in the system, when its explanation is requested at `summary`
depth, then a response is produced within 200ms that names the number of independent supports,
the most recent verification, the scope, and the nearest non-model-derived evidence — with no
model call involved.

**AC-PROV-2.** Given an attempt to store a Claim with no supporting evidence, when the write is
submitted, then it is rejected and the rejection reason names invariant I-1.

**AC-PROV-3.** Given evidence derived from a repository README (untrusted) that is summarised by
a reflection job, when the summary's trust is computed, then it is `untrusted`, and any Claim
citing only it cannot leave `candidate`.

**AC-PROV-4.** Given a Claim with three supporting evidence items that share a common ancestor
within the independence horizon, when confidence is computed, then the independent support weight
counts them as one.

**AC-PROV-5.** Given a Claim, when its full explanation is exported, then the export validates as
PROV-O and every referenced Event id resolves in the log.

**AC-PROV-6.** Given an agent that disputes an injected Claim with a failing-test counter-evidence
reference, when the dispute is processed, then a `CONTRADICTS` edge exists, the Claim's status is
`contested`, the Claim still appears in subsequent projections, and its receipt shows the
contested status.

**AC-PROV-7.** Given an agent that disputes a Claim with only its own reasoning as
counter-evidence, when the dispute is processed, then the dispute is recorded, no `CONTRADICTS`
edge is created from model output alone, and the Claim's status is unchanged.

**AC-PROV-8.** Given two tenants, when any graph query is executed, then no edge or node from the
other tenant is returned, and this is enforced by the storage layer rather than by application
filtering.

**AC-PROV-9.** Given the derived graph is deleted, when it is rebuilt from the log, then it is
identical to the previous graph, including every edge weight.

**AC-PROV-10.** Given a change to the confidence weight-set, when historical scores are read,
then each score reports the weight-set version it was computed under, and re-scoring with the new
weights is an explicit, recorded operation rather than a silent drift.
