# 28 — Capture Plane and Adapters

## 28.1 The completeness problem, restated

Any hook-bound capture layer under-observes, and under-observes *more* as agents get more
capable, because capable agents use more tools. The fix is not more adapters — it is
**reconciliation against ground truth plus a published completeness figure**.

## 28.2 The hook client

`aexo-hook` is a statically linked Rust binary. Its entire job:

```
1. read stdin (bounded, 256KB cap)
2. read AEXO_* environment for identity context
3. serialise to a fixed-size framed message
4. connect to the Unix socket (pre-resolved path, no lookup)  [timeout 3ms]
5. write; if PreToolUse, read the gate verdict               [timeout 7ms]
6. emit the verdict as JSON on stdout (or nothing)
7. exit 0                                                     ALWAYS
```

Non-negotiables:

- **No dynamic linking, no interpreter, no config file parsing at invocation.**
- **Exit code is always 0** for capture-only events. The blocking path uses the harness's JSON
  `permissionDecision`, never exit 2, because exit-code semantics differ across harnesses and
  exit 1 blocks nothing on Claude Code — a well-documented footgun that has silently disabled
  memory layers.
- **On any error, including socket unavailable, write to the queue directory and exit 0** within
  budget. If the queue write also fails, exit 0 silently and increment a counter the daemon reads
  on next start.
- **Absolute paths baked at install.** Hooks run under non-interactive shells that do not source
  `.bashrc`/`.zshrc`, so a bare `command -v aexo-hook` fails for anyone whose tooling lives in a
  virtualenv, conda or pyenv environment. The installer resolves and embeds the absolute path,
  with a runtime fallback for a relocated binary. This exact failure mode is documented in prior
  art and is the single most common cause of "I installed it and nothing happened."

## 28.3 Adapter matrix

### A1 — Claude Code
Registers on: `SessionStart`, `SessionEnd`, `UserPromptSubmit`, `PreToolUse`, `PostToolUse`,
`Stop`, `StopFailure`, `PreCompact`, `SubagentStop`, plus `mcp__.*` matchers.

Notes:
- `SessionStart` matchers distinguish startup / resume / clear / compact — the compact matcher is
  how Context Epochs are closed.
- Context is injected via `hookSpecificOutput.additionalContext`.
- `PreToolUse` fires before the permission check; hooks can tighten but never loosen policy.
- MCP tools appear as `mcp__<server>__<tool>`, so a single regex matcher captures all MCP traffic.

### A2 — OpenAI Codex
Registers on the five supported events. **`Pre/PostToolUse` covers only the Bash tool**, so file
operations must be derived by parsing shell command lines. Configuration lives in
`~/.codex/hooks.json` or `<repo>/.codex/hooks.json` behind a config flag.

### A3 — Shell command parser
Required for Codex parity and the largest coverage win on every harness. Parses a command line
into operations:

| Pattern | Derived operation |
|---|---|
| `cat`, `head`, `tail`, `less`, `bat`, `nl` + path | `READ` with range where derivable |
| `rg`, `grep`, `ag`, `ack` + pattern + paths | `SEARCH` with query hash |
| `sed -i`, `awk -i`, `perl -pi`, `>`, `>>`, `tee` | `WRITE` / `EDIT` |
| `mv`, `cp`, `rm` | `MOVE` / `WRITE` / `DELETE` |
| `git show`, `git diff`, `git log` | `READ` on a git object |
| `pytest`, `go test`, `cargo test`, `npm test`, `jest` | `TEST` |
| `cargo build`, `make`, `tsc`, `go build` | `BUILD` |
| `python x.py`, `node x.js`, `./script.sh` | `EXEC` — resource unknown, flagged for FS reconciliation |
| pipelines and `&&`/`;` chains | decomposed into constituent operations |

Parsing is best-effort and **always** paired with filesystem reconciliation, because a script's
internal reads are undecidable from the command line. Unparsed commands are recorded as `EXEC`
with the command hash — never dropped.

### A4 — MCP server (AEXO as a server)
See `2D-api-surface-spec.md`. Also a capture source: every AEXO tool call is an event.

### A5 — OpenTelemetry GenAI ingest
An OTLP receiver mapping the GenAI span tree onto Canonical Activity Events:

| OTel construct | AEXO mapping |
|---|---|
| `invoke_agent` span | Run / Agent boundary |
| `chat` span | `PROMPT` / `RESPOND` events with token attributes |
| `execute_tool` span | operation event, verb derived from the tool name |
| `retrieval` span | `QUERY` event |
| memory operation spans | `INJECT` events |
| `gen_ai.usage.*_tokens` | `result.tokens.measured` |
| trace/span ids | `causality.correlation_id` and `caused_by` |

**Version pinning is mandatory.** Every `gen_ai.*` attribute is at Development stability with no
1.0 and names can change between versions. AEXO pins a convention version, normalises on ingest,
and keeps a per-version translation table. A collector-side normaliser can map OpenInference and
OpenLLMetry profiles onto the standard names before they reach AEXO.

This adapter is the strategic bet: any harness emitting the conventions becomes a capture source
with zero AEXO-side work.

### A6 — Filesystem watcher
`fanotify` (Linux), `FSEvents` (macOS), `ReadDirectoryChangesW` (Windows). Debounced, respects
`.gitignore` plus an AEXO ignore list. Produces the **ground truth** against which reconciliation
runs. Records content hashes before and after where the before-state is known.

### A7 — Git
Hooks (`post-commit`, `post-merge`, `pre-commit`, `post-checkout`) plus periodic reflog scanning.
Reverts and force-pushes are strong failed-approach signals and are classified as such. On first
initialisation, git history is **backfilled** into events so that day one is not empty — a mature
project starts with populated memory and an accurate structural map from a single command.

### A8 — Test and CI
Parsers for JUnit XML, TAP, `cargo test --format json`, `go test -json`, pytest JSON report.
Webhook receivers for GitHub Actions, GitLab CI, Jenkins, Buildkite. CI-produced evidence is
`attested` when the provenance can be verified.

### A9 — Human
`aexo note`, `aexo decide`, `aexo attest`, PR/review comment ingestion. Human statements are the
only `trusted` evidence class that does not require machine attestation.

## 28.4 Reconciliation — the honesty mechanism

Runs continuously in the daemon.

```
every reconcile_interval (default 30s):
    fs_changes  = watcher events since last cycle
    git_changes = working tree diff vs last known state + reflog delta
    observed    = events with resource mutations in the same window

    unexplained = (fs_changes ∪ git_changes) − observed
    for each u in unexplained:
        emit COVERAGE_GAP event { resource, hash_before, hash_after,
                                  window, suspected_cause }
        synthesise a best-effort WRITE event so downstream state is correct
```

`suspected_cause` is inferred from timing and process ancestry where available: an unattributed
change during an active agent session with a preceding `EXEC` is attributed to that script.

### Observability Completeness

```
completeness = observed_mutations / (observed_mutations + unexplained_mutations)
               over a rolling 24-hour window
```

**This is an SLO, and it is injected into the agent's context** (`26` §26.5 reserved budget). An
agent told "memory coverage is 71%" can calibrate its trust. An agent told nothing cannot. This is
the direct answer to the silent-fail-open critique and it is the single feature most likely to
earn a skeptical engineer's trust, because it is the system admitting what it does not know.

Targets: ≥95% healthy, 85–95% degraded, <85% failed.

## 28.5 Adapter contract

Every adapter implements:

```
Adapter:
  id() → string
  version() → string
  capabilities() → { verbs[], resources[], can_block: bool, precision }
  normalise(raw) → [CanonicalActivityEvent]
  health() → { ok, last_event_at, error_rate, notes }
```

Adapters are **pure normalisers**. They never write to the log directly — they hand events to the
single append path (`22` §22.3), so redaction, hashing and taint assignment cannot be bypassed.

## 28.6 Acceptance criteria

**AC-CAP-1.** Given the daemon is running, when a `PreToolUse` hook fires, then the hook returns
within 10ms at p99 measured over 10,000 invocations.

**AC-CAP-2.** Given the daemon is stopped, when a hook fires, then the hook exits 0 within its
budget, the payload is queued, and the agent's tool call proceeds unaffected.

**AC-CAP-3.** Given the daemon restarts after being stopped, when it drains the queue, then all
queued events are appended in original order with their original `observed_at` values, and a
`COVERAGE_GAP` event records the outage window.

**AC-CAP-4.** Given a file modified by `sed -i` inside a shell command, when the shell parser runs,
then a `WRITE` event is produced naming the file — and given the same modification made by a
Python script invoked as `./tool.py`, then the parser produces only an `EXEC` event and the
filesystem watcher produces the `WRITE`, and reconciliation attributes it to the `EXEC`.

**AC-CAP-5.** Given a file modified entirely outside any observed process, when reconciliation
runs, then a `COVERAGE_GAP` event is emitted, a synthesised `WRITE` event keeps derived state
correct, and observability completeness decreases.

**AC-CAP-6.** Given observability completeness below 85%, when any bundle is assembled, then the
health state is `FAILED`, the notice appears in the bundle, and `aexo doctor` explains which
adapter is contributing the gap.

**AC-CAP-7.** Given an OTLP stream of GenAI spans from a harness AEXO has no adapter for, when the
spans are ingested, then Runs, Agents, tool calls and token usage appear as events without any
AEXO-side adapter being written.

**AC-CAP-8.** Given an OTel convention version different from the pinned one, when spans arrive,
then AEXO either translates them via the version table or records them as `unmapped` with the raw
attributes preserved — and it never silently drops them.

**AC-CAP-9.** Given `aexo init` on an existing repository with git history, when initialisation
completes, then events backfilled from history are present, the stack is auto-detected from
manifests, and the first session begins with a populated experience store rather than an empty
one.

**AC-CAP-10.** Given the hook binary is installed and the user's shell environment does not
include AEXO on `PATH`, when a hook fires from a non-interactive shell, then it still executes,
because the absolute path was resolved at install time.

**AC-CAP-11.** Given a Codex session performing file edits via Bash, when the session completes,
then file-level `WRITE` events exist for each edited file, derived from the shell parser and
confirmed by the filesystem watcher.

**AC-CAP-12.** Given any adapter raising an exception during normalisation, when the exception
occurs, then the raw payload is preserved in a dead-letter store, an adapter health error is
recorded, the agent is unaffected, and no other adapter is disrupted.
