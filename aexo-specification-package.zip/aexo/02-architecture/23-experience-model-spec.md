# 23 — Experience Model Specification

## 23.1 Position

Everything here is **derived**. Delete it and it rebuilds. It exists because raw events are the
wrong granularity for reasoning: no useful question is answered by "file X was read at 14:02".

## 23.2 Episode consolidation

### The boundary problem
An Episode is a stretch of coherent work. Detecting where one ends and the next begins is the
only place in the pipeline where an LLM is genuinely useful — and it is also a place where being
wrong is cheap and correctable.

### The two-stage design

**Stage 1 — deterministic segmentation.** Cut on hard boundaries that require no judgement:

| Signal | Boundary strength |
|---|---|
| New user prompt after an assistant turn | hard |
| `SessionStart` / `SessionEnd` | hard |
| Compaction | hard (also closes the Context Epoch) |
| Subagent spawn / stop | hard (nested episode) |
| Commit | hard |
| Test transition fail→pass or pass→fail | strong |
| Idle gap > threshold (default 15 min) | strong |
| Resource-set Jaccard similarity to prior window < 0.2 | weak |

Stage 1 alone produces usable Episodes. **The system is fully functional with Stage 2 disabled**,
which is the test of whether the LLM is load-bearing (it must not be).

**Stage 2 — LLM enrichment (optional, marked).** A model proposes `goal_text`, merges
over-segmented spans, and labels `outcome`. Every field it touches is tagged
`model_derived: true` and inherits taint. It may never change Episode boundaries that Stage 1
marked `hard`.

### The remedy signature

The most important derived artefact. For any Episode that attempted a change:

```
remedy_signature = blake3( canonical(
   sorted( for each changed hunk:
     ( normalised_symbol_path,          # resolved via the structure plane
       change_kind,                     # add|remove|modify|reorder|rename|config
       normalised_diff_shape ) )        # AST-shape hash, identifiers alpha-renamed,
) )                                      # literals bucketed, whitespace removed
```

Alpha-renaming and literal bucketing mean that "retry 3 times" and "retry 5 times" produce the
**same** signature, while "add a retry loop" and "add a null check" produce different ones. This
is what lets the Gate recognise a repeat attempt from content rather than from a file path — the
concrete advance over path-keyed prior art, and the mechanism that makes the "you tried this and
it failed" warning specific enough to be believed.

A secondary, coarser `remedy_family` groups signatures by (symbol, change_kind) alone, for
near-miss detection at lower confidence.

## 23.3 Evidence extraction

Evidence is produced deterministically from events. No model involved.

| Source event | Evidence produced | Attested? | Precision |
|---|---|---|---|
| Test runner output (JUnit XML, TAP, JSON) | `test_result` | if CI-signed | live |
| Commit | `commit` | if commit-signed | live |
| Non-zero exit + stderr | `stack_trace` | no | live |
| LSP query response | `structural_fact` | no | live |
| SCIP index lookup | `structural_fact` | no | indexed |
| tree-sitter parse | `structural_fact` | no | syntactic |
| CodeQL/CPG result | `static_analysis` | if CI-signed | deep |
| Benchmark run | `benchmark` | if CI-signed | live |
| Human review comment / prompt statement | `human_statement` | by identity | n/a |
| Incident record | `incident` | by system | n/a |
| Repository text (README, comment, doc) | `doc_excerpt` | **never** | n/a |
| LLM output | `model_output` | never | n/a |

Two rules carried from the trust model (`2A`):

- `doc_excerpt` and `model_output` are permanently `untrusted` and `model_derived` respectively.
- A Claim supported **only** by items from those two rows cannot leave `candidate` status.

## 23.4 Claim candidate generation

Three generators, all producing candidates only.

**G1 — Deterministic failure claims.** When two Episodes share a `remedy_signature` and both
have `outcome: failed`, emit a candidate: *"the change shaped like S applied to symbol Y does not
resolve the failure Z."* Evidence: both Episodes and their failing test results. Non-model-derived
by construction, so it can reach `verified` directly on verifier attachment.

**G2 — Deterministic co-change and coupling claims.** Statistical patterns over the event log:
files changed together in ≥N failure Episodes; a config key whose change precedes a test
transition. Emitted with the supporting counts as evidence.

**G3 — LLM reflection.** A scheduled worker reads recent closed Episodes and proposes candidates.
This is where the belief-amplification risk lives, and it is fenced by four rules:

1. **Provenance-depth limit.** The candidate must cite at least one item of non-model-derived
   evidence. Depth from a Claim to its nearest such item may not exceed 1 at admission.
2. **No self-citation.** A reflection candidate may not cite a Claim that a reflection job
   created, unless that Claim has independently reached `verified`.
3. **Independence scoring.** Two evidence items sharing a derivation ancestor count as one for
   `evidence_independence`. Confidence does not rise from correlated evidence.
4. **Statement form.** Declarative only. The generator's output schema has no imperative field
   (Constraint C-1). If the model emits an imperative, it is rejected at validation, not
   rewritten.

## 23.5 Scope resolution

A Claim's `scope` is the mechanism that turns "a pile of advice" into a queryable system.

```
resolve(scope, current_repo_state) →
   { status: resolved | partially_resolved | unresolved,
     symbols_found[], symbols_missing[], paths_matched[],
     dependency_satisfied: bool,
     architecture_generation_current: bool }
```

Scope resolution runs on every structure-snapshot rebuild. Outcomes:

| Resolution | Action |
|---|---|
| Fully resolved | no change |
| Symbol renamed (structure plane can prove the rename via git + SCIP) | scope updated automatically, event recorded |
| Symbol deleted | Claim → `scope_unresolved`, confidence band demoted, excluded from projection |
| Dependency version now outside the range | Claim excluded from projection for this repo; not retired (still true elsewhere) |
| Architecture generation token changed | Claim flagged for re-verification |

**This is how staleness is detected without a calendar.** The January claim "never retry HTTP 504"
survives March's migration to a queue architecture only if its scope still resolves and its
verifier still passes. When payments move behind a durable queue, the architecture generation
token changes, the Claim is flagged, its verifier is re-run, it fails, and a contradiction opens
against the new provider requirement. The system notices in hours, not never.

## 23.6 The architecture generation token

An opaque token per component that changes when a structural migration is recorded. It is set by:

- an explicit `aexo arch bump <component> --reason` command (human),
- a Decision whose kind is `migration`,
- or an automatic detector: a commit that moves >40% of a component's symbols, changes its
  dependency set materially, or renames its top-level module.

Automatic detection emits a *candidate* bump that requires acknowledgement. Getting this wrong in
the automatic direction is expensive (mass Claim invalidation), so the default is conservative
and the notification is loud.

## 23.7 Cross-project promotion

Lessons about a *library* rather than a repository should travel — with careful gating, because
this is also a cross-contamination vector.

```
promote(claim) requires ALL of:
  · claim.status ∈ {verified, authoritative}
  · claim.scope.dependencies is non-empty and version-ranged
  · claim.scope.paths is empty or matches only dependency-internal paths
  · claim.trust == trusted (never promote untrusted or model-only claims)
  · claim has ≥1 attested evidence item
  · explicit opt-in for the project (default: on for local, off for enterprise)
```

Surfaced Claims carry `source_project` attribution and, in enterprise deployments, respect tenant
isolation absolutely — a Claim never crosses a tenant boundary.

Matching uses word-boundary library names plus a semver range check plus a stack filter, so a
JavaScript project's lessons never reach a Go project. The promotable-library set is a
self-curating cache populated from every manifest the installation has seen, which keeps the
mechanism language-agnostic without a hard-coded list.

## 23.8 Acceptance criteria

**AC-EXP-1.** Given a session containing a user prompt, six tool calls and a commit, when
consolidation runs with LLM enrichment disabled, then at least one Episode is produced, its
`actions` list references exactly those events in order, and its outcome is derived from the
commit and test signals alone.

**AC-EXP-2.** Given two Episodes in which the agent added a retry loop with three attempts and
then five attempts to the same function, and both failed, when remedy signatures are computed,
then the two signatures are identical.

**AC-EXP-3.** Given two Episodes in which the agent added a retry loop and separately added a
null check to the same function, when remedy signatures are computed, then the two signatures
differ.

**AC-EXP-4.** Given an LLM reflection job that proposes a Claim citing only its own previous
output, when the candidate is submitted, then it is rejected with a provenance-depth violation
and the rejection is recorded as an event.

**AC-EXP-5.** Given an LLM reflection job that emits an imperative statement, when the candidate
is validated, then it is rejected for statement form, and the system does not attempt to rewrite
it into declarative form.

**AC-EXP-6.** Given a verified Claim scoped to symbol `payment.Client.charge`, when that symbol
is deleted from the repository and structure is re-indexed, then within one indexing cycle the
Claim's status becomes `scope_unresolved` and it stops appearing in any projection.

**AC-EXP-7.** Given the same Claim, when the symbol is renamed rather than deleted and the rename
is provable from git history plus the structural index, then the Claim's scope is updated
automatically, an event records the update, and the Claim remains active.

**AC-EXP-8.** Given a Claim whose scope names a dependency at `^12` and the project upgrades that
dependency to `14.0.0`, when projections are assembled, then the Claim is excluded for this
project and its status is not changed to retired.

**AC-EXP-9.** Given a Claim supported by three evidence items that all derive from the same
originating Episode, when independence is computed, then `evidence_independence` is 1, not 3, and
confidence does not rise as though three independent observations had occurred.

**AC-EXP-10.** Given a verified, attested, dependency-scoped Claim in project A and a project B
using the same dependency within the version range, when project B's session starts, then the
Claim is available with `source_project` attribution — and given the same Claim is untrusted or
model-only, then it is not.

**AC-EXP-11.** Given a component whose architecture generation token changes, when the change is
recorded, then every Claim scoped to that component is flagged for re-verification within one
worker cycle, and none is silently retired.

**AC-EXP-12.** Given LLM enrichment is disabled entirely, when the system runs for a full week,
then Episodes, remedy signatures, evidence, deterministic Claims (G1 and G2), the Gate and all
projections continue to function, proving no LLM is load-bearing.
