# 21 — Domain Model

## 21.1 The type hierarchy

The single most important correction to first-generation designs: these are **different kinds of
thing with different lifecycles**, and collapsing them into one Markdown file makes correct
expiry impossible.

```
                          ┌──────────────┐
                          │  RAW EVENT   │  immutable, factual, permanent
                          │  "checkout.py was read at 14:02 by agent X"
                          └──────┬───────┘
                                 │ grouped by consolidation
                                 ▼
                          ┌──────────────┐
                          │   EPISODE    │  immutable once closed
                          │  "attempt to fix the 504 retry bug, 14:02–14:47, failed"
                          └──────┬───────┘
                                 │ produces / cites
                                 ▼
                          ┌──────────────┐
                          │   EVIDENCE   │  immutable, content-addressed
                          │  "test_retry_idempotency failed with AssertionError …"
                          └──────┬───────┘
                                 │ SUPPORTS / CONTRADICTS
                                 ▼
                          ┌──────────────┐
                          │    CLAIM     │  mutable status & confidence, immutable content
                          │  "retrying payment 504s duplicates charges"
                          │  scope · validity · verifier · provenance
                          └──────┬───────┘
                    ┌────────────┼────────────┐
                    ▼            ▼            ▼
             ┌───────────┐ ┌──────────┐ ┌───────────┐
             │  PATTERN  │ │ DECISION │ │  FAILURE  │
             │ recurring │ │ a choice │ │ a known   │
             │ structure │ │ that was │ │ bad path  │
             │           │ │ made     │ │           │
             └───────────┘ └────┬─────┘ └───────────┘
                                │ promoted (human or verifier)
                                ▼
                          ┌──────────────┐
                          │    POLICY    │  governs behaviour; reviewed; owned
                          │  "production config changes require review"
                          └──────────────┘
```

**Direction of authority runs upward only.** Events justify Episodes; Episodes and Evidence
justify Claims; Claims and human authority justify Decisions and Policies. Nothing lower is ever
edited to match something higher.

## 21.2 Entity definitions

### Event
The atomic record. Never modified, never deleted (payload may be crypto-shredded).
Full schema: `22-event-layer-spec.md`.

### Episode
A bounded stretch of coherent work with a goal and an outcome.

```
Episode {
  id, mission_id, run_id, agent_id, epoch_id
  goal_text                    # natural language, may be model-derived (marked)
  goal_source                  # user_prompt | inferred | task_system
  opened_at, closed_at         # valid time
  outcome                      # resolved | abandoned | failed | superseded | open
  actions[]                    # event ids, ordered
  artefacts_touched[]          # resource refs with content hashes before/after
  evidence_produced[]          # evidence ids
  remedy_signature             # canonical hash of the change attempted — the key the Gate uses
  parent_episode_id            # for nested attempts
}
```

`remedy_signature` is the load-bearing field. It is a normalised fingerprint of *what was
attempted* — the set of (symbol, change-kind) pairs plus a normalised diff shape — so that the
Gate can recognise "you are about to try this again" from the **content** of a proposed change,
not merely from the file path. This is the concrete improvement over path-keyed prior art.

### Evidence
An addressable artefact that can support or contradict a Claim.

```
Evidence {
  id                           # content address (blake3 of canonical payload)
  kind                         # test_result | commit | stack_trace | tool_output
                               # | static_analysis | benchmark | human_statement
                               # | review_comment | incident | doc_excerpt | model_output
  payload_ref                  # pointer into the blob store (encrypted)
  produced_by                  # event id
  actor                        # who/what produced it
  trust                        # from the lattice: trusted | system | untrusted
  attested                     # bool — signature, CI provenance, commit signature
  precision                    # syntactic | indexed | live | deep | n/a
  observed_at                  # valid time
  recorded_at                  # transaction time
  model_derived                # bool — set if any LLM was in its production path
}
```

### Claim
A proposition AEXO holds. This is the centre of the model.

```
Claim {
  id
  statement                    # one sentence, declarative, no imperatives
  polarity                     # asserts | denies
  kind                         # behavioural | structural | operational | causal | preference
  scope {                      # ALL dimensions optional; empty means universal (discouraged)
    components[]               # logical component names
    paths[]                    # glob patterns
    symbols[]                  # fully-qualified symbol ids (resolvable via structure plane)
    environments[]             # production | staging | test | local
    languages[]
    dependencies[]             # name + semver range
    architecture_generation    # opaque token; changes when a migration is recorded
  }
  validity {
    valid_from, valid_until    # valid time; valid_until usually null
    last_verified_at
    reverify_after             # interval; a policy, not a truth
  }
  status                       # candidate | supported | verified | contested
                               # | superseded | retired | scope_unresolved
  confidence_band              # unverified | supported | verified | authoritative
  confidence_score             # deterministic float, RANKING ONLY, never gates
  provenance_depth             # hops to nearest non-model-derived evidence
  evidence_independence        # count of independent derivation ancestries
  supporting_evidence[]        # evidence ids
  contradicting_evidence[]     # evidence ids
  verifier                     # optional executable check
  derived_from[]               # episode ids, claim ids
  supersedes / superseded_by
  created_by                   # actor
  approved_by                  # actor, required for promotion to Decision/Policy
  trust                        # minimum trust across all inputs (taint propagation)
}
```

**Constraint C-1:** `statement` MUST be declarative. The schema has no field that renders as an
imperative. "Do not retry 504s" is not a Claim; "retrying 504s duplicates charges" is. Imperatives
live only in Policies, which require human approval. This is a structural anti-injection control.

**Constraint C-2:** `provenance_depth > 1` with an all-model-derived evidence set is rejected at
admission.

### Decision
A choice a human or an authorised process made, with rationale.

```
Decision { id, statement, rationale, alternatives_considered[], scope,
           decided_by (human required), decided_at, evidence[], adr_ref,
           supersedes / superseded_by, status }
```

### Policy
A Decision with enforcement force. Expressed in the Policy DSL (`29-governance-gate-spec.md`),
not free text, so the Gate can evaluate it deterministically.

```
Policy { id, decision_id, rule_dsl, severity (info|warn|require_ack),
         scope, owner (human), enabled, created_at, review_due,
         acceptance_rate (measured), auto_suppressed (bool) }
```

### Pattern
A recurring structure detected across Episodes: co-change clusters, failure clusters, remedy
families. Always a *candidate* until a Claim is derived from it.

### Verification
An execution of a Verifier against a Claim.

```
Verification { id, claim_id, verifier_ref, started_at, finished_at,
               result (pass|fail|error|skipped), evidence_id, environment,
               commit_sha, runner (ci|local|worker) }
```

### Knowledge State
AEXO's model of **delivered evidence** for one Agent in one Context Epoch. Explicitly not a model
of cognition.

```
KnowledgeState {
  epoch_id
  delivered[]        # { resource_ref, content_hash, delivered_at, byte_range?, token_cost }
  claims_injected[]  # claim ids + receipt id
  compaction_events[] # boundaries, with what was delivered before each
  disputed[]         # claims the agent challenged
}
```

## 21.3 Identity hierarchy

```
Project
  └── Mission            "ship the OAuth migration"        (may span weeks)
        └── Run          one harness execution
              └── Agent  main | subagent | reviewer | job
                    └── Context Epoch   (reset by compact/clear)
                          └── Action    one tool call
```

Every event carries the full path. This is what makes subagent handling correct rather than
approximate — see `2B-multi-agent-identity-model.md`.

## 21.4 Lifecycle rules

| Entity | Created by | Mutable fields | Deleted |
|---|---|---|---|
| Event | Capture plane only | none (payload shreddable) | never |
| Episode | Consolidator | `outcome`, `closed_at` until closed | never |
| Evidence | Capture / verifier | none | never |
| Claim | Reflection (candidate) or human | status, confidence, validity, evidence links | never — `retired` instead |
| Decision | Human | status, supersession | never |
| Policy | Promotion from Decision | enabled, severity, acceptance_rate | never — disabled instead |
| Pattern | Detector | recomputed wholesale | freely (derived) |
| Verification | Verifier runner | none | tiered out per retention |
| Knowledge State | Projection plane | append-only within epoch | with the epoch's retention tier |

**Nothing is deleted to fix a mistake.** A wrong Claim is `retired` with a reason and a
superseding Claim. The record of having believed it is itself valuable — it is how post-mortems
of agent behaviour become possible.
