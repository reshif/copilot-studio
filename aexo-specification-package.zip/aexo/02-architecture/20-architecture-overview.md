# 20 — Architecture Overview

## 20.1 The five planes

```
┌───────────────────────────────────────────────────────────────────────────────┐
│                              AGENT HARNESS                                     │
│      Claude Code · Codex · Managed Agents · custom · CI bots · humans          │
└───────┬───────────────────────────────────────────────────────▲───────────────┘
        │ hooks · MCP · OTel spans · shell · fs · git · LSP · CI │ context bundles
        ▼                                                       │ + evidence receipts
┌───────────────────────────────────────────────────────────────┴───────────────┐
│  ① CAPTURE PLANE                              ⑤ PROJECTION PLANE               │
│  ────────────────                             ──────────────────               │
│  aexo-hook (Rust, <3ms)                       Intent parser                    │
│  Harness adapters                             Candidate assembly               │
│  OTel GenAI ingest                            Budgeted selection (knapsack)     │
│  Shell / fs / git / LSP / CI collectors       Volatility ordering (cache-safe)  │
│  Normaliser → Canonical Activity Event        Delta computation                 │
│  Reconciliation loop → coverage_gap events    Receipt generation                │
└───────┬───────────────────────────────────────────────────────▲───────────────┘
        │ append                                                 │ query
        ▼                                                        │
┌───────────────────────────────────────────────────────────────┴───────────────┐
│  ② EVENT PLANE — the only source of truth                                      │
│  Append-only · hash-chained · bitemporal · content-addressed payloads          │
│  Per-payload encryption keys (crypto-shred) · single append path (redaction)    │
│  Replay API · integrity verification · retention tiering                        │
└───────┬───────────────────────────────────────────────────────▲───────────────┘
        │ fold (deterministic)                                   │ reads
        ▼                                                        │
┌───────────────────────────────────────────────────────────────┴───────────────┐
│  ③ EXPERIENCE PLANE — derived, rebuildable                                     │
│  Episodes · Evidence · Claims · Decisions · Failures · Verifications ·          │
│  Patterns · Relationships · Knowledge State per Context Epoch                   │
│  Evidence Graph (PROV-DM + SUPPORTS/CONTRADICTS/VERIFIES/SUPERSEDES)            │
└───────┬───────────────────────────────────────────────────────▲───────────────┘
        │                                                        │
        ▼                                                        │
┌───────────────────────────────────────────────────────────────┴───────────────┐
│  ④ JUDGEMENT PLANE                                                             │
│  Trust lattice & taint propagation · Provenance-depth limits                    │
│  Verifier runner · Validity engine · Contradiction detector · Supersession      │
│  Confidence function (deterministic) · Pre-action Gate · Promotion workflow     │
└────────────────────────────────────────────────────────────────────────────────┘

        ┌──────────────────────────────────────────────────────────────┐
        │  ⑥ CONTROL PLANE (cross-cutting)                              │
        │  Health & degradation · Observability Completeness SLO ·      │
        │  Cost accounting (net-of-cache) · Eval harness & shadow mode  │
        │  Config · Tenancy · RBAC · Audit export                       │
        └──────────────────────────────────────────────────────────────┘

        ┌──────────────────────────────────────────────────────────────┐
        │  ⑦ STRUCTURE PLANE (integration, not ownership)               │
        │  tree-sitter · SCIP/LSIF · LSP · CodeQL/CPG · git             │
        │  Uniform provider interface + precision labels                 │
        └──────────────────────────────────────────────────────────────┘
```

## 20.2 The data lifecycle, end to end

```
 An agent runs `rg "retry" src/`
        │
        ▼
 aexo-hook (PreToolUse) writes 180 bytes to a Unix socket in 1.4ms and exits 0
        │
        ▼
 aexo-daemon normalises → Canonical Activity Event
   { actor: agent:claude-code:s7f2, operation: SEARCH, resource: src/**,
     query_hash: …, caused_by: evt_00891, epoch: 2, trust: system }
        │
        ▼
 Event Plane appends: id = blake3(canonical_json(event) || prev_hash)
   payload encrypted under content key K_repo; envelope in the chain
        │
        ▼
 Episode consolidator (async) groups the search with the subsequent reads and
 the edit that followed into Episode ep_0412 "investigate 504 retry behaviour"
        │
        ▼
 Verification collector observes the test run that followed → Evidence ev_2288
 (attested, non-model-derived, precision: live)
        │
        ▼
 Claim candidate proposed by reflection: "Retrying payment 504s duplicates charges"
   status: candidate · provenance_depth: 1 · evidence: [ev_2288, commit a8193]
   scope: { component: checkout/payment, env: production, dep: stripe@^12 }
        │
        ▼
 Judgement: verifier attached (`pytest tests/payment/test_retry_idempotency.py`)
   → runs → passes → status: verified · confidence band: verified
        │
        ▼
 Next session, agent intent = "fix OAuth state mismatch"
   Projection Engine scores the Claim: scope does not overlap → NOT injected.
   (Under a recency-bounded digest it would have been. This is the whole point.)
        │
        ▼
 Agent intent = "add retry to checkout"
   Projection Engine injects it, with receipt:
   [claim:cl_0731 · verified 3d ago · evidence: 1 test, 1 commit · scope: checkout/payment]
        │
        ▼
 Agent proceeds. Gate fires PreToolUse on Edit(checkout/payment_client.py):
   deterministic lookup → 1 verified Claim, 2 prior failed attempts → warning + citations
```

## 20.3 Process topology (local deployment)

| Process | Language | Lifetime | Responsibility |
|---|---|---|---|
| `aexo-hook` | Rust | milliseconds, per invocation | Serialise the hook payload, write to socket, exit. Nothing else. |
| `aexo-daemon` | Rust | resident | Socket server, normalisation, append path, redaction, hash chain, fs/git watchers, structure indexer, Gate lookups |
| `aexo-server` | Python | resident | MCP server, REST/OpenAPI, projection engine, contradiction engine, reflection orchestration, dashboard |
| `aexo` (CLI) | Rust | per invocation | init, doctor, verify, replay, query, export, score |
| `aexo-worker` | Python | scheduled | Verifier runs, Episode consolidation, Claim candidates, re-verification sweeps |

The daemon owns everything on the latency-critical path. The Python server owns everything that
thinks. They communicate over the event store and a local gRPC socket, never by sharing mutable
files.

## 20.4 Why the split is drawn here

**Everything in the agent's critical path is Rust and does no thinking.** A `PreToolUse` gate
lookup is a bounded index probe against an in-memory structure. A capture write is a socket
send. Neither may parse, allocate large, or block. This is what makes AEXO survivable at 300+
tool calls per session (see `01-research/14-harness-landscape.md` §14.6).

**Everything that thinks is Python and is never in the critical path.** Projection assembly runs
at session start and on explicit tool call, where a 120ms budget is generous. Episode
consolidation, Claim extraction and contradiction triage run asynchronously. Nothing the agent
does waits on them.

**Everything authoritative is a fold over the log.** If `aexo-server` is down, the daemon still
captures and the Gate still works from its last-built index. If the daemon is down, the hook
falls back to appending to a local queue file that the daemon drains on restart. If everything is
down, the hook exits 0 in under a millisecond and the agent is unaffected — but a health event is
recorded and the next successful session start tells the agent its memory was degraded.

## 20.5 Failure semantics, stated precisely

| Failure | Agent impact | Observable signal |
|---|---|---|
| Hook cannot reach daemon | none (exit 0 within budget) | Queue file grows; `coverage_gap` on drain; health state `DEGRADED` |
| Daemon crash | none | systemd/launchd restart; gap recorded with a duration; completeness metric drops |
| Event store corruption | capture halts, agent unaffected | `aexo verify` fails; health state `FAILED`; session start injects a degraded-memory notice |
| Server down | no projections, no MCP tools | Harness sees MCP server unavailable; SessionStart injects last known good minimal bundle |
| Verifier infrastructure down | Claims stop refreshing | Claims age into `stale` after the re-verification window; confidence bands drop; this is *correct* behaviour, not a failure |
| Structure provider unavailable | lower-precision answers | Precision label degrades to `syntactic`; Claims grounded in it get lower confidence |

The invariant: **AEXO's failure never becomes the agent's failure, and never becomes the
operator's surprise.**

## 20.6 What is deliberately simple

- **No message broker.** A Unix socket and an append-only file. A broker can be added at the
  enterprise tier for fan-out; it is not needed for correctness.
- **No distributed consensus.** Single-writer per repository via the daemon. Team merge is an
  offline log-merge operation (see `2C`).
- **No graph database required.** The Evidence Graph is modest in size (thousands to low
  millions of nodes per repository) and lives in SQL with recursive CTEs. An embedded graph
  engine is an optimisation, evaluated only if query latency demands it.
- **No vector database required.** Optional, opt-in, behind an interface.
- **No LLM in the authoritative path.** Ever.
