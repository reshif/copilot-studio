# 2E — Technology Selection (ADRs)

Every decision below has a real alternative, a stated rationale, and a revisit trigger.

---

## ADR-001 — Language split: Rust for the hot path, Python for the control plane

**Context.** Hooks execute before every tool call. A Python process with imports cold-starts in
150–400ms; at 300 tool calls per session that is 45–120 seconds of added latency, which is why
harness-integrated tools get uninstalled. Meanwhile the thinking parts of the system —
projection, contradiction, reflection orchestration, schema modelling — benefit enormously from
Python's ecosystem.

**Options.**
| Option | Verdict |
|---|---|
| All Python | **Rejected.** Fails the latency budget by an order of magnitude |
| All Rust | Rejected. Slower to build the analytical layer; smaller hiring pool; no meaningful benefit off the hot path |
| All Go | Viable. Adequate start-up, simple deployment, good concurrency. Weaker for the parsing/tree-sitter integration and a weaker data/ML ecosystem |
| **Rust hot path + Python control plane** | **Chosen** |

**Decision.** `aexo-hook`, `aexo-daemon` and `aexo` (CLI) in Rust. `aexo-server` and
`aexo-worker` in Python 3.12+. Communication over Unix socket and gRPC; never shared mutable
files.

**Consequences.** Two toolchains, two CI pipelines, a shared schema definition (Protobuf +
JSON Schema generated into both). Accepted, because the alternative is a product people disable.

**Revisit when:** the team lacks Rust capability at Phase 0 — fall back to Go (Q10 in
`01-research/18-open-questions.md`).

---

## ADR-002 — Python web framework: FastAPI, with Litestar as the documented alternative

**Context.** The control plane serves REST, MCP over HTTP, and the dashboard. Throughput is
modest (hundreds of requests per second at most); developer velocity and schema tooling matter
far more.

**Evidence.** Litestar's msgspec-based serialisation benchmarks materially faster than Pydantic
and real migrations report large throughput gains; BlackSheep is faster still on raw throughput.
But under realistic database-backed workloads the gap between mature ASGI frameworks narrows to
within network and database variance, and the honest summary in 2026 practitioner analyses is
that Litestar wins synthetic charts while FastAPI wins most real production decisions.

**Decision.** **FastAPI** with Pydantic v2, served by Uvicorn (Granian evaluated if the
application server is ever a confirmed bottleneck).

**Rationale.** AEXO is not throughput-bound; it is correctness- and schema-bound. FastAPI's
ecosystem, OpenAPI generation, hiring pool, and Pydantic's integration with the schema-heavy
domain model dominate. The service layer is framework-agnostic by construction — all endpoints
are thin adapters — so a migration to Litestar is a contained change if it is ever justified.

**Revisit when:** measured p99 API latency exceeds budget *and* profiling attributes it to
framework overhead rather than to storage.

---

## ADR-003 — Event log format: JSONL segments, not a database table (locally)

**Context.** The log is the source of truth and must be legible, greppable, diffable, git-native
and independent of any database's on-disk format.

**Decision.** Newline-delimited JSON in size-and-time-sealed segments, zstd-compressed once
sealed, with the open segment uncompressed and fsync-appended.

**Rationale.** Plain text is reviewable in a pull request, survives every tool the team already
trusts, and cannot be corrupted by a database version upgrade. The derived index provides the
query performance. This mirrors the design choice the closest prior art converged on
independently, for the same reasons.

**Revisit when:** a single repository's log exceeds 50GB, at which point segment indexing may need
to move into the derived tier more aggressively.

---

## ADR-004 — Hashing: BLAKE3 over canonical JSON (RFC 8785)

**Decision.** Chain and content hashes are BLAKE3 over RFC 8785 canonical JSON of the envelope,
with the algorithm tagged in the field so migration is possible.

**Rationale.** Canonical serialisation is what makes cross-platform determinism testable
(AC-EVT-9). BLAKE3 is fast enough that hashing is never the bottleneck at 50,000 events/second.

---

## ADR-005 — No vector database in the core

**Decision.** No embeddings on the authoritative path. An optional, opt-in local index (LanceDB or
SQLite-VSS) provides fuzzy free-text search over Episode narratives only.

**Rationale.** Determinism, legibility and zero read-time model cost are worth more at the core
than fuzzy recall. Scope-based candidate generation plus deterministic scoring is reproducible,
explainable and unit-testable; top-k semantic retrieval is none of those. This is a deliberate
trade of recall breadth for trustworthiness, and it matches the explicit position of the closest
prior art.

**Revisit when:** the eval harness shows measurable ESK improvement from semantic candidate
generation that scope-matching does not capture.

---

## ADR-006 — No graph database initially

**Decision.** The Evidence Graph lives in two SQL tables with recursive CTEs.

**Rationale.** Per-repository graphs are thousands to low millions of nodes. Introducing a graph
engine adds an operational dependency and a second query language for a problem SQL solves.

**Revisit when:** p99 traversal latency exceeds 100ms on a real corpus.

---

## ADR-007 — Tree-sitter as the mandatory structure tier

**Decision.** tree-sitter for file-incremental structure; SCIP/LSP/CodeQL as optional
higher-precision tiers behind one interface.

**Rationale.** SCIP requires full graph reconstruction on repository update, which is
incompatible with an incremental hot path; tree-sitter is incremental, error-tolerant, and
covers essentially every language. Precision labels carry the difference into the confidence
model rather than hiding it.

---

## ADR-008 — OpenTelemetry GenAI as the strategic capture transport

**Decision.** Ship an OTLP receiver mapping GenAI spans to Canonical Activity Events, with a
pinned convention version and a per-version translation table.

**Rationale.** It converts adapter-writing from an O(harnesses) problem into an O(1) problem, and
it makes AEXO exportable into the customer's existing observability stack. The risk — the
conventions are pre-stable with no 1.0 and names change between versions — is bounded by pinning
and normalising on ingest.

---

## ADR-009 — Bitemporal from day one

**Decision.** Every event carries both `observed_at` and `recorded_at`.

**Rationale.** Retrofitting bitemporality is close to impossible; the historical data simply is
not there. It is required for late-arriving evidence to be handled correctly, for "what did we
believe on date D", and for the compliance deliverable. The cost is one extra timestamp field.

---

## ADR-010 — Crypto-shredding rather than physical deletion

**Decision.** Per-payload content keys; erasure destroys the key, not the record.

**Rationale.** The only way to satisfy both an immutable, verifiable audit chain and a right to
erasure. The trade — key loss is unrecoverable data loss — is accepted and prominently
documented.

---

## ADR-011 — Deterministic Gate, no model call

**Decision.** The pre-action Gate is a lookup. No inference, no network.

**Rationale.** Reproducibility, explainability, unit-testability, zero latency, zero cost, and
immunity to prompt injection in the gating path itself. Model-trained gates in the guardrail
literature target generic safety categories and are nondeterministic by construction; a
project-specific gate keyed to that project's own recorded failures does not need a model.

---

## ADR-012 — Bands over thresholds for confidence

**Decision.** Gating uses named bands assigned by rule; the numeric score is for ranking only.

**Rationale.** A band is explainable in one sentence to a user and an auditor. A float invites the
failure mode where a model's confidence becomes the system's confidence — the poisoned-confidence
risk documented in the security literature.

---

## ADR-013 — Local-first, server-optional

**Decision.** Full functionality offline on one machine with no network egress; enterprise
features are strictly additive.

**Rationale.** It is the only architecture that works for sensitive and proprietary code, for
air-gapped environments, and for individual adoption — and individual adoption is how developer
tools spread inside organisations. It also removes an entire class of security concern: MCP
security literature concerns untrusted, network-reachable servers, and a local, read-mostly,
auditable server sidesteps it.

---

## ADR-014 — Reflection calls a provider API directly, not MCP Sampling

**Decision.** The reflection worker calls the model provider's API directly.

**Rationale.** Sampling is deprecated in MCP 2026-07-28, with new implementations advised toward
direct provider APIs. Building on a deprecated feature would incur a migration within the
deprecation window for no benefit.

---

## Dependency budget

A stated constraint, because dependency sprawl is how local-first tools become unshippable.

| Component | Max runtime dependencies | Rationale |
|---|---|---|
| `aexo-hook` | **0** | Statically linked; must start instantly |
| `aexo` CLI | ≤ 8 crates | Must install anywhere |
| `aexo-daemon` | ≤ 25 crates | tree-sitter grammars counted as one |
| `aexo-server` | ≤ 12 packages | FastAPI, Pydantic, uvicorn, httpx, OTel SDK, MCP SDK, and storage drivers |

Any PR that adds a dependency must justify it in the description against this budget.
