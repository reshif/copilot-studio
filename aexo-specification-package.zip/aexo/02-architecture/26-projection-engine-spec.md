# 26 — Projection Engine Specification

The Projection Engine is the only component that puts tokens in front of a model. Every rule in
`01-research/13-token-economics.md` lands here.

## 26.1 From recency-bounded to relevance-bounded

A fixed digest buys items in priority order until the budget runs out: status file, last N
do-not-repeat entries, M recent bugs. It is deterministic and safe, and it is wrong, because
newer is not the same as relevant. Fixing an OAuth state mismatch should not consume budget on
five payment bugs merely because they are recent.

```
   intent  ──►  candidate generation  ──►  scoring  ──►  budgeted selection
                                                              │
                                          volatility ordering ▼
                                          delta computation
                                          receipt generation
                                                              │
                                                              ▼
                                                     context bundle
```

## 26.2 Intent

Intent is derived, cheaply and deterministically first:

| Source | Signal |
|---|---|
| The user prompt text | keywords, symbol mentions, file paths, error strings |
| Files already open or recently touched in this epoch | strong locality signal |
| The current git branch name and its diff | strong |
| The active task/issue reference | strong |
| An explicit `aexo.focus(...)` tool call | authoritative |
| The tool call about to be made (Gate context) | authoritative, narrow |

An LLM may enrich intent (naming the component, classifying the task kind), but the deterministic
signals alone must produce a usable projection — the same "no LLM is load-bearing" test.

## 26.3 Candidate generation

```
candidates =
    claims  whose scope overlaps the intent scope
  ∪ claims  scoped to symbols in the current diff or open files
  ∪ episodes with a remedy_signature or remedy_family matching the proposed change
  ∪ failures on artefacts in the intent scope
  ∪ decisions in the intent scope, not superseded
  ∪ policies applicable to the intent scope        (always included — see §26.6)
  ∪ deltas for artefacts the agent has seen whose content hash has changed
  ∪ health/degradation notice                       (always included if not healthy)
```

Excluded at generation, never scored: `superseded`, `retired`, `scope_unresolved`, out-of-version
dependency scopes, and anything failing the tenant boundary.

## 26.4 Scoring

Every candidate gets a deterministic score:

```
score = w1·relevance          # scope overlap depth + symbol/path match specificity
      + w2·trust_band         # authoritative 1.0 | verified .8 | supported .5 | unverified .2
      + w3·verification_recency
      + w4·novelty            # 0 if already delivered in this epoch with the same content hash
      + w5·consequence        # historical cost of ignoring this class (measured, not guessed)
      − w6·token_cost_norm
      − w7·contested_penalty
```

`novelty` is the mechanism that replaces duplicate-read suppression: content already delivered in
this epoch scores zero unless it has changed, in which case only the delta is a candidate.

`consequence` is *measured*: for each warning class, AEXO tracks how often ignoring it preceded a
failure. Classes that never precede failures decay toward zero and stop consuming budget. This is
Rule R4 made mechanical.

## 26.5 Budgeted selection

This is a knapsack. Exact solutions are unnecessary; a greedy-by-density pass with a
diminishing-returns adjustment is sufficient and fast.

```
select(candidates, budget):
    sort by score / token_cost descending
    while budget remains:
        take next candidate c
        apply redundancy discount: if c's evidence set overlaps an already-selected
          candidate's by >60%, multiply c's score by 0.4 and re-sort
        if c fits: take it, decrement budget
    always include: policies, health notice, receipt   (reserved budget, see below)
```

**Reserved budget.** Before the general knapsack runs, fixed allocations are taken:

| Reserved | Default | Reason |
|---|---|---|
| Health/degradation notice | 40 tokens | The agent must know how much to trust its memory |
| Applicable policies | up to 250 tokens | Governance is not subject to competition |
| Evidence receipt | up to 120 tokens | Provenance is a hard requirement (P4) |
| Delta block | up to 40% of the budget | The highest-value class |

**Budget determination.** The bundle budget is not a constant. It is:

```
budget = min( configured_max,
              remaining_context_fraction × harness_reported_window × safety_factor,
              expected_value_break_even(turns_remaining) )
```

The third term is the economics: injecting `B` tokens costs `B × (1.25 + 0.1(T−1))`, so in a long
session the budget should *shrink*, not grow. This inverts the naive intuition and is a genuine
differentiator.

## 26.6 Volatility ordering — the cache-safety rule

Within any assembled block, content is emitted in strict volatility order:

```
1. IMMUTABLE      project identity, repository fingerprint            (never changes)
2. STABLE         active policies, architectural decisions            (changes on promotion)
3. SLOW           component map, ownership, key invariants            (changes on migration)
4. MEDIUM         verified claims relevant to the intent              (changes on verification)
5. VOLATILE       episode-specific: recent failures, deltas, health   (changes constantly)
```

Consequence: when the bundle is regenerated, sections 1–3 usually produce byte-identical output,
so the provider's prefix cache survives up to the first changed byte. A naive assembler that
interleaves volatile content invalidates everything.

**Hard rule (from R1):** a bundle may be placed in the prompt prefix **only** at session start,
before the first cacheable write. All within-session delivery is tail-placed: as a tool result,
or appended to the user turn via the harness's context-injection field. Prefix mutation
mid-session is a defect, and is asserted against in the cache-safety test suite.

## 26.7 Delta injection

The replacement for duplicate-read prevention.

```
on read/gate of resource R by agent A in epoch E:
    last = knowledge_state[E].delivered[R]
    if last is absent           → allow full read (record delivery)
    if last.hash == current     → supply nothing; record a prevented read with its
                                   token value at the lifetime multiplier
    if last.hash != current     → compute unified diff (last.hash → current)
                                   if diff_tokens < full_tokens × delta_threshold (default .5)
                                       → supply diff with a header naming both hashes
                                       → record prevented tokens = full − diff
                                   else → allow full read (the diff isn't worth it)
```

The diff header names both content hashes so the agent can reason about what it is seeing, and so
that a later audit can reconstruct exactly what the agent was shown.

**Modes** (per `01-research/13-token-economics.md` §13.5):

| Mode | Behaviour | Default |
|---|---|---|
| `observe` | Record only, inject nothing | **Yes, for the first 14 days** |
| `delta` | Supply diffs, allow full reads when the diff is not worth it | Yes, thereafter |
| `warn` | Emit a warning, allow the read | No — labelled as costing tokens |
| `deny` | Block, with an explicit override tool available | Opt-in, per path glob |

**Subagents are exempt from `deny` by default.** They share disk state but not context: denying a
subagent a read because the parent already read it starves an agent that genuinely does not have
the content. This observation from prior art is correct and is encoded as a hard default. Under
the identity model (`2B`), the check is per Context Epoch, so the exemption falls out of the model
rather than needing a special case.

## 26.8 Two delivery shapes

**Shape A — the bundle.** Assembled text, injected at session start or post-compaction. Small by
default (target 600–1,200 tokens). Orientation, not encyclopaedia.

**Shape B — the query tools.** The primary interface. Just-in-time retrieval beats pre-loading on
both quality and cost, and a tool costs zero tokens on the turns where it is not called.

```
aexo.recall(intent, budget)          → scored, budgeted bundle for a stated intent
aexo.why(claim_id, depth)            → explanation
aexo.history(resource_ref)           → episodes and failures touching a resource
aexo.check(proposed_change)          → gate result without performing the change
aexo.evidence(claim_id)              → supporting/contradicting sets
aexo.dispute(claim_id, reason, refs) → open a contradiction
aexo.focus(scope)                    → set intent explicitly
aexo.delta(resource_ref)             → what changed since I last saw this
aexo.budget()                        → remaining context and AEXO's cost so far
```

Where the harness supports programmatic tool calling, AEXO additionally exposes the experience
store as a **queryable object inside the sandbox**, so the agent can filter and aggregate in code
and return only the result — keeping bulk out of the window entirely. This is the highest-leverage
integration available and it is Phase 3 scope.

## 26.9 Post-compaction behaviour

When compaction occurs (detected via the harness's compaction hook or an OTel span):

1. Close the Context Epoch; open a new one.
2. **Do not** assume the agent has forgotten specific facts — that is unknowable.
3. Record what was *delivered* in the closed epoch (Knowledge State is per epoch, so this falls
   out).
4. Inject a small post-compaction bundle: a receipt of what was delivered before, the active
   intent, the applicable policies, and a pointer to `aexo.recall` for anything else.
5. Never re-inject bulk content automatically. Compaction exists to reduce context; re-inflating
   it defeats the purpose and costs at the lifetime multiplier.

This is the corrected version of "mark previously read files as compacted." The system tracks
delivered evidence and makes it *recoverable on request*, rather than guessing at cognition.

## 26.10 The receipt

Every bundle ends with a compact manifest:

```
[aexo] 4 claims · 1 delta · 2 policies · memory: healthy (coverage 96.4%)
  cl_0731 verified 3d  checkout/payment  "retrying 504s duplicates charges"
  cl_0812 supported    checkout/**       "queue insert precedes provider call"
  cl_0644 contested ⚠  checkout/payment  "provider A requires 504 retry"
  cl_0203 authoritative  *               "production config changes require review"
  Δ src/payment/client.py  a91f→c30d  (3 hunks)
  why: aexo.why(<id>) · dispute: aexo.dispute(<id>, reason, evidence)
```

Cost: roughly 90–120 tokens. It buys: attribution, the ability to dispute, visible contestation,
and an honest degradation signal. This is the cheapest high-value block in the bundle.

## 26.11 Acceptance criteria

**AC-PROJ-1.** Given an intent of "fix OAuth state mismatch" and a store containing five recent
payment-scoped Claims and one OAuth-scoped Claim, when a bundle is assembled, then the
OAuth-scoped Claim is included and none of the payment Claims is.

**AC-PROJ-2.** Given the same store and no discernible intent, when a bundle is assembled, then it
falls back to scope-of-current-diff, then to repository-level policies only — and it does **not**
fall back to "most recent N items".

**AC-PROJ-3.** Given a bundle assembled twice in the same session with only volatile content
changed, when the two renderings are compared, then every byte up to the first VOLATILE section is
identical.

**AC-PROJ-4.** Given a session in progress, when any within-session injection occurs, then it is
placed in the tail (tool result or user-turn append) and never modifies the established prefix.
A test asserts that the prefix content hash is unchanged across the injection.

**AC-PROJ-5.** Given an agent that read `client.py` at hash `a91f` earlier in the epoch and the
file is now `c30d` with three changed hunks, when the agent reads it again in `delta` mode, then
it receives a diff naming both hashes, and the prevented tokens are recorded at the lifetime
multiplier for the current turn index.

**AC-PROJ-6.** Given the same situation where the diff would exceed half the file's tokens, when
the agent reads, then the full file is supplied and the event records why the delta was declined.

**AC-PROJ-7.** Given a subagent that has never been delivered a file which the parent has read,
when the subagent reads it in `deny` mode, then the read is allowed, because the Knowledge State
is per Context Epoch and the subagent has its own.

**AC-PROJ-8.** Given a session with 60 turns elapsed and a configured maximum budget, when a
bundle is assembled, then the computed budget is strictly smaller than the budget computed at turn
2 for the same intent, because the lifetime multiplier is larger.

**AC-PROJ-9.** Given AEXO's health state is `DEGRADED`, when any bundle is assembled, then the
degradation notice is present regardless of budget pressure, naming the current observability
completeness figure.

**AC-PROJ-10.** Given any bundle containing at least one Claim, when the bundle is rendered, then
a receipt is present listing every Claim id, its band, its scope and its contested status, and the
receipt is never dropped for budget.

**AC-PROJ-11.** Given a warning class whose measured acceptance rate falls below the configured
floor, when bundles are assembled thereafter, then that class is auto-suppressed and the
suppression is recorded and visible in the dashboard.

**AC-PROJ-12.** Given a compaction event, when the next bundle is assembled, then it contains a
delivery receipt and a pointer to the recall tool, and it does not automatically re-inject any
previously-delivered file content.

**AC-PROJ-13.** Given a bundle assembly, when the total time is measured at p99 over a thousand
runs on a repository of 100,000 files, then it is under 400ms.

**AC-PROJ-14.** Given identical inputs — same log, same intent, same budget, same weight-set —
when a bundle is assembled twice, then the two bundles are byte-identical, proving assembly is
deterministic.
