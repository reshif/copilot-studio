# 2B — Multi-Agent Identity Model

## 2B.1 Why `session → reads` is not enough

A flat session model cannot express: a subagent that shares disk but not context; a compaction
that resets what an agent knows without ending the session; a reviewer agent from a different
harness contributing to the same goal; a background job whose findings should roll up; or a
mission that spans a fortnight and thirty sessions.

Every one of these produces a wrong answer under a flat model, and the wrong answers are the
expensive kind: starving a subagent of context it never had, or assuming an agent remembers
something compaction discarded.

## 2B.2 The hierarchy

```
Project                 stable, tied to a repository or a set of repositories
  └── Mission           a unit of intent: "ship the OAuth migration"
        └── Run         one harness execution
              └── Agent one reasoning entity: main | subagent | reviewer | job
                    └── Context Epoch   a span between context resets
                          └── Action    one tool call
```

Every event carries the full path. Identity is assigned by the daemon from ambient session
context, so adapters do not need to construct it.

## 2B.3 Entity semantics

**Project.** Detected from the git root. Multiple repositories can be bound to one Project
explicitly, for monorepo-adjacent setups.

**Mission.** The unit that gives cross-session continuity. Created explicitly (`aexo mission
start "…"`), inferred from a branch name matching a task pattern, or inferred from an issue
reference in prompts. If none can be inferred, a default per-day mission is used — a Mission is
never absent, because Missions are how Episodes group across Runs.

**Run.** One harness execution. Begins at `SessionStart`, ends at `SessionEnd` or on a timeout
after the last observed activity.

**Agent.** A distinct reasoning entity. Created for the main agent at Run start and for each
subagent on spawn. An agent from a different harness contributing to the same Mission is a
separate Agent under a separate Run, linked by `mission_id`.

**Context Epoch.** The critical addition. An Epoch begins at Agent creation and ends at:
compaction, an explicit context clear, a resume from a persisted session, or an explicit reset.
Each Epoch has its own **Knowledge State**.

**Action.** One tool call or derived operation.

## 2B.4 Knowledge State is per Epoch

```
KnowledgeState(epoch_id) {
  delivered[]        # resource_ref → { content_hash, delivered_at, ranges, token_cost }
  claims_injected[]  # claim_id → { receipt_id, band_at_injection, injected_at }
  disputes[]
  compaction_boundary_at?
  predecessor_epoch_id?
}
```

Consequences, all of which fall out of the model rather than requiring special cases:

- **A subagent starts with an empty Knowledge State.** It has never been delivered anything, so
  duplicate-read suppression cannot starve it. The exemption that prior art had to special-case is
  structural here.
- **Compaction opens a new Epoch with an empty `delivered` set** and a `predecessor_epoch_id`.
  AEXO knows what was delivered before, does not assume what survived, and can supply any of it on
  request.
- **Delta injection is per Epoch.** "You saw this at hash X" is scoped to the Epoch that saw it.
- **Resume** links a new Epoch to the persisted one, so a resumed session is not treated as a
  fresh agent while also not being assumed to remember everything.

## 2B.5 Delegation and roll-up

When a parent spawns a subagent:

```
DELEGATION { parent_agent_id, child_agent_id, task_text, delegated_at,
             scope_hint, returned_at, result_summary_ref }
```

Roll-up rules:

| What the subagent produced | Rolls up to the Mission? | Rolls up to the parent's Epoch? |
|---|---|---|
| Events | Yes, always | n/a — events are Mission-scoped |
| Evidence | Yes | n/a |
| Episodes | Yes, as nested Episodes | n/a |
| Claim candidates | Yes | n/a |
| **Delivered content** | **No** | **No** — this is the key rule |

The last row is the one that matters: what the subagent *saw* does not become something the parent
has seen. Conflating these is precisely how a memory layer starves the wrong agent.

## 2B.6 Cross-harness missions

Three agents, three harnesses, one Mission:

```
Mission msn_0091 "ship OAuth migration"
  ├── Run run_a  Claude Code       Agent agt_1 (main)
  │                                  ├── Epoch epo_1
  │                                  └── Epoch epo_2  (after compaction)
  │                                Agent agt_2 (subagent: test writer)
  ├── Run run_b  Codex             Agent agt_3 (main)
  └── Run run_c  CI reviewer bot   Agent agt_4 (job)
```

All four contribute events to one Mission. All four see Mission-scoped Claims. None inherits
another's Knowledge State. `agt_3` starting fresh in Codex receives the Claims that `agt_1`
learned, because Claims are Mission- and Project-scoped, not Epoch-scoped — while still being told
nothing about which files `agt_1` happened to have open.

**This separation — knowledge is shared, delivery is not — is the whole content of the identity
model.**

## 2B.7 Concurrency

Multiple agents write to one log concurrently. The design:

- **Single writer.** The daemon is the only process appending. Adapters and hooks send; the daemon
  serialises. This eliminates the contended-write problem entirely rather than mitigating it.
- **No skipped writes.** OpenWolf skipped index updates under lock contention on the assumption a
  later writer would converge state. Final state converged; *history* did not. AEXO does not skip:
  writes queue, and the queue is bounded and monitored. If the queue saturates, that is a health
  event, not a silent drop.
- **Derived state is rebuilt, not merged.** Concurrency affects only the append order, which is
  totally ordered by the single writer. Everything downstream is a deterministic fold.
- **Hybrid logical clocks** are recorded per event so that logs from different machines can be
  merged deterministically later (`2C` §2C.6).

## 2B.8 Acceptance criteria

**AC-ID-1.** Given a main agent that has been delivered `client.py` and then spawns a subagent,
when the subagent reads `client.py`, then the read is permitted in every mode, because the
subagent's Knowledge State is empty.

**AC-ID-2.** Given an agent whose context is compacted, when the next Epoch begins, then its
`delivered` set is empty, its `predecessor_epoch_id` names the closed Epoch, and the closed
Epoch's delivery record remains queryable.

**AC-ID-3.** Given a Claim learned during a Claude Code Run under Mission M, when a Codex Run
begins under the same Mission, then that Claim is available to the Codex agent's projections.

**AC-ID-4.** Given the same setup, when the Codex agent's bundle is assembled, then it contains no
statement or implication about which files the Claude Code agent had open.

**AC-ID-5.** Given three agents writing concurrently at high rate, when the log is inspected, then
every event is present, the sequence is strictly monotonic, and no write was skipped.

**AC-ID-6.** Given the write queue reaching its high-water mark, when saturation occurs, then a
health event is emitted, the state moves to `DEGRADED`, and events are still not dropped until an
explicit, recorded overflow policy triggers.

**AC-ID-7.** Given a subagent that produced a Claim candidate, when the subagent stops, then the
candidate is attached to the Mission and is visible to the parent and to future Runs.

**AC-ID-8.** Given a Run that ends without a clean `SessionEnd`, when the inactivity timeout
elapses, then the Run is closed, its Episodes are finalised with `outcome: abandoned` where no
other outcome is derivable, and a health event records the unclean termination.

**AC-ID-9.** Given no Mission can be inferred, when a Run begins, then a default Mission is
created rather than events being recorded without a Mission.

**AC-ID-10.** Given a resumed session, when the new Epoch is created, then it links to the
persisted Epoch, and the delta computation treats previously-delivered content as delivered to the
predecessor rather than to the current Epoch.
