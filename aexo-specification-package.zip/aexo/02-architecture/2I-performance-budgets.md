# 2I — Performance Budgets

Budgets are contractual. A change that breaches one is a regression, not a trade-off, and CI
enforces them against the reference corpus.

## 2I.1 Reference environments

| Env | Spec | Corpus |
|---|---|---|
| **REF-DEV** | 8-core laptop, 16GB, NVMe | 50,000 files · 2M LOC · 1M events · 20k claims |
| **REF-BIG** | 16-core, 64GB, NVMe | 500,000 files · 20M LOC · 20M events · 200k claims |
| **REF-CI** | 4-core container, 8GB | 10,000 files · 100k events |

## 2I.2 Latency budgets

| Operation | p50 | p95 | p99 | Hard ceiling | Behaviour at ceiling |
|---|---|---|---|---|---|
| `aexo-hook` end to end (capture only) | 1.5ms | 4ms | 8ms | 20ms | Queue to disk, exit 0 |
| `aexo-hook` with Gate verdict | 3ms | 7ms | 10ms | 25ms | Return `allow`, `degraded: true` |
| Gate lookup (daemon internal) | 0.8ms | 2ms | 4ms | 15ms | Return `allow`, `degraded: true` |
| Event append (accepted into queue) | 50µs | 150µs | 400µs | 2ms | Backpressure, health event |
| Event durable (fsync batch) | 2ms | 8ms | 15ms | 100ms | Health event |
| Structure query, syntactic | 0.5ms | 2ms | 5ms | 20ms | Return partial + precision label |
| Structure query, indexed | 2ms | 8ms | 20ms | 100ms | Fall back to syntactic |
| Structure query, live (LSP) | 30ms | 120ms | 300ms | 2s | Fall back to indexed |
| Bundle assembly (`aexo_recall`) | 40ms | 150ms | 400ms | 1s | Ship reserved sections only |
| `aexo_why` summary | 8ms | 30ms | 80ms | 500ms | Return the band + support count |
| Graph traversal (depth ≤5) | 5ms | 25ms | 80ms | 500ms | Truncate, flag truncation |
| Contradiction check (incremental) | 20ms | 100ms | 300ms | 5s | Defer to the async queue |
| Incremental structure reindex (1 file) | 8ms | 25ms | 50ms | 500ms | Defer, mark stale |
| `aexo doctor` | 200ms | 600ms | 1.2s | 3s | — |
| Full derived rebuild, 1M events | — | — | — | 10 min | — |
| Full derived rebuild, 20M events | — | — | — | 90 min | — |

## 2I.3 Throughput

| Metric | REF-DEV | REF-BIG |
|---|---|---|
| Event append sustained | ≥50,000/s | ≥50,000/s |
| Event append burst (10s) | ≥120,000/s | ≥120,000/s |
| Hook invocations sustained | ≥2,000/s | ≥2,000/s |
| Structure reindex, full repository | ≤90s | ≤15min |
| Concurrent agents supported | ≥16 | ≥64 |

## 2I.4 Resource ceilings

| Component | RSS steady | RSS peak | CPU idle | Disk (per 1M events) |
|---|---|---|---|---|
| `aexo-hook` | n/a (transient) | 8MB | n/a | n/a |
| `aexo-daemon` REF-DEV | ≤150MB | ≤300MB | ≤0.5% | — |
| `aexo-daemon` REF-BIG | ≤400MB | ≤512MB | ≤1% | — |
| `aexo-server` | ≤400MB | ≤800MB | ≤0.5% | — |
| Log (compressed) | — | — | — | ≈700MB |
| Blobs | — | — | — | highly variable; deduplicated |
| Derived index | — | — | — | ≈350MB |

**Idle CPU is a hard constraint.** A daemon that spins is a daemon that gets killed. The
filesystem watcher must be event-driven, never polling.

## 2I.5 Token budgets

| Artefact | Target | Ceiling |
|---|---|---|
| Session-start orientation bundle | 600–1,200 | 2,000 |
| Health notice | 25 | 60 |
| Evidence receipt | 90 | 150 |
| `aexo_recall` default response | 400–900 | configurable, hard cap 8,000 |
| Gate warning | 40–90 | 200 |
| Post-compaction bundle | 200–400 | 800 |
| Delta header | 20 | 40 |

**The orientation bundle target is deliberately small.** The design bias is tools over dumps
(Rule R3): a tool costs nothing on turns where it is not called, whereas a bundle costs its full
lifetime multiplier every session.

## 2I.6 Enforcement

- Every budget has a CI benchmark run against the reference corpora on every merge to main.
- A p99 regression >15% on any latency budget fails the build.
- A memory regression >10% fails the build.
- Token budgets are asserted by golden-bundle tests: fixed inputs produce a bundle whose token
  count must stay within range.
- The hook binary's start-up time is measured on macOS, Linux and Windows separately, because
  binary loading characteristics differ materially.

## 2I.7 Known scaling risks and mitigations

| Risk | Trigger | Mitigation |
|---|---|---|
| Contradiction detection is O(n²) in Claims | >50k claims in one scope | Scope-indexed candidate generation; only overlapping scopes are compared; incremental on change only |
| Graph traversal degrades | Deep derivation chains | Depth cap of 5 with truncation flagged; provenance-depth limits keep chains shallow by design |
| Structure index size | Very large monorepos | Per-commit retention limited to N commits plus commits referenced by active Claims |
| Log growth | High-volume agent fleets | Segment sealing + zstd + retention tiering; the log is never summarised (TR3) |
| Rebuild time | Very large logs | Checkpointed folds: periodic derived-state snapshots so a rebuild starts from the last checkpoint, with full-from-genesis rebuild still exercised weekly in CI |
| Hook latency under load | Many concurrent agents | Socket accept queue tuned; daemon uses a lock-free MPSC queue; the hook never waits on the writer |

## 2I.8 Acceptance criteria

**AC-PERF-1.** Given REF-DEV and 10,000 hook invocations, when latency is measured, then p99 for
capture-only is ≤8ms and p99 with a Gate verdict is ≤10ms.

**AC-PERF-2.** Given REF-BIG, when a single file is edited, then incremental structure reindexing
completes within 50ms at p95.

**AC-PERF-3.** Given REF-DEV and 1,000 bundle assemblies, when latency is measured, then p99 is
≤400ms and every bundle is within its token budget.

**AC-PERF-4.** Given the daemon running idle for 24 hours on REF-BIG, when resources are measured,
then RSS is ≤400MB and average CPU is ≤1%.

**AC-PERF-5.** Given a burst of 120,000 events over 10 seconds, when the burst completes, then no
event is dropped, queue depth returns below 50% within 30 seconds, and a health event records the
burst.

**AC-PERF-6.** Given a log of 1M events, when a full derived rebuild runs from genesis, then it
completes within 10 minutes and the result is byte-identical to the incremental state.

**AC-PERF-7.** Given a PR that regresses any p99 latency budget by more than 15%, when CI runs,
then the build fails with the specific budget and measured value named.

**AC-PERF-8.** Given a repository with 200,000 Claims, when contradiction detection runs
incrementally on a new Claim, then it completes within 300ms at p99 by comparing only
scope-overlapping candidates.
