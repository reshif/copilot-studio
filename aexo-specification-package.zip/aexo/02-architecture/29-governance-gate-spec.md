# 29 — The Governance Gate

Memory that answers the agent is useful. Memory that acts on the agent's next action is a
different and stronger design point. This is AEXO's implementation of it.

## 29.1 What the Gate is and is not

**Is:** a deterministic lookup, keyed to the project's own recorded history and its approved
Policies, evaluated before an action, returning a verdict with citations.

**Is not:** a model call, a safety classifier, or a generic security guardrail. Those exist and
should run alongside; the Gate interface is chainable so that both can veto.

**Determinism is the whole point.** A gate that is a model call is unreproducible, unexplainable
and cannot be unit-tested. AEXO's gate is a lookup: same inputs, same verdict, every time,
with no network call and no inference cost.

## 29.2 Inputs and verdict

```
GateRequest {
  action_kind        # WRITE | EDIT | DELETE | EXEC | COMMIT | MERGE | DEPLOY
  resource_refs[]    # paths, symbols
  proposed_change?   # the diff or command, when available
  identity           # project/mission/run/agent/epoch
  intent?            # current focus
}

GateVerdict {
  decision           # allow | warn | require_ack | deny
  reasons[] {
     rule_id | claim_id | episode_id
     severity
     message         # deterministic template, never model-generated
     citations[]     # evidence ids
     confidence_band
  }
  latency_us
  degraded           # true if the Gate answered from a stale index
}
```

`deny` exists but is **off by default** and only reachable via an explicit Policy with
`severity: deny`, which requires human promotion. AEXO ships with no `deny` policies.

## 29.3 The five checks

Evaluated in order, short-circuiting on the highest severity. All complete within the p99 budget
of 10ms.

**C1 — Repeat-remedy check (the highest-value check).**
Compute the `remedy_signature` of the proposed change. Look it up against Episodes with
`outcome: failed`.

```
exact signature match, ≥1 failed episode        → warn, high confidence
                                                   "This change is shaped like one attempted
                                                    on <date> which failed: <evidence>"
remedy_family match, ≥2 failed episodes          → warn, medium confidence
no match                                         → allow
```

This is content-keyed, not path-keyed. That is what makes the warning specific enough to be
believed rather than dismissed as noise.

**C2 — Claim-scope check.**
Do any `verified` or `authoritative` Claims scope to the touched symbols or paths?

```
verified claim, polarity denies this change class → warn with citation
contested claim in scope                          → warn, flagged contested
supported only                                    → informational, budget-permitting
```

**C3 — Policy check.**
Evaluate applicable Policies from the DSL. This is the only path to `require_ack` or `deny`.

**C4 — Fragility check.**
Statistical, from the event log: churn rate, historical failure density, open issues associated
with the resource, and blast radius from the structure plane intersected with Policy scopes.

**C5 — Trust check.**
Is the proposed change derived from untrusted content? If an agent is about to act on an
instruction traceable to a repository README or a third-party doc excerpt, warn with the source
named. This is the anti-injection check at the action boundary.

## 29.4 The Policy DSL

Free-text rules cannot be evaluated deterministically. Policies are expressed in a small,
total, side-effect-free language.

```
policy "production-config-requires-review" {
  severity = require_ack
  owner    = "platform-team"
  when {
    action in [WRITE, EDIT, DELETE]
    path matches "config/production/**"
  }
  unless {
    actor.kind == human and actor.has_role("release-approver")
  }
  message = "Production configuration changes require review. See ADR-0042."
  cite    = [decision:dec_0042]
  review_due = "2027-02-01"
}

policy "payment-retry-guard" {
  severity = warn
  owner    = "payments-team"
  when {
    action in [WRITE, EDIT]
    symbol under "checkout.payment.**"
    change_touches "retry"
  }
  message = "Retry behaviour in payments is governed by cl_0812 and cl_0644 (contested)."
  cite    = [claim:cl_0812, claim:cl_0644]
}
```

Language properties (all deliberate):
- **Total.** No loops, no recursion, no unbounded operations. Every policy terminates.
- **Pure.** No I/O, no network, no data-egress verbs. A Policy cannot be used to exfiltrate
  (threat T6 in `01-research/16-security-threat-landscape.md`).
- **Typed.** Compiled and type-checked at admission; a malformed policy is rejected, never
  partially applied.
- **Testable.** Every Policy carries example cases that must pass in CI:
  ```
  test "blocks production config edit"   { given EDIT "config/production/db.yaml" → require_ack }
  test "allows staging config edit"      { given EDIT "config/staging/db.yaml"    → allow }
  ```
  A Policy without tests cannot be promoted. **This is the mechanism that makes governance
  reviewable like code.**

## 29.5 Modes

| Mode | Behaviour | Use |
|---|---|---|
| `off` | No gate | Debugging |
| `shadow` | Evaluate, record verdicts, inject nothing | **Default for the first 14 days.** Measures the false-positive rate before anyone is inconvenienced |
| `advisory` | Warn with citations; never block | Default thereafter |
| `enforcing` | `require_ack` policies require acknowledgement | Opt-in per policy |

**Shadow mode is not optional in the rollout.** A deterministic check can flag a file whose past
failure is no longer relevant to a superficially similar but valid change; prior art makes its
warning advisory for exactly this reason. AEXO measures that rate before it ever inconveniences a
user, and it publishes the number.

## 29.6 Warning-acceptance feedback

Every warning's outcome is recorded:

```
warning_outcome = accepted   # agent changed course, or the action was abandoned
                | overridden # agent proceeded and the outcome was fine
                | vindicated # agent proceeded and it failed  ← the payoff case
```

```
acceptance_rate(class)  = accepted / issued
vindication_rate(class) = vindicated / overridden
```

**Auto-suppression:** a warning class whose acceptance rate falls below the floor (default 0.15)
and whose vindication rate is below 0.10 over ≥30 issuances is automatically suppressed, an event
is recorded, and it appears in the dashboard as suppressed with its statistics. This is Rule R4
(`01-research/13-token-economics.md`) made mechanical, and it is the defence against the alert
fatigue that kills every warning system.

**Vindication is the metric that matters for the business case.** "We warned you and you proceeded
and it broke, N times this quarter" is the most persuasive artefact AEXO can produce.

## 29.7 Chaining with other guardrails

```
GateChain: [ aexo_gate, org_security_guardrail, harness_permission_rules ]
verdict = most_restrictive(all verdicts)
```

AEXO never loosens another guardrail's verdict, mirroring the harness constraint that hooks can
tighten policy but never weaken it.

## 29.8 Acceptance criteria

**AC-GATE-1.** Given a Gate lookup on a repository with 50,000 recorded Episodes, when the verdict
is computed, then it returns within 10ms at p99 and involves no model call and no network call.

**AC-GATE-2.** Given a previously-failed Episode whose remedy added a retry loop to `charge()`,
when the agent proposes adding a retry loop with a different retry count to the same function,
then the Gate returns `warn` citing that Episode and its failing evidence.

**AC-GATE-3.** Given the same history, when the agent proposes adding a null check to `charge()`,
then the Gate returns `allow`, because the remedy signature differs.

**AC-GATE-4.** Given the Gate in `shadow` mode, when it would have warned, then nothing is
injected into the agent's context, the verdict is recorded, and the agent's behaviour is
identical to running with the Gate off.

**AC-GATE-5.** Given a Policy without test cases, when promotion is attempted, then it is rejected
and the reason names the missing tests.

**AC-GATE-6.** Given a Policy whose test cases fail, when CI runs, then the build fails and the
Policy is not deployed.

**AC-GATE-7.** Given a warning class with 40 issuances, an acceptance rate of 0.08 and a
vindication rate of 0.02, when the auto-suppression sweep runs, then the class is suppressed, an
event records it, and the dashboard shows it as suppressed with its statistics.

**AC-GATE-8.** Given an agent about to act on an instruction traceable to a repository README,
when the Gate evaluates C5, then it warns and names the untrusted source explicitly.

**AC-GATE-9.** Given AEXO's index is stale because the daemon is catching up, when a Gate lookup
occurs, then it answers from the stale index, sets `degraded: true`, and the verdict message says
so rather than pretending to be current.

**AC-GATE-10.** Given an organisation-level guardrail that denies an action and AEXO that would
allow it, when the chain evaluates, then the result is `deny`.

**AC-GATE-11.** Given identical inputs, when the Gate is invoked one thousand times, then all one
thousand verdicts are byte-identical.

**AC-GATE-12.** Given an agent that received a warning and proceeded anyway, and the resulting
change caused a test failure within the same Episode, when the outcome is classified, then the
warning is recorded as `vindicated` and appears in the vindication report.
