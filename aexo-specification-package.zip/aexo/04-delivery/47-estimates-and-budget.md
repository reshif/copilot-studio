# 47 — Estimates and Budget

## 47.1 Capacity reconciliation

`42-task-backlog.md` totals 1,376 points against 42 weeks and a ramping team. The reconciliation:

| Assumption | Value | Rationale |
|---|---|---|
| Productive days per engineer-week | 3.5 | 70% of 5 days; the rest is review, meetings, context switching, support |
| Points per productive day | 1.0 | One point ≈ one focused engineer-day (`41.3`) |
| Integration overhead | 15% per phase | Cross-area work not itemised as tasks |
| Contingency | 20% | Unknowns, rework, defect fixing |

| Phase | Weeks | FTE | Raw capacity (pts) | Less 15% integ. | Less 20% cont. | Backlog (pts) | Fit |
|---|---|---|---|---|---|---|---|
| P0 | 6 | 4.0 | 84 | 71 | 57 | 318 | ✗ |
| P1 | 6 | 5.0 | 105 | 89 | 71 | 236 | ✗ |
| P2 | 8 | 5.5 | 154 | 131 | 105 | 292 | ✗ |
| P3 | 6 | 5.5 | 116 | 98 | 79 | 178 | ✗ |
| P4 | 6 | 5.5 | 116 | 98 | 79 | 165 | ✗ |
| P5 | 10 | 6.5 | 228 | 194 | 155 | 187 | ✗ |

**The plan as written does not fit.** Stating this plainly is more useful than adjusting the
estimates until it does.

## 47.2 What this actually means

Two honest readings:

**Reading A — the point scale is wrong.** A "point" defined as one engineer-day is a poor unit for
tasks estimated by an architect rather than by the engineer doing the work; empirically such
estimates run 2–3× optimistic on systems work and roughly accurate on integration work. Under this
reading the backlog is closer to 1,376 *ideal* days and the calendar needs roughly 2.4× the
assumed team or duration.

**Reading B — the scope is too large for 42 weeks.** This is the more likely reading, and the more
useful one.

Both readings point to the same corrective options.

## 47.3 Corrective options

### Option 1 — Extend the calendar
42 weeks → **72–78 weeks** at the same team size. Total engineering cost roughly 1.8×. Delivers the
full package as specified.

### Option 2 — Grow the team
Peak 6 → **peak 11–12**. Calendar holds at ~44 weeks. Costs more in absolute terms and risks
coordination overhead exceeding the gain on a codebase this specification-coupled — the critical
path (`41.2`) does not parallelise well below P3.

### Option 3 — Cut to a defensible core (recommended)
Ship P0–P4 and defer P5 entirely.

| Phase | Weeks | Points | Cumulative weeks |
|---|---|---|---|
| P0 | 10 | 318 | 10 |
| P1 | 8 | 236 | 18 |
| P2 | 11 | 292 | 29 |
| P3 | 7 | 178 | 36 |
| P4 | 7 | 165 | 43 |

**43 weeks, peak team 5.5, 1,189 points.** Delivers everything through published effectiveness
evidence. P5 (enterprise) becomes a follow-on of ~14 weeks once there is evidence worth selling.

This is recommended because of TR7: no effectiveness claims without controlled results. Building
multi-tenancy, SCIM and a control plane before knowing whether the core mechanism works is
expenditure ordered by hope. If P4 produces a null result, P5 was wasted; if P4 produces a strong
result, P5 is easy to fund.

### Option 4 — Cut to a testable core (fastest to evidence)
P0 + P1 + the Gate slice of P2 + minimal P3 + P4. Skip: Policy DSL, contradiction tiers 3–4,
LSP/SCIP tiers, dashboard, importers.

**~26 weeks, team 4.** Produces the seeded-defect result and the net-token result. Everything else
is deferred until the central claim survives contact with measurement.

## 47.4 Cost model

Fully loaded engineering cost, expressed as engineer-years so it can be repriced for any market.

| Option | Engineer-years | Calendar | Delivers |
|---|---|---|---|
| 1 — Extend | 8.1 | 78 wk | Everything |
| 2 — Grow | 9.4 | 44 wk | Everything |
| 3 — Core (recommended) | 4.9 | 43 wk | Through published evidence |
| 4 — Testable core | 2.0 | 26 wk | Central claim tested |
| 3 + P5 later | 6.6 | 43 + 14 wk | Everything, sequenced |

## 47.5 Non-engineering costs

| Item | Basis | Notes |
|---|---|---|
| Model spend, reflection (dev) | Low | Summarisation on a small model, batched |
| Model spend, evaluation | **Dominant non-engineering cost** | Paired A/B across 30 repos × N seeds × 2 arms; this is the single largest variable |
| CI compute | Moderate | Performance corpora, REF-BIG rebuilds, weekly genesis rebuilds |
| Corpus construction | 21 pts engineering + mining time | See R-42 |
| Security review | External, one engagement per major phase from P2 | |
| Compliance assessment | External, P5 only | Required before any compliance claim (R-35) |
| Signing and distribution infrastructure | Small, ongoing | |

**Evaluation model spend should be budgeted explicitly and early.** It is the cost most likely to
be discovered late, and the one most likely to be cut under pressure — which would silently convert
Option 3 into a system with no evidence, i.e. back to gap 17.

## 47.6 Recommendation

Take **Option 3**, with **Option 4 as an internal checkpoint at week 26**: if the seeded-defect and
net-token results at that point are null or negative, stop and redesign rather than continuing into
P3 polish and P4 breadth.

Two supporting decisions:

1. **Budget evaluation model spend as a line item from day one**, not as a P4 discovery.
2. **Do not start P5 until P4 has published at least one positive controlled result.** This is a
   funding gate, not a scheduling preference.

## 47.7 Estimation confidence

| Area | Confidence | Why |
|---|---|---|
| Event store, chain, fold | High | Well-understood problems with known solutions |
| Capture and hooks | Medium | Harness API churn (R-20) |
| Shell parser | **Low** | Long tail; timeboxed deliberately |
| Structure indexer | Medium-high | tree-sitter is mature; tiers add integration risk |
| Claim engine | **Low** | Quality is empirical; the estimate covers building it, not making it good |
| Remedy signatures | **Low** | Novel; tuning cost unknown until the corpus exists |
| Projection engine | Medium | Mechanism clear; scoring weights need iteration |
| Policy DSL | Medium | Small language, but totality proofs take longer than expected |
| Evaluation harness | **Low** | Corpus construction is the wildcard (R-42) |
| Enterprise | Medium | Conventional work, well-trodden |

The three low-confidence items on the critical path — shell parser, claim quality, remedy signature
tuning — are exactly the three that determine whether AEXO is better than its predecessors. That is
not a coincidence, and it is the reason for the week-26 checkpoint.
