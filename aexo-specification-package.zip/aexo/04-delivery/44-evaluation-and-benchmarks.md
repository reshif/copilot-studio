# 44 — Evaluation and Benchmarks

The OpenWolf critique ends on gap 17: effectiveness unproven, zero sessions of evidence. That gap
is not closed by shipping more features. It is closed here or not at all.

## 44.1 The claim to be tested

> Injecting provenance-bearing, validity-scoped experience into an agent's context improves task
> outcomes at a defensible net token cost, relative to the same agent without it.

Three testable parts, each of which can fail independently:
1. **Outcome** — task success, turns to resolution, repeat-failure rate.
2. **Cost** — net tokens after injection and cache effects.
3. **Attribution** — that the improvement came from AEXO and not from variance.

A system can pass (2) and fail (1), which is the failure mode most of the category is currently
in: token savings measured, task improvement assumed.

## 44.2 Why the obvious measurement is wrong

**Gross savings is not a result.** "We prevented 40 duplicate reads, saving 12,000 tokens" ignores:
- The tokens spent injecting the warnings and bundles.
- The cache-mutation cost of injections landing inside an established prefix.
- Whether the agent then re-derived the information more expensively another way.
- Whether the prevented read would have changed the outcome.

**The lifetime multiplier cuts both ways.** A read prevented at turn 3 of a 40-turn session is
worth roughly `1.25 + 0.10 × 39 ≈ 5.15×` its face value — but an injection at that same turn costs
the same multiple. Naive accounting under-reports savings by 2–7× *and* under-reports costs by the
same factor. Only the net matters.

**Warn-only modes are net-negative by construction.** If the Gate warns and the agent reads
anyway, you have paid for the warning and paid for the read. This is a measurable prediction, and
`44.6` tests it.

## 44.3 Experiment designs

### D1 — Shadow
AEXO captures, computes verdicts and assembles bundles, then discards them. Nothing is injected.

**Produces:** would-have-fired rates, rediscovery rates, candidate bundle sizes, coverage
completeness — with zero risk and zero token cost.
**Cannot produce:** any outcome claim.
**Role:** establishes the baseline and validates that the signals exist before spending on A/B.

### D2 — Paired A/B
Same task, same repository state, same model version, same seed, run with and without projection.

**Produces:** causal estimates of success delta, turns delta, net token delta.
**Confounds controlled:** task difficulty (paired), model drift (version-pinned), ordering
(randomised), evaluator (blinded where human judgement is used).
**Cost:** the dominant expense of P4.

### D3 — Counterfactual replay
Replay a recorded session; compute what AEXO would have injected and which reads it would have
prevented.

**Produces:** cheap estimates at scale, no model spend.
**Assumption:** agent behaviour is unchanged by injection — which is false in general and must be
stated in every report using it.
**Role:** hypothesis generation and regression detection between expensive A/B runs, never a
headline result.

### D4 — Seeded defect
The design that directly targets the mechanism (`44.4`).

### D5 — Longitudinal field
Opt-in telemetry from real teams over months.

**Produces:** external validity, adoption and retention signal, dispute rates.
**Weakness:** no control group; selection effects.
**Role:** does AEXO survive contact with real work — measured as continued use, not satisfaction
surveys.

## 44.4 The seeded-defect benchmark

This is the benchmark the category does not have. The closest published system in this space names
exactly this as its most valuable missing result: the fraction of injected, previously-failed fixes
that a deterministic gate actually prevents.

**Construction, per repository (~30 total):**

1. Mine commit history for a failed-fix → successful-fix pair: a change that was made, reverted or
   followed by a fix, with the failure signal visible (test failure, revert, follow-up commit
   referencing the breakage).
2. Where real pairs are scarce, synthesise them — and label every instance as `mined` or
   `synthetic`. Reporting must break results out by label, because synthetic defects are easier.
3. Construct a task whose naive approach reproduces the failed fix.
4. Pre-load AEXO with the failed attempt recorded in a **prior Epoch** (so it is genuinely memory,
   not context).
5. Run the task paired: with and without projection, N seeds each.
6. Score: was the failed remedy attempted again?

**Primary metric:** repeat-failure prevention rate.
**Secondary:** false-warning rate (the Gate warned on a fix that would have worked). This is the
metric that keeps the benchmark honest — a gate that warns on everything scores perfectly on
prevention and is useless.

**Corpus composition target:**

| Dimension | Spread |
|---|---|
| Language | ≥6 languages, no language >25% of the corpus |
| Size | Small (<10k LOC) through large (>1M LOC) |
| Defect class | Logic, config, dependency, concurrency, API misuse, test-only |
| Provenance | Mined vs synthetic, reported separately |

## 44.5 Metrics

| Metric | Definition | Design |
|---|---|---|
| **ESK** | Evidence sufficiency per kilotoken — of the facts required to complete the task correctly, the fraction present in context, per 1,000 tokens of context spent | D2 |
| **Repeat-failure prevention** | Of seeded previously-failed remedies, the fraction not repeated | D4 |
| **False-warning rate** | Of Gate warnings, the fraction where the warned action was correct | D4, D5 |
| **Task success delta** | Paired difference in success rate | D2 |
| **Turns-to-resolution delta** | Paired difference in turns | D2 |
| **Net token delta** | Avoided − injected − cache-mutation cost | D2, D3 |
| **Rediscovery rate** | Reads of content already in this Epoch's knowledge state | D1, D2 |
| **Injection precision** | Fraction of injected items subsequently referenced or acted on | D2, D5 |
| **Dispute rate** | Disputes per 100 injections | D5 |
| **Coverage completeness** | Fraction of agent actions captured | D1, all |

**ESK is always reported with its denominator.** A system that injects nothing and gets lucky can
post a strong ESK. Only the paired design distinguishes that from a real effect.

## 44.6 Pre-registered predictions

Stating these in advance is what makes the evaluation a test rather than a search.

| # | Prediction | Falsified if |
|---|---|---|
| PR1 | Warn-only duplicate prevention has a negative net token delta | Net is positive across the corpus |
| PR2 | Delta injection outperforms full re-injection on net tokens by >2× in sessions over 20 turns | Difference is under 2× |
| PR3 | Repeat-failure prevention exceeds 50% on mined defects | Below 50% |
| PR4 | False-warning rate stays under 15% at the shipped signature threshold | Above 15% |
| PR5 | Content-keyed remedy signatures outperform path-based matching on prevention rate | No significant difference |
| PR6 | Task success delta is positive but smaller than net-token delta suggests | Success delta is negative, or scales with token savings |

PR6 deserves emphasis: the honest expectation is that token savings will look better than outcome
improvement, because saving tokens is easy and improving outcomes is hard. Publishing that gap is
more useful than hiding it.

## 44.7 Statistical protocol

- Pre-register the primary metric, N, seeds and analysis plan before running.
- Paired designs throughout; report effect sizes with confidence intervals.
- Correct for multiple comparisons across the metric family.
- Report every run, including failed and aborted ones.
- Model version is a blocking factor, not a footnote: a re-run on a new model is a new experiment.
- Blinded evaluation wherever a human judges outcome quality.

## 44.8 What gets published

1. The harness, runnable by third parties.
2. The corpus and task definitions, with mined/synthetic labels.
3. Pre-registrations, timestamped.
4. All results, including nulls and negatives.
5. Metric definitions precise enough to reimplement.

**A score without a reproducible harness is a marketing claim.** The category is full of them, and
publishing the harness is the cheapest available way to be different.

## 44.9 External benchmarks

AEXO also reports against public memory benchmarks — LongMemEval, LoCoMo, MemoryAgentBench — with a
stated caveat: these measure conversational memory over dialogue, not engineering memory over
repositories and tool traces. They are reported for comparability, not as the primary evidence.
The seeded-defect benchmark is the primary evidence, because it tests the mechanism AEXO actually
claims.

## 44.10 Acceptance criteria

**AC-BENCH-1.** Given the seeded corpus, when composition is audited, then it meets every spread
target in `44.4` and mined/synthetic labels are present on every instance.

**AC-BENCH-2.** Given any published result, when inspected, then N, seeds, model version, harness
version and AEXO version are present.

**AC-BENCH-3.** Given a pre-registration, when the corresponding results are published, then the
primary metric matches the registered one, and any deviation is disclosed as such.

**AC-BENCH-4.** Given the repeat-failure prevention result, when it is reported, then the
false-warning rate is reported alongside it in the same table.

**AC-BENCH-5.** Given a prediction in `44.6` is falsified, when results are published, then the
falsification is stated explicitly rather than omitted.

**AC-BENCH-6.** Given the published harness, when a third party runs it on their own corpus, then
they obtain metric values without access to any AEXO-internal data.
