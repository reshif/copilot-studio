# 43 — Acceptance Test Catalog

Every test is written in natural language as **Given / When / Then**. No test here depends on
reading source code to interpret. A test that cannot be checked by a competent person with the
product and this document is not a test.

Conventions:
- **Given** is the world state before.
- **When** is a single triggering action.
- **Then** is observable behaviour, never an internal state assertion unless that state is
  externally inspectable via CLI or API.
- Every test names how the observation is made.

Coverage: **178 tests** across 21 areas. Phase column indicates when the test must first pass.

---

## AT-CAP — Capture runtime

**AT-CAP-001 · Hook never fails the agent · P0**
*Given* a valid hook payload on stdin and any daemon state.
*When* `aexo-hook` executes.
*Then* it exits 0, and the harness reports no error.
*Observed via* exit code and harness transcript.

**AT-CAP-002 · Event conforms to schema · P0**
*Given* a Claude Code `PreToolUse` payload.
*When* the hook emits its event.
*Then* the event validates against the published Canonical Activity Event JSON Schema with no
warnings.
*Observed via* `aexo export` and a schema validator.

**AT-CAP-003 · Transport works on all platforms · P0**
*Given* a running daemon on Linux, macOS and Windows.
*When* 1,000 hook invocations occur on each.
*Then* all 1,000 events appear in the log on each platform.

**AT-CAP-004 · Spool preserves everything · P0**
*Given* no daemon running and 10,000 hook invocations across 40 spool files.
*When* the daemon starts.
*Then* all 10,000 events appear in the log exactly once, in embedded-timestamp order.

**AT-CAP-005 · Loss is loud · P0**
*Given* a spool directory at its 256MB cap.
*When* further events arrive.
*Then* the drop count increases, `aexo doctor` reports it, and the next injected health notice
states it.

**AT-CAP-006 · All Claude Code events mapped · P0**
*Given* a session exercising every Claude Code hook event.
*When* the log is inspected.
*Then* every event has a corresponding canonical event, and unmapped events appear as
`harness.<name>` rather than being dropped silently.

**AT-CAP-007 · Advisory context delivered · P0**
*Given* a Gate verdict of `warn`.
*When* the hook returns.
*Then* it exits 0 and the message appears in the agent's context as additional context.

**AT-CAP-008 · Malformed input survived · P0**
*Given* truncated, empty, oversized and non-UTF-8 stdin payloads.
*When* the hook executes on each.
*Then* it exits 0 within its ceiling in every case, emits a `capture.malformed` health event, and
never hangs or crashes.

**AT-CAP-009 · Shell lexing is correct · P0**
*Given* a corpus of 500 real shell command lines with quoting, pipes, redirects and sequencing.
*When* each is lexed.
*Then* tokenisation matches the labelled expectation for all 500.

**AT-CAP-010 · Shell intent classified · P0**
*Given* `rg -n "TODO" src/ | head -20`.
*When* it is classified.
*Then* intent is `search`, `src/` is extracted as a path argument, and the pipe target is not
recorded as a separate read.

**AT-CAP-011 · Unknown commands are not guessed · P0**
*Given* a command line the classifier does not recognise.
*When* it is captured.
*Then* intent is `other`, the raw command is retained, and no file arguments are asserted.

**AT-CAP-012 · Codex coverage is honest · P0**
*Given* a Codex session using non-Bash tools.
*When* completeness is reported.
*Then* the uncovered tool classes are listed as unsupported, not as captured.

**AT-CAP-013 · Config fast path · P0**
*Given* a valid memory-mapped config.
*When* the hook reads configuration.
*Then* it completes in under 100µs and no TOML parsing occurs.

**AT-CAP-014 · Cold start within target · P0**
*Given* a cold page cache on each supported platform.
*When* start-up is measured 100 times.
*Then* the median is within the platform target in `31.2`.

**AT-CAP-015 · OTel ingest works without hooks · P0**
*Given* a harness emitting OpenTelemetry GenAI spans and no AEXO hooks installed.
*When* spans are received.
*Then* canonical events are produced and appear in the log with source recorded as OTLP.

**AT-CAP-016 · Generic adapter contract · P0**
*Given* the reference adapter implementation.
*When* it emits events for a synthetic harness.
*Then* they are accepted and indistinguishable in structure from native adapter events.

---

## AT-DMN — Daemon

**AT-DMN-001 · Single instance enforced · P0**
*Given* a running daemon.
*When* a second is started against the same home.
*Then* the second exits non-zero within 200ms naming the holder's PID, and the first is unaffected.

**AT-DMN-002 · Crash loses nothing committed · P0**
*Given* a daemon killed with SIGKILL mid-write.
*When* it restarts.
*Then* `aexo verify` reports INTACT and every event acknowledged as durable is present.

**AT-DMN-003 · Backpressure is accounted · P0**
*Given* the queue driven to 85% depth.
*When* low-value events arrive.
*Then* they are dropped, counts by kind are recorded, and completeness reflects the loss within one
minute.

**AT-DMN-004 · Checkpoint equals full rebuild · P0**
*Given* 250,000 events since the last checkpoint and a restart.
*When* derived state is loaded from checkpoint plus tail.
*Then* it is identical to a full rebuild from genesis.

**AT-DMN-005 · Schema mismatch rebuilds · P0**
*Given* a derived schema version older than the daemon's.
*When* the daemon starts.
*Then* it rebuilds, reports progress, and serves reads only from a consistent state.

**AT-DMN-006 · No polling · P0**
*Given* the daemon idle for one hour.
*When* syscalls are traced.
*Then* no polling pattern is observable and average CPU is ≤1%.

**AT-DMN-007 · Clean shutdown · P0**
*Given* SIGTERM.
*When* the daemon shuts down.
*Then* the queue drains, all accepted events are durable, the lock is released, and exit occurs
within 2 seconds.

**AT-DMN-008 · Bad frame isolates · P0**
*Given* a malformed frame on the hook socket.
*When* it is received.
*Then* a health event is emitted, that connection alone is closed, and all others continue.

**AT-DMN-009 · Scheduler runs nothing inline · P0**
*Given* a long-running scheduled job.
*When* it executes.
*Then* the scheduler thread remains responsive and other jobs are not delayed beyond their tick.

---

## AT-STORE — Event store

**AT-STORE-001 · Chain verifies at scale · P0**
*Given* 1,000,000 events.
*When* verification runs from genesis.
*Then* it reports INTACT at ≥300MB/s of decompressed input.

**AT-STORE-002 · Tampering is located exactly · P0**
*Given* one flipped byte in a sealed segment envelope.
*When* verification runs.
*Then* it names the exact sequence of the first break with expected and computed hashes.

**AT-STORE-003 · Sealing is crash-safe · P0**
*Given* a crash injected at each of the five sealing steps.
*When* the daemon restarts after each.
*Then* no event is lost or duplicated and the manifest matches the files present.

**AT-STORE-004 · Blobs deduplicate · P0**
*Given* the same 2MB content captured by 20 agents.
*When* storage is measured.
*Then* one blob exists with 20 referencing envelopes.

**AT-STORE-005 · Shred preserves the chain · P2**
*Given* a completed `FORGET` for a subject.
*When* the log is inspected.
*Then* no payload for that subject decrypts, `aexo verify` reports INTACT, and envelopes retain
their provenance and redaction metadata.

**AT-STORE-006 · Sealed segments are immutable · P0**
*Given* a sealed segment.
*When* any code path attempts to open it for writing.
*Then* the attempt fails and is recorded as a health event.

**AT-STORE-007 · Auditable without our software · P0**
*Given* only `zstd` and `jq`.
*When* an auditor inspects a sealed segment.
*Then* every envelope is readable, self-describing, and carries its chain fields.

**AT-STORE-008 · Clock changes do not corrupt order · P0**
*Given* events written across a DST transition and a manual clock adjustment.
*When* they are read back.
*Then* sequence order is unchanged and both temporal fields remain interpretable.

---

## AT-DER — Derived state

**AT-DER-001 · Fold is deterministic across platforms · P0**
*Given* a 1M-event log.
*When* derived state is built on Linux, macOS and Windows.
*Then* the resulting stores are identical after normalisation of file ordering.

**AT-DER-002 · Rebuild equals incremental · P0**
*Given* an incrementally maintained store.
*When* a full rebuild from genesis is compared to it.
*Then* they are identical.

**AT-DER-003 · Unknown kinds are forward-compatible · P0**
*Given* an event kind unknown to this version.
*When* it is folded.
*Then* it is counted as unhandled, the fold continues, and chain and sequence are unaffected.

**AT-DER-004 · Staleness is disclosed · P0**
*Given* the fold delayed by 2 seconds.
*When* a bundle is generated.
*Then* it carries a staleness marker and a health event has fired.

**AT-DER-005 · Receipts are reproducible · P3**
*Given* any receipt and its recorded sequence.
*When* state is rebuilt to that sequence.
*Then* the bundle regenerates byte-identically.

**AT-DER-006 · Purity is enforced mechanically · P0**
*Given* a fold handler that reads the system clock.
*When* the determinism lint runs.
*Then* the build fails naming the offending handler.

---

## AT-SIDX — Structure indexer

**AT-SIDX-001 · Works with zero setup · P0**
*Given* a repository and no configured indexer.
*When* a structural query is made.
*Then* an answer is returned with precision `syntactic` and no external process is spawned.

**AT-SIDX-002 · Highest available precision, correctly labelled · P2**
*Given* a SCIP index and a running language server.
*When* the same query is made.
*Then* the highest-precision answer is returned and the label matches the source actually used.

**AT-SIDX-003 · Degradation is downward only · P2**
*Given* a language server that stops responding.
*When* a `live` query is attempted.
*Then* it degrades within the ceiling and the label reflects what was actually used, never higher.

**AT-SIDX-004 · Incremental within budget · P0**
*Given* a 500,000-file repository.
*When* one file is edited.
*Then* reindexing completes within 50ms at p95 and only that file's symbols are re-emitted.

**AT-SIDX-005 · No-op edits produce no events · P0**
*Given* a whitespace-only edit.
*When* reindexing runs.
*Then* zero symbol events are emitted.

**AT-SIDX-006 · Referenced history is retained · P0**
*Given* a Claim whose provenance references commit X.
*When* structure retention prunes.
*Then* commit X's structure for the referenced paths remains.

**AT-SIDX-007 · Unknown languages are opaque, not guessed · P0**
*Given* a file in a language with no shipped grammar.
*When* it changes.
*Then* it is recorded with content hash only and no structural claims are made about it.

**AT-SIDX-008 · Branch switch does not trigger full reindex · P0**
*Given* a branch switch touching 4,000 files.
*When* the watcher fires.
*Then* a batch incremental pass completes within 15 seconds and no full reindex occurs.

---

## AT-EPI / AT-EXP — Episodes, evidence, claims

**AT-EPI-001 · Boundaries are deterministic · P1**
*Given* an identical event log processed twice.
*When* Episodes are derived.
*Then* boundaries and structured fields are identical; only summaries may differ.

**AT-EPI-002 · Verified success is recognised · P1**
*Given* a failing test run followed by a passing run of the same command in one Episode.
*When* the outcome is classified.
*Then* it is `resolved` with trust `machine_verified`.

**AT-EPI-003 · Abandonment is not success · P1**
*Given* an Episode ended by 25 minutes of idle with no terminal signal.
*When* it is classified.
*Then* the outcome is `abandoned` and no Claim cites it as evidence of success.

**AT-EPI-004 · Summaries are not evidence · P1**
*Given* a Claim candidate citing an Episode summary.
*When* it is submitted.
*Then* it is rejected with a reason naming the prohibited source.

**AT-EPI-005 · Reflection is optional to correctness · P1**
*Given* the reflection budget exhausted.
*When* Episodes close.
*Then* structured fields are complete, summaries queue, and no agent sees an error.

**AT-EPI-006 · No provider, no problem · P1**
*Given* no model provider reachable.
*When* an Episode closes.
*Then* consolidation completes with a null summary.

**AT-EXP-001 · Evidence resolves · P1**
*Given* any Evidence record.
*When* it is dereferenced.
*Then* it resolves to a specific event range or verification result with its source and trust.

**AT-EXP-002 · Decisions record alternatives · P1**
*Given* a recorded Decision.
*When* it is queried.
*Then* the chosen option, the alternatives considered and the rationale reference are all present.

**AT-EXP-003 · Human writes are attributed · P1**
*Given* `aexo note`, `aexo decide` and `aexo attest`.
*When* each is used.
*Then* the resulting record carries a human actor identity and the appropriate trust level.

**AT-EXP-004 · Claim filters work · P1**
*Given* claims across bands, scopes and staleness.
*When* `aexo claims` is filtered on each dimension.
*Then* results match an independently computed expectation.

**AT-EXP-005 · Artefact history is complete · P3**
*Given* a file with 40 recorded interactions.
*When* `aexo_history` is called on it.
*Then* all 40 are represented or the truncation is explicit.

---

## AT-CLM — Claim engine

**AT-CLM-001 · Imperatives are refused · P1**
*Given* a candidate whose statement is an imperative.
*When* it is submitted.
*Then* it is rejected naming the mood violation and no Claim is created.

**AT-CLM-002 · Hallucinated citations kill the candidate · P1**
*Given* a candidate citing a non-existent event ID.
*When* grounding runs.
*Then* the entire candidate is rejected with no partial write.

**AT-CLM-003 · Scope is intersected, not accepted · P1**
*Given* a candidate scoped `**/*` with evidence covering only `src/auth/`.
*When* scope inference runs.
*Then* the admitted scope is `src/auth/` and the narrowing is recorded.

**AT-CLM-004 · Duplicates become support · P1**
*Given* three identical statements in the same scope.
*When* they are admitted.
*Then* one Claim exists with three supporting evidence links.

**AT-CLM-005 · Derived claims are capped · P1**
*Given* a candidate whose only evidence is another Claim.
*When* its band is computed.
*Then* it is at most `derived` and can never reach `verified` on that basis.

**AT-CLM-006 · Amplification is structurally impossible · P1**
*Given* a chain of candidates each citing the previous.
*When* the third is submitted.
*Then* it is refused because provenance depth exceeds 2.

**AT-CLM-007 · Correlated evidence counts once · P1**
*Given* five evidence records from one agent, one Epoch, one file.
*When* independence is scored.
*Then* they count as one and the Claim does not reach `supported` on that basis.

**AT-CLM-008 · Malformed model output is discarded whole · P1**
*Given* the candidate generator returns malformed JSON.
*When* it is processed.
*Then* the batch is discarded, a health event is recorded, and no Claim is created.

**AT-CLM-009 · Verification precedes the verified band · P1**
*Given* a candidate proposing a verifier.
*When* it is admitted.
*Then* its band reflects evidence only until the verifier has actually run.

**AT-CLM-010 · Admission is deterministic · P1**
*Given* the same model output replayed.
*When* admission runs twice.
*Then* the admitted Claims are identical.

---

## AT-PROV — Provenance

**AT-PROV-001 · Every claim has a resolvable chain · P1**
*Given* any admitted Claim.
*When* its provenance is walked.
*Then* every edge resolves to a real record and no dangling reference exists.

**AT-PROV-002 · Support and contradiction are distinct edges · P1**
*Given* evidence that contradicts a Claim.
*When* the graph is inspected.
*Then* the edge is typed CONTRADICTS and is not counted as support.

**AT-PROV-003 · Traversal truncation is flagged · P1**
*Given* a chain deeper than 5.
*When* it is traversed.
*Then* results are truncated at 5 and the truncation is explicit in the response.

**AT-PROV-004 · `why` answers in one call · P1**
*Given* any claim, remedy signature, receipt or decision ID.
*When* `aexo why` is called.
*Then* it returns the supporting evidence, bands, dates and actors without a follow-up call.

---

## AT-TRUST — Trust and taint

**AT-TRUST-001 · Trust is assigned at write · P2**
*Given* content from each source class.
*When* it is captured.
*Then* each record carries the correct trust level, verified against the source class table.

**AT-TRUST-002 · Trust is the minimum of inputs · P2**
*Given* a derived record combining `observed` and `untrusted` inputs.
*When* its trust is computed.
*Then* it is `untrusted`.

**AT-TRUST-003 · Untrusted content is always labelled · P2**
*Given* untrusted content selected for rendering.
*When* it is emitted.
*Then* it appears inside a labelled quotation naming source and trust, never as a directive.

**AT-TRUST-004 · Elevation is evidence, not mutation · P2**
*Given* a human attests a Claim.
*When* the change is inspected.
*Then* a new attestation record exists and the original record is unmodified.

---

## AT-VER — Verification

**AT-VER-001 · Passing verifier raises the band · P2**
*Given* a Claim with a passing command verifier.
*When* verification runs.
*Then* the band becomes `verified` and the verifier version and exit code are recorded.

**AT-VER-002 · Failure demotes, never deletes · P2**
*Given* a `verified` Claim whose verifier now fails.
*When* verification runs.
*Then* the band drops to `observed`, the Claim is flagged, and it still exists.

**AT-VER-003 · Undeclared network is blocked · P2**
*Given* a verifier attempting an undeclared network connection.
*When* it runs.
*Then* the connection fails, the result is `error`, and the band is unchanged.

**AT-VER-004 · Runaway verifiers are contained · P2**
*Given* a verifier that never terminates.
*When* the timeout elapses.
*Then* the process tree is killed and daemon resources return to baseline.

**AT-VER-005 · Verification follows change, not the calendar · P2**
*Given* a Claim scoped `src/billing/` and an edit inside it.
*When* the watcher fires.
*Then* verification is scheduled within one scheduler tick.

**AT-VER-006 · Decay is computed at read time · P2**
*Given* a `verified` Claim unverified for 45 days on a 14-day interval.
*When* it is read.
*Then* its effective band is `observed`.

**AT-VER-007 · Decay survives outages · P2**
*Given* the daemon offline for 60 days.
*When* it restarts and Claims are read.
*Then* decay is correct with no catch-up sweep.

**AT-VER-008 · Verification never starves the developer · P2**
*Given* 200 Claims due for command verification.
*When* they are scheduled.
*Then* concurrency and CPU share stay within configuration.

**AT-VER-009 · Cheap verifiers are preferred · P2**
*Given* a Claim verifiable structurally with a command verifier proposed.
*When* it is admitted.
*Then* a recommendation for the cheaper verifier is recorded.

---

## AT-CON — Contradiction

**AT-CON-001 · Deterministic detection needs no model · P2**
*Given* two Claims with structurally negated predicates in overlapping scope.
*When* detection runs.
*Then* a contradiction is raised with zero model calls.

**AT-CON-002 · Detection scales · P2**
*Given* 200,000 Claims.
*When* a new Claim is admitted.
*Then* detection completes within 300ms at p99 by comparing only scope-overlapping candidates.

**AT-CON-003 · Conflict is shown, not hidden · P2**
*Given* an unresolved contradiction relevant to the agent's intent.
*When* a bundle is generated.
*Then* both Claims appear with bands, ages and the conflict marker.

**AT-CON-004 · Semantic detection cannot resolve · P2**
*Given* a tier-4 semantic detection at maximum model confidence.
*When* it fires.
*Then* it is routed to review and never auto-resolved.

**AT-CON-005 · Supersession is recognised · P2**
*Given* Claim B formed after a commit that changed Claim A's subject.
*When* classification runs.
*Then* it is `supersession`, A is marked superseded, and both remain queryable.

**AT-CON-006 · Resolutions are auditable and reversible · P2**
*Given* a resolution later reversed.
*When* history is queried.
*Then* both appear with actors and timestamps and no record was mutated.

**AT-CON-007 · Stale conflicts surface · P2**
*Given* contradictions unresolved for 31 days.
*When* the health notice is generated.
*Then* their count appears within the notice budget.

**AT-CON-008 · Apparent conflicts do not recur · P2**
*Given* two Claims mistakenly treated as overlapping.
*When* classification runs.
*Then* they are dismissed as `apparent` and are not re-raised on later sweeps.

---

## AT-GATE — Governance Gate

**AT-GATE-001 · Duplicate read is caught in budget · P2**
*Given* a file already read in this Epoch.
*When* the Gate runs.
*Then* it returns `warn` within 10ms p99 naming the prior read.

**AT-GATE-002 · Subagents are structurally exempt · P2**
*Given* a subagent in a different Epoch reading a file the parent read.
*When* the Gate runs.
*Then* it returns `allow`.

**AT-GATE-003 · Repeat fixes are caught by content · P2**
*Given* an edit differing from a previously-failed edit only by identifier names and formatting.
*When* the signature is computed.
*Then* it matches and the Gate warns naming the prior failure.

**AT-GATE-004 · Different fixes are not conflated · P2**
*Given* a semantically different edit to the same file.
*When* the signature is computed.
*Then* it does not match and the Gate does not warn on that basis.

**AT-GATE-005 · Gate path is inference-free · P2**
*Given* 10,000 gated calls under trace.
*When* the trace is inspected.
*Then* no inference call, network call or credential access occurs.

**AT-GATE-006 · Slow Gate yields · P2**
*Given* derived state stale beyond threshold.
*When* the Gate runs.
*Then* it returns `allow` with `degraded: true` within 15ms and the degradation is counted.

**AT-GATE-007 · Default never blocks · P2**
*Given* default configuration and any check firing.
*When* the verdict returns.
*Then* it is `warn` and the harness receives exit 0.

**AT-GATE-008 · Block mode is scoped and recorded · P2**
*Given* an enterprise policy enabling block for one rule.
*When* that rule fires.
*Then* the action is refused with the rule ID recorded, and all other rules still only warn.

**AT-GATE-009 · Allows are recorded too · P2**
*Given* 10,000 tool calls.
*When* verdicts are queried.
*Then* every call has a recorded verdict including allows.

**AT-GATE-010 · Large edits degrade gracefully · P2**
*Given* a 5,000-line edit.
*When* the signature is computed.
*Then* it completes within budget using the coarse signature and the reduced precision is recorded.

---

## AT-POL — Policy

**AT-POL-001 · I/O cannot compile · P2**
*Given* a Policy containing any I/O construct.
*When* it is compiled.
*Then* compilation fails naming the construct and the Policy is not stored active.

**AT-POL-002 · Tests are mandatory · P2**
*Given* a Policy lacking a positive or negative test.
*When* activation is attempted.
*Then* it is refused.

**AT-POL-003 · Failing tests block activation · P2**
*Given* a Policy whose tests fail.
*When* activation is attempted.
*Then* it is refused and the failing test is named.

**AT-POL-004 · Totality holds under adversarial input · P2**
*Given* input designed to maximise evaluation cost.
*When* a compiled Policy evaluates it.
*Then* evaluation completes within the Gate budget.

**AT-POL-005 · Policy count does not degrade the Gate · P2**
*Given* 500 active Policies.
*When* the Gate evaluates one action.
*Then* only scope-matching Policies evaluate and Gate p99 holds.

**AT-POL-006 · Warnings trace to a policy version · P2**
*Given* a Gate warning from a Policy.
*When* its provenance is queried.
*Then* the compiled version hash, source text and author are returned.

**AT-POL-007 · Deactivation is an event · P2**
*Given* a Policy is deactivated.
*When* the Gate next evaluates.
*Then* it no longer fires, and the deactivation is recorded with actor and reason.

---

## AT-PRJ — Projection

**AT-PRJ-001 · Bundles are deterministic · P3**
*Given* identical state, intent and budget.
*When* a bundle is generated twice.
*Then* the output is byte-identical.

**AT-PRJ-002 · Budgets hold · P3**
*Given* a session-start bundle.
*When* tokens are counted.
*Then* it is within 600–1,200 and never exceeds 2,000.

**AT-PRJ-003 · Deltas only · P3**
*Given* an Epoch already shown item X.
*When* a later injection occurs.
*Then* X is absent and the header names only what changed.

**AT-PRJ-004 · The prefix is never mutated · P3**
*Given* any injection point.
*When* content is emitted.
*Then* it is appended at the tail and no earlier content is rewritten.
*Observed via* a trace of context assembly across a full session.

**AT-PRJ-005 · Degradation preserves what matters · P3**
*Given* a budget too small for all reserved sections.
*When* a bundle is generated.
*Then* reserved sections ship, others are dropped, and the receipt records `degraded: true` with
what was omitted.

**AT-PRJ-006 · Lifetime cost is priced · P3**
*Given* two equally relevant items of different size at turn 3 of an expected 40-turn session.
*When* they are scored.
*Then* the cost difference reflects the lifetime multiplier, not the raw token difference.

**AT-PRJ-007 · Receipts are complete and arithmetically sound · P3**
*Given* any bundle.
*When* its receipt is inspected.
*Then* every rendered item appears with score components and item tokens sum to the reported total.

**AT-PRJ-008 · Disputes are captured · P3**
*Given* an agent calls `aexo_dispute` on a receipt.
*When* it is processed.
*Then* a dispute event is recorded citing receipt and reason, and it appears in the dashboard within
one refresh.

**AT-PRJ-009 · Claims are never bare assertions · P3**
*Given* Claims at different bands selected.
*When* they are rendered.
*Then* each shows band, evidence count and age, and none is rendered as an instruction.

**AT-PRJ-010 · Untrusted content stays quoted · P3**
*Given* untrusted repository content selected for rendering.
*When* it is emitted.
*Then* it appears inside a labelled quotation and never as a directive.

---

## AT-MCP / AT-SRV / AT-CLI

**AT-MCP-001 · Restarts are free · P3**
*Given* 50 MCP server restarts in one session.
*When* each completes.
*Then* no state is lost, re-initialisation stays under 200ms, and no event is duplicated.

**AT-MCP-002 · Description budget enforced · P3**
*Given* the full tool set.
*When* descriptions are tokenised.
*Then* the total is ≤450 tokens and exceeding it fails CI naming the description.

**AT-MCP-003 · Bad news arrives as success · P3**
*Given* the daemon stopped.
*When* any tool is called.
*Then* the call returns successfully with an unavailability message and no exception trace.

**AT-MCP-004 · Attestation asks the human · P3**
*Given* `aexo_attest` called by an agent on a claim needing human confirmation.
*When* it executes.
*Then* it returns `input_required` and never auto-attests.

**AT-MCP-005 · Oversized results truncate explicitly · P3**
*Given* a query matching 5,000 claims.
*When* it is answered.
*Then* the response is within budget, truncation is explicit, and a narrower query is suggested.

**AT-MCP-006 · Capabilities are reported accurately · P3**
*Given* `server/discover`.
*When* a client negotiates.
*Then* active extensions are reported truthfully.

**AT-MCP-007 · Long operations become Tasks · P3**
*Given* a rebuild invoked over MCP.
*When* it starts.
*Then* the tool call returns immediately with a task handle.

**AT-SRV-001 · The API cannot write the log · P1**
*Given* the server process.
*When* its file handles are inspected.
*Then* it holds no write handle on any segment.

**AT-SRV-002 · Machines cannot author policy · P2**
*Given* a service account with the highest role.
*When* it posts a policy.
*Then* it is rejected because the actor is not human, and the attempt is logged.

**AT-SRV-003 · Tenants are isolated · P5**
*Given* two tenants.
*When* tenant A issues every API route with B's identifiers.
*Then* zero rows from B are returned and every attempt is logged.

**AT-SRV-004 · Graph queries stay in budget · P1**
*Given* a depth-5 provenance query on REF-BIG.
*When* it executes.
*Then* it completes within 200ms p99 or returns truncated with the truncation flagged.

**AT-SRV-005 · Expired tokens leak nothing · P5**
*Given* an expired token.
*When* any route is called.
*Then* 401 is returned with no partial data.

**AT-SRV-006 · Exports stream · P3**
*Given* an export of 1M events.
*When* requested.
*Then* first byte arrives under 500ms and server memory stays constant.

**AT-SRV-007 · The contract is enforced · P1**
*Given* the running server's OpenAPI document.
*When* it is compared to the committed contract.
*Then* they match, and a mismatch fails CI.

**AT-CLI-001 · Install is honest · P0**
*Given* Claude Code and Codex installed.
*When* `aexo init` runs.
*Then* both are configured, unrelated settings are byte-identical, and Codex coverage limits are
printed.

**AT-CLI-002 · Install is idempotent · P0**
*Given* `aexo init` run twice.
*When* the second completes.
*Then* configuration is unchanged with no duplicate hook entries.

**AT-CLI-003 · Everything is scriptable · P0**
*Given* every command.
*When* `--json` is passed.
*Then* stdout is valid JSON and all human formatting is on stderr.

**AT-CLI-004 · Integrity failure has its own exit code · P0**
*Given* a broken chain.
*When* `aexo verify` runs.
*Then* it exits 3 and names the break sequence.

**AT-CLI-005 · Net is never hidden · P3**
*Given* `aexo budget`.
*When* it prints.
*Then* avoided, injected, cache cost and net all appear, and net is never omitted.

**AT-CLI-006 · Destruction requires informed consent · P2**
*Given* `aexo forget --subject X` without `--yes`.
*When* it runs.
*Then* it describes exactly what becomes unrecoverable and requires explicit confirmation.

**AT-CLI-007 · No daemon, no hang · P0**
*Given* no daemon running.
*When* any read command is issued.
*Then* it serves read-only or reports unavailability, and never hangs.

**AT-CLI-008 · Doctor is actionable · P0**
*Given* a stale index, a dropped-event count and an unconfigured harness.
*When* `aexo doctor` runs.
*Then* all three are reported with specific remediation commands.

---

## AT-SEC — Security

**AT-SEC-001 · Zero injection escapes · P2**
*Given* the full injection fuzz corpus across all ten ingestion routes.
*When* bundles are generated for every payload.
*Then* zero payloads appear as unlabelled imperatives, and any occurrence fails the build.

**AT-SEC-002 · Unicode evasion fails · P2**
*Given* bidi overrides, homoglyphs, zero-width joiners and tag characters carrying imperatives.
*When* they are processed.
*Then* none escapes labelling, and the evasion is recorded.

**AT-SEC-003 · Encoding evasion fails · P2**
*Given* base64, hex, ROT13 and unicode-escaped imperatives.
*When* they are processed.
*Then* none is decoded into a directive by any component.

**AT-SEC-004 · Secrets never land on disk · P0**
*Given* the credential corpus embedded in captured payloads.
*When* events are written.
*Then* no credential is present in plaintext on disk and correct redaction kinds are recorded.

**AT-SEC-005 · Ordinary prose is untouched · P0**
*Given* the false-positive prose corpus containing token-like words.
*When* it is captured.
*Then* it is stored byte-identically with zero redactions.

**AT-SEC-006 · Tampering is detected · P0**
*Given* any modified envelope byte.
*When* verification runs.
*Then* the exact break sequence is reported.

**AT-SEC-007 · Erasure is real and chain-safe · P2**
*Given* a completed crypto-shred.
*When* it is inspected.
*Then* no payload decrypts, verification reports INTACT, and a `FORGET` event names actor and
reason.

**AT-SEC-008 · Sandbox holds · P2**
*Given* a verifier attempting filesystem writes outside temp, network access and privilege
escalation.
*When* it runs.
*Then* all three fail and are recorded.

**AT-SEC-009 · The Gate has no credentials · P2**
*Given* the Gate process.
*When* its environment is inspected.
*Then* no provider credential is present.

**AT-SEC-010 · Dormant claims are flagged, not erased · P2**
*Given* a Claim dormant 120 days that suddenly matches an intent.
*When* it is selected.
*Then* a review flag is raised and the Claim is still injected.

**AT-SEC-011 · Policy authorship is human-gated · P2**
*Given* any non-human identity.
*When* a policy write is attempted.
*Then* it is rejected and logged.

**AT-SEC-012 · The security suite gates release · P2**
*Given* a release candidate.
*When* the security suite runs.
*Then* injection fuzz, both redaction suites, tenancy isolation and chain integrity all pass, and
any failure blocks release.

---

## AT-PERF — Performance

**AT-PERF-001 · Hook latency · P0**
*Given* REF-DEV and 10,000 invocations.
*When* latency is measured.
*Then* capture-only p99 ≤8ms and gated p99 ≤10ms.

**AT-PERF-002 · Incremental structure · P0**
*Given* REF-BIG and a single file edit.
*When* reindexing runs.
*Then* p95 ≤50ms.

**AT-PERF-003 · Bundle assembly · P3**
*Given* REF-DEV and 1,000 assemblies.
*When* latency is measured.
*Then* p99 ≤400ms and all bundles are within budget.

**AT-PERF-004 · Idle footprint · P0**
*Given* 24 hours idle on REF-BIG.
*When* resources are measured.
*Then* RSS ≤400MB and average CPU ≤1%.

**AT-PERF-005 · Burst absorption · P0**
*Given* 120,000 events in 10 seconds.
*When* the burst completes.
*Then* nothing is dropped, queue depth returns below 50% within 30 seconds, and a health event
records the burst.

**AT-PERF-006 · Rebuild time · P0**
*Given* 1M events.
*When* a genesis rebuild runs.
*Then* it completes within 10 minutes and matches incremental state.

**AT-PERF-007 · Regressions fail the build · P0**
*Given* a PR regressing any p99 budget by >15%.
*When* CI runs.
*Then* the build fails naming the budget and the measured value.

**AT-PERF-008 · Contradiction at scale · P2**
*Given* 200,000 Claims.
*When* incremental detection runs on a new Claim.
*Then* p99 ≤300ms.

---

## AT-IMP / AT-EVAL / AT-OBS / AT-DSH / AT-CTL / AT-ENT / AT-REL

**AT-IMP-001 · Imported memory is not authority · P1**
*Given* a `.wolf/` directory.
*When* it is imported.
*Then* every ledger entry becomes a Claim at trust `imported` and none renders as an imperative.

**AT-IMP-002 · Imported rules await a human · P1**
*Given* `cerebrum.md` rules.
*When* they are imported.
*Then* they are staged inactive and require explicit human activation.

**AT-IMP-003 · Imports are idempotent · P1**
*Given* the same import run twice.
*When* it completes.
*Then* no duplicates exist.

**AT-IMP-004 · Imports do not starve capture · P1**
*Given* a 100,000-record import concurrent with live capture.
*When* it runs.
*Then* no live hook exceeds its ceiling.

**AT-IMP-005 · Undo retires, never deletes · P1**
*Given* `aexo import --undo`.
*When* it runs.
*Then* records are retired via events, the log contains no deletions, and verification is INTACT.

**AT-IMP-006 · projectmem types survive · P1**
*Given* a projectmem event log.
*When* imported.
*Then* typed records preserve type and trust; untyped enter at `imported`.

**AT-IMP-007 · Git history is observed, not inferred · P1**
*Given* a git history import.
*When* it completes.
*Then* records are at trust `observed` and no Claim is generated directly from commit messages
without evidence.

**AT-EVAL-001 · Results carry their conditions · P4**
*Given* any published result.
*When* it is inspected.
*Then* N, seeds, model version, harness version and AEXO version are present.

**AT-EVAL-002 · No gross-only claims · P4**
*Given* any evaluation report.
*When* it is inspected.
*Then* effect sizes and confidence intervals are present and no bare gross-savings figure appears.

**AT-EVAL-003 · Shadow mode is truly zero-injection · P4**
*Given* shadow mode enabled.
*When* a session runs.
*Then* the agent's context is byte-identical to a run with AEXO absent, and verdicts are still
recorded.

**AT-EVAL-004 · Assumptions are stated · P4**
*Given* a counterfactual replay result.
*When* the report is read.
*Then* the behavioural-invariance assumption appears in the report body.

**AT-EVAL-005 · Experiments are reproducible · P4**
*Given* the same configuration, seeds and model version.
*When* run twice.
*Then* recorded AEXO-side decisions are identical.

**AT-EVAL-006 · Negatives are published · P4**
*Given* a configuration with negative net token delta.
*When* the report is generated.
*Then* it appears with the same prominence as positive results.

**AT-EVAL-007 · Third parties can reproduce · P4**
*Given* the published harness and corpus.
*When* an external party runs it.
*Then* they can compute the reported metrics without access to internal data.

**AT-OBS-001 · Failures are events · P0**
*Given* each defined failure mode triggered.
*When* it occurs.
*Then* a health event of the correct kind is emitted.

**AT-OBS-002 · Completeness is measured, not assumed · P0**
*Given* a mixed-harness installation.
*When* completeness is computed.
*Then* it reports captured, dropped, degraded and unsupported per harness and per event kind.

**AT-OBS-003 · AEXO is observable by standard tools · P0**
*Given* an OTel collector.
*When* AEXO runs.
*Then* its own traces and metrics are exported and readable.

**AT-OBS-004 · Rollups match raw · P0**
*Given* a rollup window.
*When* it is compared to raw computation.
*Then* the values match.

**AT-OBS-005 · Degradation reaches the agent · P3**
*Given* an active degradation.
*When* the next injection occurs.
*Then* a health notice within 60 tokens states it.

**AT-DSH-001 · The dashboard admits losses · P4**
*Given* a session where injected exceeds avoided.
*When* the economics view renders.
*Then* the net is shown as negative with equal prominence.

**AT-DSH-002 · Coverage gaps show as gaps · P4**
*Given* a Codex-only installation.
*When* completeness renders.
*Then* non-Bash coverage shows as unsupported.

**AT-DSH-003 · Provenance is browsable · P4**
*Given* any claim.
*When* provenance is opened.
*Then* the chain to depth 5 renders with bands and truncation marked.

**AT-DSH-004 · No editing, no bulk resolve · P4**
*Given* the dashboard.
*When* a user seeks to edit a Claim or bulk-resolve conflicts.
*Then* no such control exists.

**AT-DSH-005 · Drops appear fast · P4**
*Given* events dropped to backpressure.
*When* the health view renders.
*Then* counts by kind appear within one minute.

**AT-DSH-006 · Stale data is never presented as current · P4**
*Given* the REST server unavailable.
*When* the dashboard loads.
*Then* it renders an explicit unavailability state.

**AT-CTL-001 · Control plane is not a dependency · P5**
*Given* the control plane unreachable for 7 days.
*When* developers work.
*Then* capture, gating and projection function fully and org-policy staleness is reported locally.

**AT-CTL-002 · Unsigned policy is refused · P5**
*Given* a bundle with an invalid signature.
*When* a daemon pulls it.
*Then* it is rejected, the previous bundle stays active, and the rejection is reported.

**AT-CTL-003 · Local cannot weaken org · P5**
*Given* a local policy attempting to disable an org policy.
*When* it is compiled.
*Then* compilation fails and the attempt appears in fleet health.

**AT-CTL-004 · Payloads stay local by default · P5**
*Given* default configuration.
*When* control-plane traffic is inspected.
*Then* no event payload content is transmitted.

**AT-CTL-005 · Forwarding is disclosed · P5**
*Given* payload forwarding enabled.
*When* a developer checks status.
*Then* `aexo status` and the health notice both state it is on and where data goes.

**AT-CTL-006 · Rotation loses nothing · P5**
*Given* fleet-wide key rotation.
*When* it completes.
*Then* all nodes re-wrap keys, no payload becomes unreadable, and events record it on every node.

**AT-CTL-007 · Silent nodes are visible · P5**
*Given* a node silent for 30 days.
*When* fleet health renders.
*Then* it shows as stale with its last-seen time.

**AT-ENT-001 · No cross-tenant dedup · P5**
*Given* identical content in two tenants.
*When* blob storage is inspected.
*Then* two separate encrypted blobs exist under separate keys.

**AT-ENT-002 · Provisioning propagates · P5**
*Given* a SCIM deprovision.
*When* it completes.
*Then* the identity's access is revoked across all services within the configured window.

**AT-ENT-003 · Service-to-service is authenticated · P5**
*Given* mTLS enabled.
*When* a service presents no client certificate.
*Then* the connection is refused and logged.

**AT-ENT-004 · Retention policy reaches nodes · P5**
*Given* an org retention schedule pushed.
*When* nodes apply it.
*Then* enforcement matches the schedule and each application is recorded.

**AT-ENT-005 · Compliance evidence is producible · P5**
*Given* an auditor request.
*When* the evidence pack is generated.
*Then* it contains chain verification output, attestation records, policy change history, forget
records and access logs for the requested period.

**AT-REL-001 · Dependency budget holds · P0**
*Given* a PR adding a dependency beyond budget.
*When* CI runs.
*Then* it fails naming the dependency and the budget.

**AT-REL-002 · Builds are reproducible and signed · P0**
*Given* a release build run twice on clean machines.
*When* artefacts are compared.
*Then* they are byte-identical, signatures verify, and the SBOM matches.

**AT-REL-003 · Offline install works · P5**
*Given* a machine with no network access.
*When* the offline installer runs.
*Then* installation completes and `aexo doctor` reports a healthy installation.

---

## Coverage summary

| Area | Tests | Phase first required |
|---|---|---|
| CAP | 16 | P0 |
| DMN | 9 | P0 |
| STORE | 8 | P0/P2 |
| DER | 6 | P0 |
| SIDX | 8 | P0/P2 |
| EPI/EXP | 11 | P1 |
| CLM | 10 | P1 |
| PROV | 4 | P1 |
| TRUST | 4 | P2 |
| VER | 9 | P2 |
| CON | 8 | P2 |
| GATE | 10 | P2 |
| POL | 7 | P2 |
| PRJ | 10 | P3 |
| MCP | 7 | P3 |
| SRV | 7 | P1/P5 |
| CLI | 8 | P0/P3 |
| SEC | 12 | P0/P2 |
| PERF | 8 | P0/P3 |
| IMP | 7 | P1 |
| EVAL | 7 | P4 |
| OBS | 5 | P0/P3 |
| DSH | 6 | P4 |
| CTL | 7 | P5 |
| ENT | 5 | P5 |
| REL | 3 | P0/P5 |
| **Total** | **212** | |
