# 46 — Team and RACI

## 46.1 Roles

| Role | Count at peak | Primary areas |
|---|---|---|
| **Tech Lead / Architect** | 1 | Architecture, ADRs, critical-path review, trade rejections |
| **Systems Engineer (Rust)** | 2 | CAP, DMN, EVT, DER, STR, GATE, PROJ, MCP, POL, CLI |
| **Backend Engineer (Python)** | 1.5 | EXP, PROV, JDG, WRK, API, IMP, ENT |
| **Security Engineer** | 0.5→1 | SEC, trust model, sandbox, compliance, fuzz corpora |
| **Research / Eval Engineer** | 0→1 | EVAL, corpus, statistics, publication |
| **Frontend Engineer** | 0→0.5 | DSH |
| **Platform Engineer** | 0.5 | REL, CI, performance harness, packaging |

## 46.2 Staffing by phase

| Phase | TL | Sys | BE | Sec | Res | FE | Plat | Total |
|---|---|---|---|---|---|---|---|---|
| P0 | 1 | 2 | 0 | 0.5 | 0 | 0 | 0.5 | 4.0 |
| P1 | 1 | 1.5 | 1.5 | 0.5 | 0 | 0 | 0.5 | 5.0 |
| P2 | 1 | 2 | 1 | 1 | 0 | 0 | 0.5 | 5.5 |
| P3 | 1 | 2 | 1 | 0.5 | 0.5 | 0 | 0.5 | 5.5 |
| P4 | 1 | 1 | 1 | 0.5 | 1 | 0.5 | 0.5 | 5.5 |
| P5 | 1 | 1 | 2 | 1 | 0.5 | 0.5 | 0.5 | 6.5 |

Fractional roles are shared or contracted. The Tech Lead is 50% hands-on throughout; a purely
managing lead on a project this specification-dense is a coordination cost, not a multiplier.

## 46.3 RACI by area

R = responsible, A = accountable, C = consulted, I = informed.

| Area | TL | Sys | BE | Sec | Res | FE | Plat |
|---|---|---|---|---|---|---|---|
| Architecture and ADRs | **A/R** | C | C | C | I | I | C |
| Capture and hooks | A | **R** | I | C | I | — | C |
| Event store and chain | A | **R** | I | **C** | I | — | I |
| Derived state and fold | A | **R** | C | I | I | — | I |
| Structure plane | A | **R** | I | I | I | — | I |
| Experience model | A | C | **R** | I | C | — | I |
| Provenance graph | **A** | C | **R** | C | C | — | I |
| Trust and taint | A | C | R | **A/R** | I | — | I |
| Verification | A | R | **R** | C | I | — | I |
| Contradiction | A | C | **R** | I | C | — | I |
| Governance Gate | **A** | **R** | C | C | C | — | I |
| Policy DSL | A | **R** | C | **C** | I | — | I |
| Projection engine | **A** | **R** | C | C | C | — | I |
| Token economics model | **A/R** | C | C | I | **C** | — | I |
| MCP and API | A | **R** | **R** | C | I | C | I |
| Security controls | C | C | C | **A/R** | I | I | C |
| Observability | A | **R** | C | I | C | C | C |
| Evaluation | **A** | C | C | I | **R** | I | C |
| Dashboard | I | I | C | I | C | **R** | I |
| Enterprise and control plane | A | C | **R** | **R** | I | C | C |
| Release and packaging | A | C | I | C | I | I | **R** |
| Documentation | **A** | R | R | R | R | R | R |

Two accountabilities are deliberately held by the Tech Lead rather than delegated: **the token
economics model** and **the evaluation design**. Both are places where a small methodological
compromise produces a large, flattering number, and both are where the project's credibility
actually lives.

## 46.4 Decision rights

| Decision | Who decides | Who must be consulted |
|---|---|---|
| New dependency | TL | Sec, Plat |
| Change to a trade rejection (TR1–TR7) | TL + sponsor | Whole team |
| Performance budget change | TL | Sys, Plat |
| Trust model change | Sec | TL |
| Publishing an evaluation result | TL + Res | Sec (for disclosure), sponsor |
| Shipping a default that measures net-negative | **Not permitted** | — |
| Adding an imperative surface outside Policies | **Not permitted** | — |

## 46.5 Rituals

| Ritual | Cadence | Purpose |
|---|---|---|
| Architecture review | Weekly, 60min | ADR proposals, critical-path risk |
| Budget review | Weekly, 30min | Latency, memory and token budgets against CI |
| Risk review | Fortnightly | Register items scoring 15+ |
| Red-team session | Monthly | Adversarial testing of trust and injection paths |
| Evaluation review | Fortnightly in P3+ | Pre-registrations, results, disclosure |
| Demo | End of phase | Exit gate walkthrough against the acceptance tests |

Exit gates are demonstrated by running the named acceptance tests live, not by reviewing a status
document.
