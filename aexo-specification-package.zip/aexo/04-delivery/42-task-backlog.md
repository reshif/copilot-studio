# 42 — Task Backlog

Every task carries: ID, title, phase, dependencies, estimate (points, per `41.3`), and the
acceptance tests that constitute its Definition of Done. Acceptance test IDs resolve in
`43-acceptance-test-catalog.md`.

Total: **214 tasks**, ~1,090 points.

---

## P0 — Foundations

### CAP — Capture

| ID | Title | Deps | Pts | DoD tests |
|---|---|---|---|---|
| AEXO-CAP-001 | Hook binary skeleton, stdin read, exit-0 discipline | — | 3 | AT-CAP-001, AT-CAP-008 |
| AEXO-CAP-002 | Canonical Activity Event struct + MessagePack framing | CAP-001 | 3 | AT-CAP-002 |
| AEXO-CAP-003 | Unix socket transport with 5ms connect timeout | CAP-002 | 3 | AT-CAP-003 |
| AEXO-CAP-004 | Windows named-pipe transport | CAP-002 | 3 | AT-CAP-003 |
| AEXO-CAP-005 | Spool fallback with O_APPEND and 256MB cap | CAP-003 | 5 | AT-CAP-004, AT-CAP-005 |
| AEXO-CAP-006 | Claude Code payload normalisation, all 31 events | CAP-002 | 8 | AT-CAP-006 |
| AEXO-CAP-007 | Claude Code verdict translation (exit 0 + additionalContext) | CAP-006 | 3 | AT-CAP-007 |
| AEXO-CAP-008 | Shell command lexer: quoting, pipes, redirects, sequencing | CAP-002 | 8 | AT-CAP-009 |
| AEXO-CAP-009 | Shell intent classifier for top-40 tools | CAP-008 | 8 | AT-CAP-010, AT-CAP-011 |
| AEXO-CAP-010 | Codex adapter over the shell parser | CAP-009 | 5 | AT-CAP-012 |
| AEXO-CAP-011 | Memory-mapped config fast path | CAP-001 | 3 | AT-CAP-013 |
| AEXO-CAP-012 | Cold-start benchmark harness, 3 platforms | CAP-001 | 5 | AT-CAP-014 |
| AEXO-CAP-013 | Malformed-input resilience suite | CAP-006 | 3 | AT-CAP-008 |
| AEXO-CAP-014 | OTel GenAI OTLP receiver in daemon | DMN-004 | 8 | AT-CAP-015 |
| AEXO-CAP-015 | Generic adapter contract + reference implementation | CAP-014 | 5 | AT-CAP-016 |

### DMN — Daemon

| ID | Title | Deps | Pts | DoD tests |
|---|---|---|---|---|
| AEXO-DMN-001 | Process skeleton, config, exclusive lock | — | 3 | AT-DMN-001 |
| AEXO-DMN-002 | Socket/pipe acceptor threads | DMN-001 | 5 | AT-DMN-008 |
| AEXO-DMN-003 | Bounded MPSC queue with depth metrics | DMN-002 | 5 | AT-DMN-003 |
| AEXO-DMN-004 | Single writer thread and append pipeline | DMN-003, EVT-002 | 8 | AT-STORE-001 |
| AEXO-DMN-005 | Group commit (5ms / 256 events) | DMN-004 | 5 | AT-PERF-005 |
| AEXO-DMN-006 | Backpressure tiers and per-kind drop accounting | DMN-003 | 5 | AT-DMN-003 |
| AEXO-DMN-007 | Spool drain, ordering, dedup | CAP-005, DMN-004 | 5 | AT-CAP-004 |
| AEXO-DMN-008 | Scheduler with the job table | DMN-001 | 5 | AT-DMN-009 |
| AEXO-DMN-009 | Filesystem watcher, event-driven, debounced | DMN-008 | 8 | AT-DMN-006 |
| AEXO-DMN-010 | Graceful shutdown within 2s | DMN-004 | 3 | AT-DMN-007 |
| AEXO-DMN-011 | Crash recovery: partial frame truncation | DMN-004 | 5 | AT-DMN-002 |
| AEXO-DMN-012 | Stale lock detection and safe break | DMN-001 | 3 | AT-DMN-001 |
| AEXO-DMN-013 | Local admin API (unix socket) | DMN-002 | 5 | AT-CLI-007 |
| AEXO-DMN-014 | Idle-resource conformance test | DMN-009 | 3 | AT-PERF-004 |

### EVT — Event store

| ID | Title | Deps | Pts | DoD tests |
|---|---|---|---|---|
| AEXO-EVT-001 | Envelope schema + JSON Schema artefact | — | 5 | AT-EVT-001 |
| AEXO-EVT-002 | RFC 8785 JCS canonicalisation | EVT-001 | 5 | AT-EVT-002 |
| AEXO-EVT-003 | BLAKE3 chain over envelopes | EVT-002 | 3 | AT-STORE-001 |
| AEXO-EVT-004 | Segment writer, sealing, manifest | EVT-003 | 8 | AT-STORE-003 |
| AEXO-EVT-005 | zstd compression on seal | EVT-004 | 3 | AT-STORE-007 |
| AEXO-EVT-006 | Anchor records every 10k events / 1h | EVT-003 | 3 | AT-STORE-001 |
| AEXO-EVT-007 | Content-addressed blob store | EVT-004 | 5 | AT-STORE-004 |
| AEXO-EVT-008 | Per-content encryption + keychain/KMS wrap | EVT-007 | 8 | AT-SEC-007 |
| AEXO-EVT-009 | Redaction scrubber: prefix-anchored patterns | EVT-001 | 8 | AT-SEC-004, AT-SEC-005 |
| AEXO-EVT-010 | Redaction TP corpus (secrets) | EVT-009 | 5 | AT-SEC-004 |
| AEXO-EVT-011 | Redaction FP corpus (ordinary prose) | EVT-009 | 5 | AT-SEC-005 |
| AEXO-EVT-012 | Quarantine path for scrubber faults | EVT-009 | 3 | AT-EVT-003 |
| AEXO-EVT-013 | Chain verification (anchor, full, range) | EVT-006 | 5 | AT-STORE-002 |
| AEXO-EVT-014 | Sealed-segment write refusal guard | EVT-004 | 2 | AT-STORE-006 |
| AEXO-EVT-015 | Bitemporal field handling across clock changes | EVT-001 | 5 | AT-STORE-008 |

### DER — Derived state

| ID | Title | Deps | Pts | DoD tests |
|---|---|---|---|---|
| AEXO-DER-001 | SQLite WAL store, schema v1, DDL artefact | — | 5 | AT-DER-001 |
| AEXO-DER-002 | Fold engine with total, pure handler contract | DER-001, EVT-004 | 8 | AT-DER-003 |
| AEXO-DER-003 | Determinism test harness (3 platforms) | DER-002 | 5 | AT-DER-001 |
| AEXO-DER-004 | Unknown-kind no-op counter | DER-002 | 2 | AT-DER-003 |
| AEXO-DER-005 | Checkpointing every 250k events | DER-002 | 8 | AT-DMN-004 |
| AEXO-DER-006 | Full rebuild path + progress reporting | DER-002 | 5 | AT-DER-002 |
| AEXO-DER-007 | Schema version detection and rebuild-on-mismatch | DER-006 | 3 | AT-DMN-005 |
| AEXO-DER-008 | Read snapshot semantics + staleness marker | DER-002 | 5 | AT-DER-004 |
| AEXO-DER-009 | Purity lint: forbid clock/random/IO in handlers | DER-002 | 3 | AT-DER-006 |
| AEXO-DER-010 | `knowledge_state` table, per-Epoch | DER-002 | 5 | AT-GATE-002 |

### STR — Structure (P0 slice)

| ID | Title | Deps | Pts | DoD tests |
|---|---|---|---|---|
| AEXO-STR-001 | tree-sitter embedding + grammar packaging (21 langs) | — | 8 | AT-SIDX-001 |
| AEXO-STR-002 | Symbol extraction and normalisation | STR-001 | 8 | AT-SIDX-001 |
| AEXO-STR-003 | Incremental reparse on watcher events | STR-002, DMN-009 | 8 | AT-SIDX-004, AT-SIDX-005 |
| AEXO-STR-004 | Structure tables in derived state | STR-002, DER-001 | 5 | AT-SIDX-006 |
| AEXO-STR-005 | Opaque-artefact handling for unknown languages | STR-002 | 3 | AT-SIDX-007 |
| AEXO-STR-006 | Batch pass on branch switch | STR-003 | 5 | AT-SIDX-008 |

### CLI / OBS / SEC / REL — P0 slice

| ID | Title | Deps | Pts | DoD tests |
|---|---|---|---|---|
| AEXO-CLI-001 | CLI skeleton, `--json` on every command, exit codes | — | 5 | AT-CLI-003, AT-CLI-004 |
| AEXO-CLI-002 | `aexo init` with harness detection and confirmation | CLI-001, CAP-006, CAP-010 | 8 | AT-CLI-001, AT-CLI-002 |
| AEXO-CLI-003 | `aexo start/stop/restart/status` | CLI-001, DMN-013 | 5 | AT-CLI-007 |
| AEXO-CLI-004 | `aexo doctor` full diagnostic | CLI-003, OBS-002 | 8 | AT-CLI-008 |
| AEXO-CLI-005 | `aexo verify` with exit code 3 | EVT-013 | 3 | AT-CLI-004 |
| AEXO-CLI-006 | `aexo rebuild` | DER-006 | 3 | AT-DER-002 |
| AEXO-OBS-001 | Health event taxonomy and emission | DMN-001 | 5 | AT-OBS-001 |
| AEXO-OBS-002 | Completeness metric by harness and kind | OBS-001, CAP-010 | 8 | AT-OBS-002, AT-DSH-002 |
| AEXO-OBS-003 | OTel export of AEXO's own telemetry | OBS-001 | 5 | AT-OBS-003 |
| AEXO-OBS-004 | Metrics rollup tables | DER-001 | 5 | AT-OBS-004 |
| AEXO-SEC-001 | Threat-model test matrix scaffold | — | 3 | AT-SEC-012 |
| AEXO-SEC-002 | Unicode evasion corpus (bidi, homoglyph, ZWJ, tags) | SEC-001 | 5 | AT-SEC-001 |
| AEXO-SEC-003 | File permission and socket mode enforcement | DMN-002 | 3 | AT-SEC-012 |
| AEXO-REL-001 | Cross-platform build matrix, static linking | — | 8 | AT-CAP-014 |
| AEXO-REL-002 | Dependency budget enforcement in CI | REL-001 | 3 | AT-REL-001 |
| AEXO-REL-003 | Reproducible builds + artefact signing + SBOM | REL-001 | 8 | AT-REL-002 |
| AEXO-REL-004 | Reference corpora (REF-DEV, REF-BIG, REF-CI) | — | 8 | AT-PERF-001 |
| AEXO-REL-005 | Performance CI with regression gates | REL-004 | 8 | AT-PERF-007 |
| AEXO-DOC-001 | P0 setup guide and troubleshooting | CLI-004 | 5 | — |

**P0 subtotal: 63 tasks, 318 points.**

---

## P1 — Experience

| ID | Title | Deps | Pts | DoD tests |
|---|---|---|---|---|
| AEXO-EXP-001 | Episode boundary detection (deterministic) | DER-002 | 5 | AT-EPI-001 |
| AEXO-EXP-002 | Episode structured field folds | EXP-001 | 8 | AT-EPI-001 |
| AEXO-EXP-003 | Outcome classifier, priority rules | EXP-002 | 5 | AT-EPI-002, AT-EPI-003 |
| AEXO-EXP-004 | Evidence records and citation rules | EXP-002 | 5 | AT-EXP-001 |
| AEXO-EXP-005 | Citable-source allow-list enforcement | EXP-004 | 3 | AT-EPI-004 |
| AEXO-EXP-006 | Claim schema, declarative-only enforcement | EXP-004 | 5 | AT-CLM-001 |
| AEXO-EXP-007 | Grounding check (deterministic) | EXP-006 | 5 | AT-CLM-002 |
| AEXO-EXP-008 | Scope inference by intersection | EXP-007 | 8 | AT-CLM-003 |
| AEXO-EXP-009 | Novelty check and support linking | EXP-008 | 5 | AT-CLM-004 |
| AEXO-EXP-010 | Band assignment rules | EXP-009 | 5 | AT-CLM-005 |
| AEXO-EXP-011 | Decision records | EXP-004 | 5 | AT-EXP-002 |
| AEXO-EXP-012 | Admission API in daemon | EXP-010, DMN-013 | 8 | AT-CLM-010 |
| AEXO-PROV-001 | Provenance graph tables and edges | EXP-004 | 8 | AT-PROV-001 |
| AEXO-PROV-002 | SUPPORTS / CONTRADICTS edge model (PROV-DM extension) | PROV-001 | 5 | AT-PROV-002 |
| AEXO-PROV-003 | Depth computation and hard cap at 2 | PROV-001 | 5 | AT-CLM-006 |
| AEXO-PROV-004 | Independence scoring | PROV-001 | 8 | AT-CLM-007 |
| AEXO-PROV-005 | Depth-limited traversal with truncation flag | PROV-001 | 5 | AT-PROV-003 |
| AEXO-PROV-006 | `why` resolution across claims, remedies, receipts | PROV-005 | 5 | AT-PROV-004 |
| AEXO-WRK-001 | Worker skeleton, job queue consumer | EXP-012 | 5 | AT-WRK-006 |
| AEXO-WRK-002 | Credential isolation and process boundary test | WRK-001 | 5 | AT-WRK-001 |
| AEXO-WRK-003 | Labelled-block prompt construction | WRK-001 | 5 | AT-WRK-002 |
| AEXO-WRK-004 | Prompt versioning and hash provenance | WRK-003 | 5 | AT-WRK-003 |
| AEXO-WRK-005 | Episode summarisation job | WRK-004, EXP-003 | 5 | AT-EPI-005 |
| AEXO-WRK-006 | Claim candidate generation job | WRK-004, EXP-012 | 8 | AT-CLM-008 |
| AEXO-WRK-007 | Strict JSON schema output, discard-on-malformed | WRK-006 | 3 | AT-CLM-008 |
| AEXO-WRK-008 | Reflection budget and degradation | WRK-005 | 5 | AT-WRK-005, AT-EPI-006 |
| AEXO-WRK-009 | Provider-outage resilience | WRK-008 | 3 | AT-WRK-004 |
| AEXO-IMP-001 | Import framework: idempotency, undo, reporting | EXP-012 | 8 | AT-IMP-003, AT-IMP-005 |
| AEXO-IMP-002 | OpenWolf `.wolf/` importer | IMP-001 | 8 | AT-IMP-001, AT-IMP-002 |
| AEXO-IMP-003 | projectmem importer | IMP-001 | 5 | AT-IMP-006 |
| AEXO-IMP-004 | Git history importer | IMP-001 | 5 | AT-IMP-007 |
| AEXO-IMP-005 | Import rate limiting vs live capture | IMP-001 | 5 | AT-IMP-004 |
| AEXO-API-001 | FastAPI skeleton, no log write handle | EXP-012 | 5 | AT-SRV-001 |
| AEXO-API-002 | Query routes (claims, episodes, evidence, decisions) | API-001 | 8 | AT-SRV-004 |
| AEXO-API-003 | Provenance routes | API-002, PROV-005 | 5 | AT-SRV-004 |
| AEXO-API-004 | Write routes through admission | API-001, EXP-012 | 5 | AT-SRV-001 |
| AEXO-API-005 | OpenAPI contract test | API-002 | 3 | AT-SRV-007 |
| AEXO-CLI-007 | `aexo why` | PROV-006 | 5 | AT-PROV-004 |
| AEXO-CLI-008 | `aexo note` / `decide` / `attest` | API-004 | 5 | AT-EXP-003 |
| AEXO-CLI-009 | `aexo claims` with filters | API-002 | 3 | AT-EXP-004 |
| AEXO-CLI-010 | `aexo import` / `--undo` | IMP-001 | 3 | AT-IMP-005 |
| AEXO-SEC-004 | Adversarial candidate suite (imperatives, laundering) | EXP-006 | 8 | AT-CLM-001 |
| AEXO-DOC-002 | Claim and Policy authoring guide | EXP-006 | 5 | — |

**P1 subtotal: 43 tasks, 236 points.**

---

## P2 — Judgement

| ID | Title | Deps | Pts | DoD tests |
|---|---|---|---|---|
| AEXO-JDG-001 | Trust lattice types, enforced at write | EXP-012 | 8 | AT-TRUST-001 |
| AEXO-JDG-002 | Taint propagation (minimum rule) | JDG-001 | 5 | AT-TRUST-002 |
| AEXO-JDG-003 | Labelled-quotation rendering for untrusted content | JDG-002 | 5 | AT-TRUST-003, AT-PRJ-010 |
| AEXO-JDG-004 | Attestation flow and trust elevation as new evidence | JDG-001 | 5 | AT-TRUST-004 |
| AEXO-JDG-005 | Verifier types: structural, pattern, artefact | DER-002, STR-004 | 8 | AT-VER-009 |
| AEXO-JDG-006 | Command verifier sandbox (netns, mounts, limits) | JDG-005 | 8 | AT-VER-003, AT-VER-004 |
| AEXO-JDG-007 | Verifier scheduling by band and by scope change | JDG-006, DMN-008 | 8 | AT-VER-005, AT-VER-008 |
| AEXO-JDG-008 | Result handling: pass/fail/error/timeout | JDG-007 | 5 | AT-VER-001, AT-VER-002 |
| AEXO-JDG-009 | Read-time decay computation | JDG-008 | 5 | AT-VER-006, AT-VER-007 |
| AEXO-JDG-010 | Broken-verifier detection and backoff | JDG-008 | 3 | AT-VER-003 |
| AEXO-JDG-011 | Scope-overlap index for candidate generation | DER-001 | 8 | AT-CON-002 |
| AEXO-JDG-012 | Tier 1: structural negation detection | JDG-011 | 8 | AT-CON-001 |
| AEXO-JDG-013 | Tier 2: verifier disagreement detection | JDG-008 | 5 | AT-CON-001 |
| AEXO-JDG-014 | Tier 3: value conflict detection | JDG-011 | 5 | AT-CON-001 |
| AEXO-JDG-015 | Tier 4: semantic detection, review-only routing | JDG-012, WRK-004 | 8 | AT-CON-004 |
| AEXO-JDG-016 | Classification: supersession / refinement / contradiction / apparent | JDG-012 | 8 | AT-CON-005, AT-CON-008 |
| AEXO-JDG-017 | Resolution events and reversibility | JDG-016 | 5 | AT-CON-006 |
| AEXO-JDG-018 | Unresolved-conflict ageing and surfacing | JDG-017 | 3 | AT-CON-007 |
| AEXO-GATE-001 | Gate skeleton, verdict types, recording all verdicts | DER-010 | 5 | AT-GATE-009 |
| AEXO-GATE-002 | Duplicate-read check via knowledge_state | GATE-001 | 5 | AT-GATE-001, AT-GATE-002 |
| AEXO-GATE-003 | AST normalisation: alpha-rename, literal bucketing | STR-002 | 8 | AT-GATE-003 |
| AEXO-GATE-004 | Remedy signature computation and store | GATE-003 | 8 | AT-GATE-003, AT-GATE-004 |
| AEXO-GATE-005 | Coarse signature fallback for large edits | GATE-004 | 5 | AT-GATE-010 |
| AEXO-GATE-006 | Repeat-failed-remedy check | GATE-004 | 5 | AT-GATE-003 |
| AEXO-GATE-007 | Claim-contradiction check in gate path | GATE-001, JDG-011 | 5 | AT-GATE-005 |
| AEXO-GATE-008 | Destructive-action rationale check | GATE-001 | 3 | AT-GATE-005 |
| AEXO-GATE-009 | Degradation path (15ms ceiling → allow) | GATE-001 | 5 | AT-GATE-006 |
| AEXO-GATE-010 | Warning renderer within 40–90 tokens | GATE-006 | 3 | AT-GATE-001 |
| AEXO-GATE-011 | Block mode behind enterprise policy flag | GATE-001 | 3 | AT-GATE-007, AT-GATE-008 |
| AEXO-GATE-012 | Gate purity trace test (no inference/network/creds) | GATE-001 | 3 | AT-GATE-005, AT-SEC-009 |
| AEXO-GATE-013 | Remedy-signature precision/recall corpus | GATE-004 | 8 | AT-GATE-003, AT-GATE-004 |
| AEXO-POL-001 | Policy DSL grammar | — | 8 | AT-POL-001 |
| AEXO-POL-002 | Type checker and totality proof | POL-001 | 8 | AT-POL-004 |
| AEXO-POL-003 | Capability-free evaluator construction | POL-002 | 5 | AT-POL-001 |
| AEXO-POL-004 | Required-test enforcement at activation | POL-002 | 5 | AT-POL-002, AT-POL-003 |
| AEXO-POL-005 | Scope-indexed compiled decision table | POL-002 | 8 | AT-POL-005 |
| AEXO-POL-006 | Policy version hashing on verdicts | POL-005 | 3 | AT-POL-006 |
| AEXO-POL-007 | Human-identity authorisation for policy writes | API-004 | 5 | AT-SEC-011, AT-SRV-002 |
| AEXO-POL-008 | Activation / deactivation events | POL-004 | 3 | AT-POL-007 |
| AEXO-SEC-005 | Injection fuzz corpus: all 10 ingestion routes | SEC-002 | 13 | AT-SEC-001 |
| AEXO-SEC-006 | Injection fuzz CI gate (zero-escape) | SEC-005 | 5 | AT-SEC-001 |
| AEXO-SEC-007 | Retrieval anomaly detection signals | JDG-011 | 8 | AT-SEC-010 |
| AEXO-SEC-008 | Crypto-shred implementation and `FORGET` events | EVT-008 | 8 | AT-SEC-007 |
| AEXO-CLI-011 | `aexo policy add/list/test/remove` | POL-004 | 5 | AT-POL-002 |
| AEXO-CLI-012 | `aexo resolve` | JDG-017 | 3 | AT-CON-006 |
| AEXO-CLI-013 | `aexo forget` with explicit confirmation | SEC-008 | 5 | AT-CLI-006 |
| AEXO-STR-007 | SCIP/LSIF ingest, `indexed` tier | STR-004 | 8 | AT-SIDX-002 |
| AEXO-STR-008 | LSP client, `live` tier with degradation | STR-007 | 8 | AT-SIDX-003 |
| AEXO-STR-009 | Structural query API with precision labels | STR-008 | 8 | AT-SIDX-002 |
| AEXO-DOC-003 | Policy DSL reference | POL-001 | 5 | — |

**P2 subtotal: 51 tasks, 292 points.**

---

## P3 — Projection

| ID | Title | Deps | Pts | DoD tests |
|---|---|---|---|---|
| AEXO-PROJ-001 | Candidate assembly from claims/policies/structure/gate | JDG-009, POL-005 | 8 | AT-PRJ-001 |
| AEXO-PROJ-002 | Deterministic scoring with component recording | PROJ-001 | 8 | AT-PRJ-007 |
| AEXO-PROJ-003 | Lifetime-cost model `1.25 + 0.10(T−1)` | PROJ-002 | 5 | AT-PRJ-006 |
| AEXO-PROJ-004 | Expected-remaining-turns estimator | PROJ-003 | 5 | AT-PRJ-006 |
| AEXO-PROJ-005 | Reserved sections (policy, conflict, health, gate) | PROJ-001 | 5 | AT-PRJ-005 |
| AEXO-PROJ-006 | Budget enforcement and graceful degradation | PROJ-005 | 5 | AT-PRJ-002, AT-PRJ-005 |
| AEXO-PROJ-007 | Epoch-scoped seen-set and delta computation | DER-010 | 8 | AT-PRJ-003 |
| AEXO-PROJ-008 | Tail-only injection; no-prefix-mutation guard | PROJ-007 | 5 | AT-PRJ-004 |
| AEXO-PROJ-009 | Cache-boundary estimator with configurable TTL regime | PROJ-003 | 8 | AT-PRJ-006 |
| AEXO-PROJ-010 | Deterministic renderer (band, evidence, age) | PROJ-006 | 8 | AT-PRJ-001, AT-PRJ-009 |
| AEXO-PROJ-011 | Receipt generation and events | PROJ-010 | 5 | AT-PRJ-007 |
| AEXO-PROJ-012 | Dispute channel and weight feedback | PROJ-011 | 5 | AT-PRJ-008 |
| AEXO-PROJ-013 | Session-start orientation bundle | PROJ-010 | 5 | AT-PRJ-002 |
| AEXO-PROJ-014 | Post-compaction re-anchor bundle | PROJ-013 | 5 | AT-PRJ-002 |
| AEXO-PROJ-015 | Health notice injection | OBS-002, PROJ-005 | 3 | AT-OBS-005 |
| AEXO-PROJ-016 | Golden-bundle token budget tests | PROJ-013 | 5 | AT-PRJ-002 |
| AEXO-MCP-001 | MCP server skeleton, stateless, stdio + HTTP | PROJ-010 | 8 | AT-MCP-001 |
| AEXO-MCP-002 | `server/discover` capability negotiation | MCP-001 | 3 | AT-MCP-006 |
| AEXO-MCP-003 | `aexo_recall` | MCP-001, PROJ-010 | 5 | AT-MCP-005 |
| AEXO-MCP-004 | `aexo_why` | MCP-001, PROV-006 | 3 | AT-PROV-004 |
| AEXO-MCP-005 | `aexo_structure` | MCP-001, STR-009 | 3 | AT-SIDX-002 |
| AEXO-MCP-006 | `aexo_history` | MCP-001 | 3 | AT-EXP-005 |
| AEXO-MCP-007 | `aexo_attest` with MRTR `input_required` | MCP-001, JDG-004 | 5 | AT-MCP-004 |
| AEXO-MCP-008 | `aexo_note` / `aexo_decide` | MCP-001, API-004 | 3 | AT-EXP-003 |
| AEXO-MCP-009 | `aexo_dispute` | MCP-001, PROJ-012 | 3 | AT-PRJ-008 |
| AEXO-MCP-010 | `aexo_policy_check` | MCP-001, POL-005 | 3 | AT-POL-005 |
| AEXO-MCP-011 | `aexo_budget` | MCP-001, OBS-005 | 3 | AT-CLI-005 |
| AEXO-MCP-012 | Tool-description token budget golden test (≤450) | MCP-011 | 3 | AT-MCP-002 |
| AEXO-MCP-013 | Failure behaviour: successful responses with bad news | MCP-001 | 5 | AT-MCP-003 |
| AEXO-MCP-014 | Tasks extension for long operations | MCP-001 | 5 | AT-MCP-007 |
| AEXO-OBS-005 | Net token accounting (avoided/injected/cache/net) | PROJ-011 | 8 | AT-CLI-005 |
| AEXO-OBS-006 | ESK computation with denominator reporting | OBS-005 | 5 | AT-EVAL-002 |
| AEXO-CLI-014 | `aexo recall` | PROJ-010 | 3 | AT-PRJ-001 |
| AEXO-CLI-015 | `aexo budget` | OBS-005 | 3 | AT-CLI-005 |
| AEXO-CLI-016 | `aexo completeness` | OBS-002 | 3 | AT-OBS-002 |
| AEXO-CLI-017 | `aexo export` and `aexo query` (DuckDB) | API-002 | 5 | AT-SRV-006 |
| AEXO-DOC-004 | Token economics explainer for users | OBS-005 | 5 | — |

**P3 subtotal: 37 tasks, 178 points.**

---

## P4 — Proof

| ID | Title | Deps | Pts | DoD tests |
|---|---|---|---|---|
| AEXO-EVAL-001 | Shadow mode (compute, never inject) | PROJ-011 | 8 | AT-EVAL-003 |
| AEXO-EVAL-002 | Paired A/B runner with seed control | EVAL-001 | 8 | AT-EVAL-001 |
| AEXO-EVAL-003 | Counterfactual replay engine | EVAL-001 | 8 | AT-EVAL-004 |
| AEXO-EVAL-004 | Seeded-defect corpus: 30 repositories | EVAL-002 | 21 | AT-EVAL-007 |
| AEXO-EVAL-005 | Task definitions reproducing failed remedies | EVAL-004 | 13 | AT-EVAL-007 |
| AEXO-EVAL-006 | Metric implementations (ESK, prevention rate, deltas) | OBS-006 | 8 | AT-EVAL-002 |
| AEXO-EVAL-007 | Pre-registration format and enforcement | EVAL-006 | 5 | AT-EVAL-001 |
| AEXO-EVAL-008 | Statistical reporting (effect sizes, CIs) | EVAL-006 | 8 | AT-EVAL-002 |
| AEXO-EVAL-009 | Provenance stamping of all results | EVAL-008 | 3 | AT-EVAL-001 |
| AEXO-EVAL-010 | Negative-result publication path | EVAL-008 | 3 | AT-EVAL-006 |
| AEXO-EVAL-011 | Determinism of recorded AEXO-side decisions | EVAL-002 | 5 | AT-EVAL-005 |
| AEXO-EVAL-012 | Public harness packaging | EVAL-005 | 8 | AT-EVAL-007 |
| AEXO-DSH-001 | SPA skeleton and API client | API-002 | 5 | AT-DSH-006 |
| AEXO-DSH-002 | Health view | OBS-002 | 5 | AT-DSH-005 |
| AEXO-DSH-003 | Completeness view with structural gaps | OBS-002 | 5 | AT-DSH-002 |
| AEXO-DSH-004 | Knowledge and provenance views | API-003 | 8 | AT-DSH-003 |
| AEXO-DSH-005 | Contradictions view, no bulk resolve | JDG-018 | 5 | AT-DSH-004 |
| AEXO-DSH-006 | Economics view with net and counterfactual coverage | OBS-005 | 8 | AT-DSH-001 |
| AEXO-DSH-007 | Receipts view with disputes | PROJ-012 | 5 | AT-PRJ-008 |
| AEXO-DSH-008 | Audit view | EVT-013, SEC-008 | 5 | AT-SEC-006 |
| AEXO-DSH-009 | Read-only enforcement (no claim editing) | DSH-004 | 3 | AT-DSH-004 |
| AEXO-DOC-005 | Evaluation methodology paper | EVAL-008 | 8 | — |

**P4 subtotal: 22 tasks, 165 points.**

---

## P5 — Enterprise

| ID | Title | Deps | Pts | DoD tests |
|---|---|---|---|---|
| AEXO-ENT-001 | PostgreSQL derived-state backend | DER-001 | 13 | AT-DER-002 |
| AEXO-ENT-002 | Tenant ID on every derived row | ENT-001 | 8 | AT-SRV-003 |
| AEXO-ENT-003 | Query-layer isolation enforcement | ENT-002 | 8 | AT-SRV-003 |
| AEXO-ENT-004 | Adversarial cross-tenant test suite | ENT-003 | 8 | AT-SRV-003 |
| AEXO-ENT-005 | Per-tenant key material and separate blob stores | EVT-008, ENT-002 | 8 | AT-ENT-001 |
| AEXO-ENT-006 | OIDC authentication | API-001 | 8 | AT-SRV-005 |
| AEXO-ENT-007 | SCIM provisioning | ENT-006 | 8 | AT-ENT-002 |
| AEXO-ENT-008 | mTLS between services | ENT-006 | 5 | AT-ENT-003 |
| AEXO-ENT-009 | KMS/HSM integration and BYOK | EVT-008 | 13 | AT-CTL-006 |
| AEXO-ENT-010 | Fleet-wide key rotation orchestration | ENT-009 | 8 | AT-CTL-006 |
| AEXO-ENT-011 | Control plane service skeleton | ENT-006 | 8 | AT-CTL-001 |
| AEXO-ENT-012 | Signed policy bundle distribution | ENT-011, POL-005 | 8 | AT-CTL-002 |
| AEXO-ENT-013 | Policy precedence enforcement (org > project > local) | ENT-012 | 5 | AT-CTL-003 |
| AEXO-ENT-014 | Fleet health aggregation | ENT-011, OBS-002 | 8 | AT-CTL-007 |
| AEXO-ENT-015 | Metadata-only transport by default | ENT-014 | 5 | AT-CTL-004 |
| AEXO-ENT-016 | Payload forwarding opt-in with local disclosure | ENT-015 | 5 | AT-CTL-005 |
| AEXO-ENT-017 | Retention governance push | ENT-012 | 5 | AT-ENT-004 |
| AEXO-ENT-018 | Fleet-scale crypto-shred | SEC-008, ENT-010 | 8 | AT-SEC-007 |
| AEXO-ENT-019 | EU AI Act logging posture evidence pack | ENT-014 | 8 | AT-ENT-005 |
| AEXO-ENT-020 | ISO 42001 control mapping | ENT-019 | 8 | AT-ENT-005 |
| AEXO-ENT-021 | SOC 2 evidence automation | ENT-019 | 8 | AT-ENT-005 |
| AEXO-REL-006 | Offline installer, no network at install | REL-003 | 8 | AT-REL-003 |
| AEXO-REL-007 | Air-gapped operation mode | REL-006 | 8 | AT-REL-003 |
| AEXO-DOC-006 | Enterprise deployment and compliance guide | ENT-021 | 8 | — |

**P5 subtotal: 24 tasks, 187 points.**

---

## Totals

| Phase | Tasks | Points | Weeks | Team |
|---|---|---|---|---|
| P0 | 63 | 318 | 6 | 3 |
| P1 | 43 | 236 | 6 | 4 |
| P2 | 51 | 292 | 8 | 5 |
| P3 | 37 | 178 | 6 | 5 |
| P4 | 22 | 165 | 6 | 5 |
| P5 | 24 | 187 | 10 | 6 |
| **Total** | **240** | **1,376** | **42** | peak 6 |

Points exceed raw capacity by design: `41.3` allocates 15% per phase to cross-area integration and
assumes ~70% of an engineer-week is task-productive. See `47-estimates-and-budget.md` for the
reconciliation.
