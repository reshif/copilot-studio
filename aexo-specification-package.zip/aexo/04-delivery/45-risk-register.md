# 45 — Risk Register

Scored as Likelihood (1–5) × Impact (1–5). Anything at 15+ is a standing agenda item; anything at
20+ has a named owner and a weekly check.

## 45.1 Product and evidence risks

| ID | Risk | L | I | Score | Mitigation | Trigger to act |
|---|---|---|---|---|---|---|
| R-01 | Effectiveness turns out to be marginal | 3 | 5 | **15** | P4 exists precisely to find this early; shadow mode gives signal before A/B spend; publish nulls | Shadow-mode would-have-fired rates below 10% |
| R-02 | Claims are noise — low signal, high volume | 4 | 4 | **16** | Strict admission; scope intersection; independence scoring; band caps; dispute channel as a quality signal | Dispute rate >20 per 100 injections |
| R-03 | Net token delta is negative in common configurations | 3 | 4 | 12 | Lifetime-cost scoring; delta injection; no prefix mutation; `aexo budget` shows net by default | Any shipped default config measures net-negative |
| R-04 | The Gate warns too often and gets ignored | 4 | 3 | 12 | False-warning rate is a first-class metric; signature threshold tuned on a labelled corpus, not intuition | False-warning rate >15% |
| R-05 | Agents ignore injected context entirely | 3 | 4 | 12 | Injection precision measured; receipts + disputes; tools over dumps | Injection precision <30% |

## 45.2 Technical risks

| ID | Risk | L | I | Score | Mitigation | Trigger |
|---|---|---|---|---|---|---|
| R-10 | Hook latency makes AEXO feel slow | 3 | 5 | **15** | Rust binary; measured budgets in CI; spool fallback; degradation path | p99 >10ms on any platform |
| R-11 | Remedy signatures are too coarse or too fine | 4 | 4 | **16** | Labelled corpus (GATE-013); report precision and recall; coarse fallback for large edits | Either metric below target on the corpus |
| R-12 | Fold determinism rots silently | 3 | 5 | **15** | Purity lint; weekly genesis-rebuild equivalence test in CI | Any equivalence failure |
| R-13 | Shell parser coverage for Codex is inadequate | 4 | 3 | 12 | Top-40 coverage timeboxed; unknown classified as `other`, never guessed; completeness reported honestly | Completeness <60% on Codex sessions |
| R-14 | Contradiction detection does not scale | 2 | 4 | 8 | Scope-indexed candidates; incremental only; benchmarked at 200k claims | p99 >300ms at scale |
| R-15 | Structure indexing bloats storage on monorepos | 3 | 3 | 9 | Commit retention limits with Claim-referenced pinning | Index >2× log size |
| R-16 | SQLite becomes the bottleneck for teams | 3 | 3 | 9 | PostgreSQL backend planned for P5; derived state is disposable so migration is a rebuild | Concurrent readers >64 |

## 45.3 Ecosystem and dependency risks

| ID | Risk | L | I | Score | Mitigation | Trigger |
|---|---|---|---|---|---|---|
| R-20 | Harness hook APIs change without notice | 4 | 4 | **16** | Adapter isolation; OTel ingest as the harness-independent path; conformance tests per harness version | Any adapter test failure on a new harness release |
| R-21 | Provider cache semantics change silently | 4 | 3 | 12 | Configurable TTL regime; assumptions recorded on receipts; measured against observed billing where available | Observed cost diverges >15% from model |
| R-22 | MCP spec churn breaks the server | 3 | 3 | 9 | Target a pinned revision; capability negotiation; keep the server thin so rewrites are cheap | Breaking change in a target revision |
| R-23 | A dominant harness ships equivalent memory natively | 3 | 4 | 12 | Differentiate on provenance, verification and audit — the parts a harness vendor is least likely to build; stay harness-agnostic | Native feature covers gate + provenance |
| R-24 | tree-sitter grammar quality varies by language | 3 | 2 | 6 | Precision labels; per-language conformance tests; opaque fallback | Symbol extraction accuracy <90% for a shipped language |

## 45.4 Security and compliance risks

| ID | Risk | L | I | Score | Mitigation | Trigger |
|---|---|---|---|---|---|---|
| R-30 | Memory poisoning succeeds in the field | 2 | 5 | 10 | Trust lattice; depth limits; declarative-only claims; injection fuzz gate; anomaly detection | Any confirmed field incident |
| R-31 | Redaction false negative leaks a credential | 2 | 5 | 10 | TP/FP corpora in CI; encryption at rest limits blast radius; `aexo forget` for remediation | Any leak found |
| R-32 | Redaction false positives corrupt captured content | 3 | 3 | 9 | FP corpus; prefix-anchored minimum-length patterns; redaction counts visible | Any FP in the prose corpus |
| R-33 | Crypto-shred fails to make data unrecoverable | 2 | 5 | 10 | Key destruction verified by test; no plaintext caches; documented key hierarchy | Any recoverable payload post-shred |
| R-34 | Cross-tenant leak in enterprise topology | 2 | 5 | 10 | Row-level isolation; adversarial suite over every route; no cross-tenant blob dedup | Any foreign row returned |
| R-35 | Compliance mapping is wrong | 3 | 4 | 12 | Reviewed by counsel or a qualified assessor before any claim is made publicly | Assessor finding |

## 45.5 Delivery risks

| ID | Risk | L | I | Score | Mitigation | Trigger |
|---|---|---|---|---|---|---|
| R-40 | Scope creep from "enterprise-grade" pressure | 4 | 4 | **16** | Explicit non-goals (`03`); trade rejections (TR1–TR7); ADRs required for new dependencies | Any phase adding >15% unplanned scope |
| R-41 | Rust/Python split doubles maintenance | 3 | 3 | 9 | Sharp boundary at the admission API; shared schemas generated from one source of truth | Duplicate logic found in both languages |
| R-42 | The seeded corpus takes far longer than estimated | 4 | 3 | 12 | 21 points allocated; mined-vs-synthetic split allows partial delivery; corpus can grow post-launch | Corpus below 15 repos at P4 week 3 |
| R-43 | Key-person dependency on the systems side | 3 | 4 | 12 | Two engineers on every critical-path area; ADRs capture reasoning, not just decisions | Any critical-path area with one contributor for 4 weeks |
| R-44 | Team cannot be hired at the assumed profile | 3 | 4 | 12 | Phase staffing ramps; P0 needs 3; contract systems capacity if needed | P0 starts understaffed |

## 45.6 The risks that are not on this list

Three things that look like risks and are not:

- **"Results might be unimpressive."** That is the experiment working. R-01 covers the case where
  results are marginal *and* we fail to detect it early.
- **"Users might not adopt it."** Adoption is a downstream consequence of R-02, R-04, R-05 and
  R-10. Listing it separately invites treating it as a marketing problem.
- **"The design is too strict."** Strictness is the product. Loosening admission to increase Claim
  volume would trade the only defensible differentiator for a vanity metric.
