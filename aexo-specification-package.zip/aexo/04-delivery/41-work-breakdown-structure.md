# 41 — Work Breakdown Structure

Areas, their owning discipline, and the task-ID prefix used in `42-task-backlog.md`.

## 41.1 Areas

| Prefix | Area | Discipline | Phases |
|---|---|---|---|
| `CAP` | Capture runtime and adapters | Systems (Rust) | P0, P1 |
| `DMN` | Daemon, scheduler, lifecycle | Systems (Rust) | P0–P3 |
| `EVT` | Event store, chain, blobs, retention | Systems (Rust) | P0, P5 |
| `DER` | Derived state, fold, checkpoints | Systems (Rust) | P0, P1 |
| `STR` | Structure indexer, tiers, queries | Systems (Rust) | P0–P2 |
| `EXP` | Episodes, evidence, claims | Backend (Python) | P1 |
| `PROV` | Provenance graph, depth, independence | Backend | P1 |
| `JDG` | Trust, verification, contradiction | Backend + Systems | P2 |
| `GATE` | Governance Gate, remedy signatures | Systems | P2 |
| `POL` | Policy DSL and compiler | Systems | P2 |
| `PROJ` | Projection engine, budgets, receipts | Systems | P3 |
| `MCP` | MCP server | Systems | P3 |
| `API` | REST/gRPC server | Backend | P1, P3, P5 |
| `CLI` | Command-line interface | Systems | P0–P3 |
| `WRK` | Reflection worker | Backend | P1 |
| `IMP` | Importers and migration | Backend | P1 |
| `EVAL` | Evaluation harness and corpus | Research | P4 |
| `DSH` | Dashboard | Frontend | P4 |
| `SEC` | Security controls and fuzz suites | Security | P0–P5 |
| `OBS` | Observability, metrics, completeness | Systems | P0–P3 |
| `ENT` | Multi-tenancy, control plane, compliance | Backend + Security | P5 |
| `REL` | Build, packaging, release, SBOM | Platform | P0–P5 |
| `DOC` | Documentation, runbooks | All | P0–P5 |

## 41.2 Dependency spine

```
CAP ─┬─▶ EVT ─▶ DER ─┬─▶ EXP ─▶ PROV ─┬─▶ JDG ─┬─▶ GATE ─┬─▶ PROJ ─▶ MCP ─▶ EVAL
     │               │                │        │         │
     └─▶ DMN ────────┘                └─ POL ──┘         └─▶ API ─▶ DSH
                                                                     │
                                       STR ─────────────────────────┘
                          SEC, OBS, REL, DOC run across all phases
```

Critical path: `CAP → EVT → DER → EXP → JDG → GATE → PROJ → EVAL`. Anything on it is protected;
anything off it can slip a sprint without moving the end date.

## 41.3 Estimation basis

- One point ≈ one engineer-day of focused work by someone familiar with the codebase.
- Estimates include unit tests and the task's own acceptance tests. They do not include cross-area
  integration, which is budgeted separately at 15% per phase.
- Systems tasks in Rust carry a 1.25× multiplier over equivalent Python work for the first two
  phases, reflecting build/iteration cost, dropping to 1.1× thereafter.
- Anything estimated above 8 points is decomposed before it enters a sprint.

## 41.4 Definition of Done (applies to every task)

1. Code merged with tests passing.
2. The task's named acceptance tests implemented and passing in CI.
3. Performance budgets for the touched paths verified unchanged or improved.
4. Security suites unaffected (fuzz, redaction, tenancy where applicable).
5. Observability: new failure modes emit health events; new degradations are counted.
6. Documentation updated in the same PR — spec deltas, CLI help, runbook entries.
7. No new dependency without an ADR entry against the dependency budget (`2E`).
8. For anything on the agent's synchronous path: latency measured, not assumed.
