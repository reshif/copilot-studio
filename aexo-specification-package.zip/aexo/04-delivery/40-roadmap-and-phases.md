# 40 — Roadmap and Phases

Six phases, ~42 weeks, peak team 6. Each phase ends with a demonstrable capability and an exit gate
that is testable, not a status opinion.

## 40.1 Overview

| Phase | Name | Duration | Team | Ends with |
|---|---|---|---|---|
| **P0** | Foundations | 6 wk | 3 | Capture and log that can be audited |
| **P1** | Experience | 6 wk | 4 | Episodes, Evidence, Claims with provenance |
| **P2** | Judgement | 8 wk | 5 | Trust, verification, contradiction, Gate |
| **P3** | Projection | 6 wk | 5 | Cache-aware injection with receipts |
| **P4** | Proof | 6 wk | 5 | Published, reproducible effectiveness results |
| **P5** | Enterprise | 10 wk | 6 | Multi-tenant, control plane, compliance evidence |

Phases are sequential in dependency but overlap in staffing: P1 design starts in P0 week 4.

## 40.2 P0 — Foundations (weeks 1–6)

**Goal:** every relevant thing an agent does is captured, immutably, verifiably, without the
developer noticing.

Deliverables:
- `aexo-hook` for Claude Code (all relevant events) and Codex (with the shell parser)
- `aexo-daemon` with the single-writer append path, chain, anchors, segments, blobs
- Redaction on the append path with both TP and FP suites
- Derived state fold with determinism tests
- `aexo init`, `status`, `doctor`, `verify`
- OTel GenAI ingest path
- Performance harness and the REF corpora

**Exit gate (all must pass):**
1. A 4-hour real coding session produces a chain that verifies INTACT.
2. Hook p99 within budget on all three platforms.
3. Full genesis rebuild is byte-identical to incremental state.
4. Zero redaction false positives on the prose corpus; zero false negatives on the secrets corpus.
5. `aexo doctor` correctly reports a deliberately broken installation.
6. Daemon idle CPU ≤1% over 24h.

**Risk:** the shell parser for Codex is underestimated. Mitigation: timebox to 2 weeks, ship the
top-40-tool coverage, classify the rest as `other` honestly.

## 40.3 P1 — Experience (weeks 7–12)

**Goal:** raw events become structured, citable experience.

Deliverables:
- Episode consolidator with deterministic boundaries and outcome classification
- Evidence model and the citation rules
- Claim engine: candidate generation, grounding, scope intersection, novelty, band assignment
- Provenance graph with depth limits and independence scoring
- `aexo_why`, `aexo note`, `aexo decide`, `aexo attest`
- Reflection worker with credential isolation and prompt versioning
- Importers for OpenWolf and projectmem

**Exit gate:**
1. 100 real Episodes produce Claims where every Claim's provenance resolves to real evidence.
2. Zero admitted Claims contain imperatives (adversarial candidate suite).
3. Scope intersection demonstrably narrows over-broad candidates on a labelled test set.
4. Depth-limit test: a 3-deep derivation chain is refused.
5. Replaying the log reproduces the identical Claim set.

**Risk:** candidate quality is poor and Claims are noise. Mitigation: this is why P4 exists and why
nothing is claimed before it; also why admission is strict — a rejected candidate costs nothing.

## 40.4 P2 — Judgement (weeks 13–20)

**Goal:** the system knows what it can rely on, and says so.

Deliverables:
- Trust lattice enforced at write, with taint propagation
- Verifier runner with sandbox, scheduling, decay
- Contradiction engine tiers 1–3 (tier 4 opt-in)
- Governance Gate with remedy signatures
- Policy DSL, compiler, test requirement
- Injection fuzz suite in CI

**Exit gate:**
1. Injection fuzz suite passes with zero escapes across all ingestion routes.
2. Gate p99 ≤10ms with remedy-signature computation included.
3. Remedy signature matches an alpha-renamed, reformatted equivalent edit; does not match a
   semantically different one.
4. A failing verifier demotes rather than deletes; decay is correct after a 60-day daemon outage.
5. Contradiction detection at 200k Claims within 300ms p99.
6. A Policy attempting I/O fails to compile.

**Risk:** remedy signatures are too coarse (false warnings) or too fine (missed repeats). Mitigation:
tune against a labelled corpus built in P1; report precision and recall rather than shipping a
threshold on intuition.

## 40.5 P3 — Projection (weeks 21–26)

**Goal:** the agent receives the right thing, at the right time, at a defensible net cost.

Deliverables:
- Projection Engine with lifetime-cost scoring
- Delta injection; no prefix mutation
- Cache-boundary estimation
- Receipts and `aexo_dispute`
- MCP server with the full tool set and the 450-token description budget
- Session-start, post-compaction and health injection points
- `aexo budget` with net accounting

**Exit gate:**
1. Bundle determinism: identical state and intent → identical bytes.
2. Token budgets held on golden tests.
3. No code path mutates an established prefix (verified by trace).
4. Every injection has a receipt whose item tokens sum to the reported total.
5. `aexo budget` never reports gross without net.
6. Tool descriptions ≤450 tokens.

**Risk:** cache-boundary estimation is wrong because the provider changes behaviour without notice —
as happened in March 2026 when the default TTL moved from one hour to five minutes and inflated
bills 17–32%. Mitigation: estimation is configurable, measured against observed billing where
available, and the receipt records the assumption used so historical analysis stays interpretable.

## 40.6 P4 — Proof (weeks 27–32)

**Goal:** make the claim falsifiable, then test it, then publish whatever comes out.

Deliverables:
- Shadow mode
- Paired A/B runner
- Counterfactual replay
- Seeded-defect corpus (~30 repos)
- Statistical reporting with pre-registration
- Published harness and corpus
- Dashboard

**Exit gate:**
1. A pre-registered paired experiment completes with effect sizes and confidence intervals.
2. Shadow mode is provably zero-injection (byte-identical context).
3. A third party can run the published harness without access to internal data.
4. At least one negative or null result is published alongside positive ones.
5. Repeat-failure prevention rate is measured on the seeded corpus.

**Risk:** the results are unimpressive. This is not a project risk; it is the point. An honest null
result on a specific configuration is more valuable to the roadmap than an unmeasured launch, and
TR7 forbids claiming effectiveness without it.

## 40.7 P5 — Enterprise (weeks 33–42)

**Goal:** deployable in an organisation with auditors.

Deliverables:
- PostgreSQL backend, multi-tenancy with adversarial isolation tests
- Control plane: policy distribution, fleet health, aggregate metrics
- OIDC/SCIM, mTLS, KMS/HSM, BYOK
- Crypto-shred at fleet scale, retention governance
- Compliance evidence pack (EU AI Act logging posture, ISO 42001 controls mapping, SOC 2 evidence)
- Offline installer, SBOM, signed artefacts

**Exit gate:**
1. Cross-tenant adversarial query suite returns zero foreign rows.
2. Control plane offline for 7 days: no developer impact.
3. Fleet-wide key rotation completes with no payload loss.
4. Compliance mapping reviewed by counsel or a qualified assessor.
5. Offline install succeeds with no network access.

## 40.8 What is deliberately not on the roadmap

- Vector database in core (ADR-009). Retrieval is scope- and structure-driven; embeddings are an
  optional tier 4 aid, not the substrate.
- Graph database in core (ADR-010). Depth-limited traversal over SQLite is sufficient and removes
  an operational dependency.
- Hosted SaaS storing customer source-derived content by default. The local-first posture is a
  feature, and reversing it later is easier than reversing the opposite.
- An agent-facing chat UI. The agent is the UI.
