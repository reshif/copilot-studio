# 3D — REST / gRPC Server (`aexo-server`)

Python 3.12, FastAPI, Pydantic v2, Granian. Optional for solo use; required for dashboard, team and
enterprise topologies.

## 3D.1 Why FastAPI here and not on the hot path

Decided in ADR-004 (`2E`). Summary: this server handles human-rate and integration-rate traffic —
dashboard queries, exports, admin operations, webhooks. Latency budgets are in the tens of
milliseconds, not microseconds. FastAPI's schema generation, validation and ecosystem are worth
more than the throughput difference. The hot path is Rust; this is not the hot path.

Granian over Uvicorn for the Rust-based HTTP layer and lower per-request overhead, with Uvicorn
retained as a documented fallback.

## 3D.2 Surface

Full spec in `2D-api-surface-spec.md`. Grouped:

| Group | Routes | Auth |
|---|---|---|
| Query | `/v1/claims`, `/v1/episodes`, `/v1/evidence`, `/v1/decisions`, `/v1/events` | read |
| Provenance | `/v1/why/{id}`, `/v1/graph` | read |
| Projection | `/v1/bundles`, `/v1/receipts` | read |
| Write | `/v1/notes`, `/v1/attestations`, `/v1/decisions`, `/v1/disputes` | write |
| Policy | `/v1/policies` | **human identity required** |
| Admin | `/v1/rebuild`, `/v1/verify`, `/v1/forget`, `/v1/retention` | admin |
| Health | `/v1/health`, `/v1/metrics`, `/v1/completeness` | read |
| Export | `/v1/export/{format}` | read |

All writes go through the daemon's admission path. **The server never appends to the log
directly.** It has no write handle.

## 3D.3 Auth

| Topology | Mechanism |
|---|---|
| Local | Unix socket peer credentials; no tokens |
| Team | OIDC; short-lived tokens; role claims |
| Enterprise | OIDC + SCIM provisioning; mTLS between services; per-tenant key isolation |

Roles: `reader`, `contributor`, `attester`, `policy_author`, `admin`. `policy_author` requires a
human identity assertion — a service account cannot hold it (`2H` S4).

## 3D.4 Multi-tenancy

Enterprise topology only. Row-level isolation with tenant ID on every derived row, enforced at the
query layer and tested adversarially. Separate log directories and separate key material per
tenant; there is no shared blob store across tenants, because content-addressed dedup across
tenants is a confidentiality leak.

## 3D.5 Performance

| Route class | p95 | p99 |
|---|---|---|
| Simple query | 25ms | 80ms |
| Provenance graph | 60ms | 200ms |
| Aggregate/metrics | 100ms | 400ms |
| Export | streaming, first byte <500ms | — |

## 3D.6 Acceptance criteria

**AC-SRV-1.** Given the server process, when its open file handles are inspected, then it holds no
write handle on any log segment.

**AC-SRV-2.** Given a `policy_author` role assigned to a service account, when it posts a policy,
then the request is rejected because the actor is not human, and the attempt is logged.

**AC-SRV-3.** Given two tenants, when tenant A issues every query in the API surface with tenant B
identifiers, then zero rows from B are returned and each attempt is logged.

**AC-SRV-4.** Given a provenance graph query of depth 5 on REF-BIG, when it executes, then it
completes within 200ms at p99 or returns truncated with the truncation flagged.

**AC-SRV-5.** Given an expired token, when any route is called, then it returns 401 with no data,
and no partial response is emitted.

**AC-SRV-6.** Given an export of 1M events, when it is requested, then the response streams with
first byte under 500ms and constant server memory.

**AC-SRV-7.** Given an OpenAPI document generated from the running server, when it is validated,
then it matches the committed contract and a mismatch fails CI.
