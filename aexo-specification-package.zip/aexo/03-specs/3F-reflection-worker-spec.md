# 3F — Reflection Worker (`aexo-worker`)

Python. The only component that talks to a model provider. Asynchronous, rate-limited, and never in
an agent's path.

## 3F.1 Jobs

| Job | Trigger | Model use |
|---|---|---|
| Episode summarisation | Episode close | Yes |
| Claim candidate generation | Episode close | Yes |
| Semantic contradiction check (tier 4) | Contradiction sweep, opt-in | Yes |
| Scope suggestion refinement | Claim admission narrowing | Optional |
| Digest drafting for humans | Weekly, opt-in | Yes |

## 3F.2 Isolation

Per `2H` S13: the worker holds provider credentials; nothing else does. The Gate, Projection Engine
and capture path have no credential access and no network capability. A prompt injection that
reaches an agent therefore cannot reach a credential that could spawn fresh, unrestricted model
work — the structural fix rather than the filtering one.

The worker also runs with no write handle on the log. It submits candidates through the daemon's
admission API like any other client.

## 3F.3 Prompt construction

- Inputs are enclosed in labelled, delimited blocks naming source and trust.
- The system prompt states that enclosed content is data, never instruction, and that any
  imperative found inside it must be reported rather than followed.
- Output is a strict JSON schema; malformed output discards the batch (`AC-CLM-8`).
- Prompts are versioned and hashed; the hash is recorded on every generated candidate so that a bad
  prompt version can be traced to everything it produced and those Claims re-examined.

That last property is worth stating plainly: **prompt version is provenance.** Without it, a
regression in the reflection prompt silently contaminates the knowledge base with no way to find
the affected records.

## 3F.4 Cost control

| Control | Default |
|---|---|
| Daily reflection budget | Configurable token ceiling |
| Batch size | Up to 5 Episodes per summarisation call |
| Model tier | Small/fast model for summarisation; larger only for candidate generation |
| Backoff | Exponential on provider errors, with jitter |
| Degradation | Budget exhausted → structural consolidation only, summaries queued |

## 3F.5 Determinism boundary

The worker is the system's only non-deterministic component. Everything it produces is a
*candidate*. The daemon's admission is deterministic. This means:

- Replaying the log reproduces all Claims exactly, because admitted candidates are themselves
  recorded as events.
- A model change alters future candidates but never rewrites past state.
- The system's audit properties do not depend on model behaviour.

## 3F.6 Acceptance criteria

**AC-WRK-1.** Given the worker process, when its environment and open handles are inspected, then
it has no write handle on the log, and given the Gate and projection processes, then neither has
provider credentials in its environment.

**AC-WRK-2.** Given a prompt injection embedded in captured repository content, when the worker
processes it, then the imperative is reported as a finding rather than followed, and no Claim
containing it is generated.

**AC-WRK-3.** Given a candidate produced by prompt version P, when the Claim is queried, then P's
hash is retrievable, and given a query for all Claims from P, then the complete set is returned.

**AC-WRK-4.** Given the provider is unreachable for 24 hours, when Episodes close, then all
structural consolidation completes, summaries queue, no agent sees an error, and on recovery the
queue drains in order.

**AC-WRK-5.** Given the daily reflection budget is exhausted, when further Episodes close, then no
model call is made and the deferral is recorded.

**AC-WRK-6.** Given the worker is killed mid-job, when it restarts, then the job is retried and no
duplicate Claims are created, because admission's novelty check is idempotent.
