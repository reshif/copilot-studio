# 3C — MCP Server (`aexo-mcp`)

The harness-agnostic surface. Stateless, thin, fast to restart.

## 3C.1 Protocol posture

Targets MCP revision 2026-07-28. Design consequences:

- **Stateless core.** No session state held in the server; every call carries the context it needs
  or resolves it from the daemon. Harnesses restart MCP servers freely; that must cost nothing.
- **`server/discover`** implemented for capability negotiation.
- **MRTR** (`resultType: input_required`) used for the human-attestation flow: `aexo_attest` can
  return `input_required` when a claim needs confirmation, rather than blocking.
- **No Sampling.** Deprecated in the target revision, and AEXO's design forbids the server calling
  back into the model anyway (P4).
- **No SSE resumability** — removed in the target revision. Streaming, where used, is restartable
  from a sequence cursor instead.
- **Tasks extension** used for long-running operations (`aexo_rebuild`, deep verification) so they
  do not occupy a tool call.

Transport: stdio for local harnesses, streamable HTTP for remote. Enterprise auth extension for the
hosted topology.

## 3C.2 Tools

| Tool | Purpose | Typical tokens out |
|---|---|---|
| `aexo_recall` | Query-shaped retrieval of relevant experience | 400–900 |
| `aexo_why` | Provenance for a claim, remedy or receipt | 80–200 |
| `aexo_structure` | Structural query with precision label | 50–400 |
| `aexo_history` | What happened to this artefact/symbol | 100–400 |
| `aexo_attest` | Human confirms or denies a claim | 20 |
| `aexo_note` | Record an observation as evidence | 20 |
| `aexo_decide` | Record a decision with alternatives and rationale | 20 |
| `aexo_dispute` | Dispute an injection receipt | 20 |
| `aexo_policy_check` | Ask whether a planned action violates policy | 30–120 |
| `aexo_budget` | Report token accounting for this session | 60 |

**Tools over dumps (R3).** A tool costs nothing on turns where it is not called; a bundle costs its
lifetime multiplier every session. The only automatic injections are session start, post-compaction
re-anchor, gate warnings and health notices.

## 3C.3 Tool description discipline

MCP tool descriptions occupy context on every turn, in the cached prefix. The full tool set's
descriptions are budgeted at **≤450 tokens total**. Each description states what the tool returns
and when to call it, in one or two sentences. This is measured in CI as a golden test; a
description that grows the budget fails the build.

## 3C.4 Failure behaviour

| Condition | Response |
|---|---|
| Daemon unreachable | Tool returns a short, honest unavailability message; never an exception trace |
| Query exceeds budget | Truncated with an explicit marker and a narrower-query suggestion |
| Derived state rebuilding | Returns partial results with a staleness marker |
| Unknown tool arguments | Validation error naming the field |

An MCP error surfaces to the agent as a failed tool call, which wastes a turn. AEXO returns
successful responses containing bad news instead.

## 3C.5 Acceptance criteria

**AC-MCP-1.** Given a harness restarting the MCP server 50 times in a session, when each restart
completes, then no state is lost, no re-initialisation cost exceeds 200ms, and no event is
duplicated.

**AC-MCP-2.** Given the full tool set, when tool descriptions are tokenised, then the total is
≤450 tokens, and a PR that exceeds it fails CI naming the offending description.

**AC-MCP-3.** Given the daemon is stopped, when any tool is called, then the call returns
successfully with an unavailability message and no exception trace.

**AC-MCP-4.** Given `aexo_attest` on a claim requiring human confirmation, when it is called by an
agent, then it returns `input_required` per MRTR rather than blocking or auto-attesting.

**AC-MCP-5.** Given `aexo_recall` with a query matching 5,000 claims, when it is answered, then the
response is within budget, truncation is explicit, and a narrower query is suggested.

**AC-MCP-6.** Given `server/discover`, when a client negotiates, then AEXO's capabilities are
reported accurately including which optional extensions are active.

**AC-MCP-7.** Given a long-running rebuild, when it is invoked through MCP, then it is issued as a
Task and the tool call returns immediately with a task handle.

**AC-MCP-8.** Given any tool response, when it renders untrusted content, then the content is
labelled with source and trust level.
