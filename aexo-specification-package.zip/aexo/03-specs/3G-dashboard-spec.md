# 3G — Dashboard

A static SPA over the REST API. Read-mostly. Its purpose is to make the system's honesty visible.

## 3G.1 Views

| View | Answers |
|---|---|
| **Health** | Is capture complete? What is being dropped? What is degraded? |
| **Knowledge** | What does the system believe, at what band, with what evidence? |
| **Provenance** | For any claim: where did this come from, and what supports it? |
| **Contradictions** | What conflicts are unresolved, and for how long? |
| **Economics** | Avoided tokens, injected tokens, cache cost, **net** — with the counterfactual caveat |
| **Receipts** | What was injected, when, why, and was it disputed? |
| **Episodes** | Timeline of work with outcomes |
| **Audit** | Chain status, anchors, forgets, policy changes, attestations |

## 3G.2 The economics view is deliberately unflattering

It must show, on the same screen and with equal prominence:

- Tokens avoided (gross)
- Tokens injected (cost)
- Cache-mutation cost incurred
- **Net**
- Counterfactual coverage: what fraction of the "avoided" figure is measured against a controlled
  baseline versus estimated

A dashboard that shows only gross savings is marketing, and TR5 forbids it. If the net is negative
for a given configuration, the dashboard says so in the same typeface as everything else.

## 3G.3 Completeness view

Per harness, per event kind: captured, dropped, degraded, unsupported. Codex's Bash-only tool hooks
show as a structural coverage gap, not as a green tick.

## 3G.4 Non-goals

- No editing of Claims. Changes are events, made through the CLI or API with a reason.
- No "resolve all" bulk actions on contradictions. Bulk resolution is how a knowledge base becomes
  confidently wrong at scale.
- No chat interface. The agent is the interface.

## 3G.5 Acceptance criteria

**AC-DSH-1.** Given a session where injected tokens exceed avoided tokens, when the economics view
renders, then the net is displayed as negative with the same prominence as the gross figures.

**AC-DSH-2.** Given a Codex-only installation, when the completeness view renders, then non-Bash
tool coverage is shown as unsupported rather than as complete.

**AC-DSH-3.** Given any claim in the knowledge view, when its provenance is opened, then the full
evidence chain to depth 5 is displayed with bands, and truncation beyond 5 is marked.

**AC-DSH-4.** Given the dashboard, when a user attempts to edit a Claim's statement, then no such
control exists.

**AC-DSH-5.** Given events dropped due to backpressure, when the health view renders, then counts
by kind appear within one minute of the drop.

**AC-DSH-6.** Given the REST server is unavailable, when the dashboard loads, then it renders an
explicit unavailability state and no stale data presented as current.
