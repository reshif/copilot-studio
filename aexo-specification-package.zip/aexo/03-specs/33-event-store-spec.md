# 33 — Event Store

The system of record. Everything else is a cache.

## 33.1 Physical layout

```
$AEXO_HOME/
  log/
    000001.jsonl.zst      sealed segment
    000002.jsonl.zst      sealed segment
    000003.jsonl          open segment (uncompressed)
    anchors.jsonl         {seq, hash, ts, sig?}
    manifest.json         segment index: {file, first_seq, last_seq, first_hash, last_hash}
  blobs/
    b3/<aa>/<bb>/<full-hash>   content-addressed, encrypted
  derived/
    state.sqlite          derived projection (WAL)
    checkpoints/
  spool/
  run/
```

**Format: JSONL, one canonical JSON envelope per line.** Chosen over a binary format because a
system of record that requires our software to read is a system of record you cannot audit. `zcat |
jq` must work forever. The cost is size, and zstd recovers most of it (≈700MB per 1M events).

## 33.2 Envelope

Full schema in `06-appendix/schemas/`. The fields that matter here:

| Field | Purpose |
|---|---|
| `seq` | Total order, monotonic, gapless |
| `id` | ULID, globally unique, sortable |
| `prev_hash` / `hash` | Chain |
| `t_event` / `t_ingest` | Bitemporal pair (`2C`) |
| `kind` | Event type |
| `actor` | Who — human, agent, system, verifier |
| `context` | Project / Mission / Run / Agent / Epoch (`2B`) |
| `trust` | Trust level of the content (`2A`) |
| `payload` | Inline (<4KB) or `{blob: <hash>, size, media_type}` |
| `redactions` | `[{kind, count}]` — what was removed, never what it was |
| `schema_version` | Envelope schema version |

**The envelope never contains free text.** Free text lives in the payload, which may be shredded.
This separation is what makes crypto-shredding compatible with an immutable chain.

## 33.3 Segments

- Open segment is uncompressed for append efficiency.
- Sealed at 128MB or 24 hours.
- Sealing: fsync, compress with zstd-3, write manifest entry, fsync the manifest, delete the
  uncompressed file last. Crash at any point leaves a recoverable state.
- The manifest allows seeking to a sequence range without decompressing every segment.

## 33.4 Blob store

- Content-addressed by BLAKE3 of the plaintext.
- Encrypted at rest with a per-content key (`2H`).
- Deduplicated: the same file content read by twenty agents stores once. This is a large real
  saving on repositories where agents re-read the same files.
- Reference counted for retention, but **never garbage-collected below the retention floor** while
  any live Claim's provenance references the blob.

## 33.5 Reads

| Access pattern | Mechanism | Budget |
|---|---|---|
| By sequence | Manifest seek + scan | <5ms |
| By ID | Derived index → sequence | <2ms |
| Range scan | Sequential decompress | ≥200MB/s |
| Tail follow | Notification + incremental read | <10ms latency |
| By any attribute | **Not supported here** — use derived state | — |

The log is not a query engine. Any question more interesting than "what happened in this range"
goes to derived state or DuckDB (`2C`).

## 33.6 Integrity operations

| Command | Scope | Target |
|---|---|---|
| `aexo verify` | From the last anchor | <500ms |
| `aexo verify --full` | Genesis to head | ≥300MB/s |
| `aexo verify --range A:B` | Bounded | proportional |
| `aexo anchor --sign` | Sign the current head | — |

A break is reported with the exact sequence where the chain first fails, the expected hash and the
computed hash. Ambiguity here is useless in an audit.

## 33.7 What is never done to the log

Restating TR3, because it is the discipline most likely to erode under pressure:

- The log is **never** consolidated, summarised, compacted-with-loss, or rewritten.
- Retention removes whole *segments* past the retention horizon, or shreds *payloads*; it never
  edits envelopes.
- A correction is a new event. A retraction is a new event. A deletion of subject data is a
  `FORGET` event plus key destruction.
- There is no code path that opens a sealed segment for writing.

## 33.8 Acceptance criteria

**AC-STORE-1.** Given 1,000,000 appended events, when the chain is verified from genesis, then it
reports INTACT and completes at ≥300MB/s of decompressed input.

**AC-STORE-2.** Given a single flipped byte in a sealed segment envelope, when verification runs,
then it reports the exact sequence of the first break with expected and computed hashes.

**AC-STORE-3.** Given a crash during segment sealing at any of the five sealing steps, when the
daemon restarts, then no event is lost or duplicated and the manifest is consistent with the files
present.

**AC-STORE-4.** Given the same 2MB file content captured by 20 agents, when blob storage is
measured, then exactly one blob exists and 20 envelopes reference it.

**AC-STORE-5.** Given a `FORGET` for a subject, when it completes, then that subject's payloads are
undecryptable, the chain verifies INTACT, and the envelopes remain with their redaction and
provenance metadata intact.

**AC-STORE-6.** Given a sealed segment, when any code path attempts to open it for writing, then
the attempt fails and is recorded as a health event.

**AC-STORE-7.** Given `zstd -dc` and `jq` and no AEXO software, when an auditor inspects a sealed
segment, then every envelope is readable, self-describing, and includes its chain fields.

**AC-STORE-8.** Given events written across a daylight-saving transition and a clock adjustment,
when they are read back, then `seq` order is unchanged and `t_event` / `t_ingest` both remain
interpretable, with monotonic ordering preserved by sequence rather than by wall-clock.
