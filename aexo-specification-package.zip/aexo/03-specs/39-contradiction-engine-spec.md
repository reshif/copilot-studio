# 39 — Contradiction Engine

Implements `25`. Detects, classifies and routes conflicts between Claims. Never resolves a
substantive conflict autonomously.

## 39.1 Candidate generation

Only Claims with **overlapping scope** are compared. This is what keeps detection tractable at
200,000 Claims (`2I.7`): the `claim_scope_idx` yields candidates in O(log n) rather than comparing
all pairs.

Scope overlap is computed structurally — glob intersection, symbol identity, commit-range overlap —
not semantically.

## 39.2 Detection tiers

| Tier | Method | Confidence | Cost |
|---|---|---|---|
| 1 | Structural negation (same subject, negated predicate) | High | µs |
| 2 | Verifier disagreement (two Claims, incompatible verifier outcomes on the same target) | High | free (already computed) |
| 3 | Value conflict (same attribute, different asserted value) | High | µs |
| 4 | Semantic (embedding distance + entailment prompt) | Low | model call |

Tiers 1–3 are deterministic and run always. Tier 4 is optional, rate-limited, and its output is
**always** routed to human review — it can raise a conflict but never resolve one.

## 39.3 Classification

| Class | Meaning | Automatic action |
|---|---|---|
| `supersession` | Same subject, one strictly newer, evidence shows a change over time | Auto-resolve: mark older superseded, retain both |
| `refinement` | One is a narrower-scope special case of the other | Auto-resolve: both live, narrower wins in its scope |
| `contradiction` | Genuinely incompatible in the same scope at the same time | **Escalate** |
| `apparent` | Different scopes that looked overlapping | Auto-dismiss, record |

Only `supersession` and `refinement` are auto-resolved, and only when the deterministic tiers
established them. Everything ambiguous escalates.

## 39.4 Escalation behaviour

An unresolved `contradiction` does **not** silence either Claim. Both are injected, together, with
the conflict marked:

```
⚠ conflicting knowledge in this scope
  A: <statement>  [verified · 3 evidence · last verified 2d ago]
  B: <statement>  [observed · 1 evidence · 41d old]
  unresolved since 2026-08-14 · aexo_why(claim="A") · aexo resolve <id>
```

This is deliberate. Suppressing one side means the agent acts on a coin flip made by a heuristic.
Showing both, with their bands and ages, lets the agent — or the human — decide with the evidence
visible. Hiding conflict is how a memory system teaches an agent to be confidently wrong.

## 39.5 Resolution

Resolution is an event: `claim.contradiction.resolved` with actor, reason and chosen outcome
(`keep_a`, `keep_b`, `both_scoped`, `both_retired`, `new_claim`). Resolutions are auditable and
reversible — reversal is another event, never an edit.

Unresolved contradictions older than 30 days appear in the health notice and the dashboard. They
are a maintenance signal, like failing tests.

## 39.6 Acceptance criteria

**AC-CON-1.** Given two Claims with structurally negated predicates on the same subject and
overlapping scope, when detection runs, then a contradiction is raised at tier 1 with no model
call.

**AC-CON-2.** Given a repository with 200,000 Claims, when a new Claim is admitted, then detection
compares only scope-overlapping candidates and completes within 300ms at p99.

**AC-CON-3.** Given an unresolved contradiction relevant to the agent's current intent, when a
bundle is generated, then both Claims appear with their bands, ages and the conflict marker.

**AC-CON-4.** Given a tier-4 semantic detection, when it fires, then it is routed to review and
never auto-resolved regardless of model confidence.

**AC-CON-5.** Given Claim B was formed after a commit that changed the subject of Claim A, when
classification runs, then it is classified `supersession`, A is marked superseded, and both remain
queryable.

**AC-CON-6.** Given a resolution is recorded and later reversed, when the Claim history is
queried, then both the resolution and the reversal appear with actors and timestamps, and no record
was mutated.

**AC-CON-7.** Given contradictions unresolved for 31 days, when the health notice is generated,
then their count appears, capped at the notice's token budget.

**AC-CON-8.** Given two Claims whose scopes were mistakenly treated as overlapping, when
classification runs, then they are marked `apparent`, dismissed, and not re-raised on subsequent
sweeps.
