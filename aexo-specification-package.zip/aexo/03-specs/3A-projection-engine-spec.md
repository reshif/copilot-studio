# 3A — Projection Engine

Implements `26`. Decides what an agent sees, when, and at what cost. The component where token
economics is actually realised.

## 3A.1 Inputs

| Input | Source |
|---|---|
| Intent | Prompt text, current file, recent actions, active Mission |
| Epoch knowledge state | Derived state — what this Epoch already saw |
| Cache state | Estimated prefix length, turn index, TTL regime |
| Budget | Configured ceiling for this injection point |
| Candidate set | Claims, Policies, Decisions, structure facts, gate warnings |

## 3A.2 Selection

Scoring is deterministic and explainable — every selected item can be traced to its score
components, which is what makes `aexo_why` answerable.

```
score = w_relevance · relevance
      + w_band      · band_weight
      + w_recency   · recency
      + w_impact    · expected_action_impact
      − w_cost      · lifetime_token_cost
      − w_seen      · already_known_penalty
```

`lifetime_token_cost = tokens × (1.25 + 0.10 × (expected_remaining_turns − 1))`

This is the corrected multiplier from `13-token-economics.md`. Using raw token count instead
systematically under-prices early injections and over-prices late ones. Selection must price what
injection actually costs over the session, not what it costs once.

Reserved sections always ship regardless of score: active Policies in scope, unresolved
contradictions in scope, health degradation notices, and Gate warnings.

## 3A.3 Injection points and budgets

| Point | Budget | Content |
|---|---|---|
| Session start | 600–1,200 | Orientation: mission, active policies, top claims, health |
| Post-compaction | 200–400 | Re-anchor: mission, policies, what was in flight |
| Pre-tool (gate) | 40–90 | Warning only, when the Gate fires |
| On demand (`aexo_recall`) | 400–900 | Query-shaped |
| Delta | 20–40 header + content | Only what changed since last injection |

## 3A.4 Delta injection

The rule that follows from the cache math: **never mutate an established prefix mid-session.**

- Session-start content goes in the prefix, once.
- Everything after is appended at the tail.
- Each subsequent injection carries only the delta versus what this Epoch has already been shown,
  with a one-line header naming what changed.

A single mid-session prefix mutation on a 30k-token prefix costs roughly `1.15 × 30,000 ≈ 34,500`
token-equivalents in re-caching — more than an entire session's savings. The engine therefore has
no code path that rewrites earlier context.

## 3A.5 Cache-boundary awareness

The engine estimates whether an injection would land inside or after the cached prefix. If an
injection is unavoidable and would fall inside the boundary, the engine:

1. Prefers deferring it to the next natural breakpoint (session start, post-compaction), or
2. Emits it at the tail with an explicit note, or
3. If it is a reserved section, emits it anyway and records the cache-mutation cost on the receipt.

Cost is always recorded, never hidden. TR5: gross savings are never published without the
corresponding costs.

## 3A.6 Receipts

Every injection produces a receipt (`26`, `2G`):

```
{ receipt_id, at_seq, injection_point, items:[{type,id,score,tokens,band}],
  total_tokens, estimated_lifetime_cost, cache_position, budget, degraded }
```

Receipts are events. They are what makes the counterfactual harness (`44`) possible: you cannot
measure whether memory helped if you cannot say exactly what was shown.

The agent can dispute a receipt via `aexo.dispute`, which records a `projection.disputed` event
citing the receipt and the reason. Disputes feed selection-weight tuning and appear in the
dashboard. An agent telling you your memory was wrong is the highest-value signal the system can
receive, and no competing system collects it.

## 3A.7 Rendering rules

- Every Claim renders with its band, evidence count and age. Never a bare assertion.
- Untrusted content, if rendered, is enclosed in a labelled quotation naming source and trust
  (`2A`).
- Policies render as imperatives; Claims never do.
- Structure facts render with their precision label.
- The bundle is deterministic: same state, same intent, same budget → same bytes.

## 3A.8 Acceptance criteria

**AC-PRJ-1.** Given identical derived state, intent and budget, when a bundle is generated twice,
then the output is byte-identical.

**AC-PRJ-2.** Given a session-start bundle, when its tokens are counted, then it is within
600–1,200 and never exceeds 2,000.

**AC-PRJ-3.** Given an Epoch already shown item X, when a later injection occurs, then X is absent
and the delta header names only what changed.

**AC-PRJ-4.** Given any injection point, when content is emitted, then it is appended at the tail
and no previously emitted content is rewritten.

**AC-PRJ-5.** Given a budget too small for all reserved sections, when a bundle is generated, then
reserved sections ship, non-reserved are dropped, and the receipt records `degraded: true` with
what was omitted.

**AC-PRJ-6.** Given two candidate items of equal relevance but different token cost at turn 3 of an
expected 40-turn session, when scored, then the cheaper item's advantage reflects the lifetime
multiplier, not the raw token difference.

**AC-PRJ-7.** Given any bundle, when the receipt is inspected, then every rendered item appears
with its score components, and the sum of item tokens equals the reported total.

**AC-PRJ-8.** Given an agent calls `aexo.dispute` on a receipt, when it is processed, then a
`projection.disputed` event is recorded citing the receipt and reason, and it appears in the
dashboard within one refresh.

**AC-PRJ-9.** Given a Claim at band `observed` and one at `verified` both selected, when rendered,
then both display their band and evidence count, and neither is rendered as an instruction.

**AC-PRJ-10.** Given untrusted repository content selected for rendering, when it is emitted, then
it appears inside a labelled quotation naming its source and trust level, and never as a directive.
