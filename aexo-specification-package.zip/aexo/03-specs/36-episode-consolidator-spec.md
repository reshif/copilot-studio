# 36 — Episode Consolidator

Turns raw event ranges into Episodes: bounded, outcome-labelled units of work that Claims can cite.

## 36.1 Boundary detection

An Episode ends at the earliest of:
- `session.end`
- idle >20 minutes (configurable)
- 200 events since the Episode began
- an explicit `aexo episode close`
- a Mission change

Boundaries are detected deterministically by the daemon and recorded as events. **The LLM does not
decide where episodes begin or end.** Non-deterministic boundaries would make Episode identity
unstable and break citation.

## 36.2 What an Episode records

| Field | Source |
|---|---|
| `id`, `seq_range` | Deterministic |
| `context` | Project/Mission/Run/Agent/Epoch |
| `intent` | The prompt(s) that opened it, verbatim reference |
| `artefacts_touched` | Fold over `tool.*` events |
| `commands_run` | Fold, with exit codes |
| `outcome` | Derived from signals: tests passed/failed, build result, commit made, explicit human statement, abandonment |
| `outcome_confidence` | How strong the outcome signal is |
| `summary` | LLM-written, advisory only, never cited as evidence |

**The distinction that matters:** the structured fields are computed and citable; the summary is
generated and is not. A Claim may cite `episode.outcome` because it is derived from observed test
exit codes. It may not cite `episode.summary`, because that is an inference (P4, TR2).

## 36.3 Outcome classification

Deterministic rules, in priority order:

1. Explicit human statement (`aexo attest` or a captured confirmation) → that outcome, trust
   `human_stated`.
2. Test command exit 0 after a failing run in the same Episode → `resolved`, trust `machine_verified`.
3. Test command exit non-zero at Episode end → `failed`.
4. Commit made and no failing signal → `probably_resolved`.
5. Episode ended by idle with no terminal signal → `abandoned`.
6. Otherwise → `unknown`.

`unknown` is a legitimate, common outcome. Forcing a classification is how a memory system starts
learning from noise.

## 36.4 Cost discipline

Reflection is asynchronous and rate-limited. Per Episode: one summarisation call, batched where
possible. Configurable ceiling on reflection spend per day; when exceeded, Episodes are still
recorded structurally and queued for later summarisation. **Structural consolidation never depends
on model availability.**

## 36.5 Acceptance criteria

**AC-EPI-1.** Given an identical event log processed twice, when Episodes are derived, then the
boundaries and structured fields are identical, and only the summaries may differ.

**AC-EPI-2.** Given an Episode containing a failing test run followed by a passing run of the same
command, when the outcome is classified, then it is `resolved` with trust `machine_verified`.

**AC-EPI-3.** Given an Episode ending with no terminal signal after 25 minutes idle, when it is
classified, then the outcome is `abandoned` and no Claim cites it as evidence of success.

**AC-EPI-4.** Given a Claim candidate that cites `episode.summary` as evidence, when it is
submitted for admission, then it is rejected with a reason naming the prohibited source.

**AC-EPI-5.** Given the reflection budget is exhausted, when Episodes close, then they are recorded
with full structured fields, summaries are queued, and no error surfaces to the agent.

**AC-EPI-6.** Given no model provider is reachable, when an Episode closes, then consolidation
completes with structured fields and a null summary.
