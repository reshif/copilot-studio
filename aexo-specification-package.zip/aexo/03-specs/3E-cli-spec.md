# 3E — CLI (`aexo`)

Rust. Single static binary. The human's primary interface and the operator's only required tool.

## 3E.1 Commands

**Lifecycle**
| Command | Purpose |
|---|---|
| `aexo init` | Initialise `$AEXO_HOME`, detect harnesses, write hook config |
| `aexo start` / `stop` / `restart` | Daemon lifecycle |
| `aexo status` | One-screen state |
| `aexo doctor` | Full diagnostic (`2G`) |

**Knowledge**
| Command | Purpose |
|---|---|
| `aexo recall <query>` | What the agent would be told |
| `aexo why <id>` | Provenance for a claim, remedy, receipt or decision |
| `aexo claims [--band] [--scope] [--stale]` | List and filter |
| `aexo attest <id> --yes/--no --reason` | Human attestation |
| `aexo note "<observation>"` | Record evidence |
| `aexo decide "<decision>" --alternatives --because` | Record a decision |
| `aexo policy add/list/test/remove` | Policy management |
| `aexo resolve <contradiction-id>` | Resolve a conflict |

**Integrity and data**
| Command | Purpose |
|---|---|
| `aexo verify [--full] [--range]` | Chain verification |
| `aexo rebuild` | Rebuild derived state |
| `aexo export --format jsonl\|duckdb\|csv` | Export |
| `aexo import --from wolf\|projectmem\|otel` | Import (`3I`) |
| `aexo forget --subject <s> --reason <r>` | Crypto-shred |
| `aexo retention apply` | Enforce retention |

**Analysis**
| Command | Purpose |
|---|---|
| `aexo budget [--session]` | Token accounting, net not gross |
| `aexo completeness` | Observability completeness by harness and event kind |
| `aexo eval run/report` | Evaluation harness (`3H`) |
| `aexo query "<sql>"` | DuckDB over the export view |

## 3E.2 Output discipline

- Human-readable by default; `--json` on every command for scripting.
- Exit codes: 0 success, 1 operational failure, 2 invalid usage, 3 integrity failure.
- No colour when not a TTY. No spinners in non-interactive mode.
- **Every number that could be mistaken for a savings claim is printed with its cost alongside**
  (TR5). `aexo budget` reports avoided tokens, injected tokens, cache-mutation cost and the net.

## 3E.3 `aexo init` behaviour

1. Detect harnesses present (Claude Code settings, Codex config, others).
2. Show exactly what will be written, where, and what it will do.
3. Require confirmation unless `--yes`.
4. Write hook configuration idempotently; never clobber unrelated user settings.
5. Verify by firing a synthetic hook and confirming capture.
6. Print the verification result, including which harness events are and are not covered.

Honesty about coverage at install time prevents the false confidence that gap 1 of the OpenWolf
critique describes.

## 3E.4 Acceptance criteria

**AC-CLI-1.** Given a machine with Claude Code and Codex installed, when `aexo init` runs, then
both harnesses are configured, unrelated settings are preserved byte-identically, and coverage
limitations for Codex are printed explicitly.

**AC-CLI-2.** Given `aexo init` run twice, when the second run completes, then configuration is
unchanged and no duplicate hook entries exist.

**AC-CLI-3.** Given every command, when `--json` is passed, then output is valid JSON on stdout
with all human formatting on stderr.

**AC-CLI-4.** Given a broken chain, when `aexo verify` runs, then it exits 3 and names the exact
sequence of the break.

**AC-CLI-5.** Given `aexo budget`, when it prints, then avoided tokens, injected tokens,
cache-mutation cost and the net figure all appear, and the net is never omitted.

**AC-CLI-6.** Given `aexo forget --subject X`, when it runs without `--yes`, then it describes
exactly what will become unrecoverable and requires explicit confirmation.

**AC-CLI-7.** Given no daemon running, when any read command is issued, then it either serves from
derived state read-only or reports unavailability clearly, and never hangs.

**AC-CLI-8.** Given `aexo doctor` on a system with a stale index, a dropped-event count and one
unconfigured harness, when it runs, then all three are reported with specific remediation commands.
