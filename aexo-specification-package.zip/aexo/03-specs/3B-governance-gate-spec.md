# 3B — Governance Gate

Implements `29`. Deterministic, sub-10ms, advisory by default. The only component in the agent's
synchronous path besides capture.

## 3B.1 What the Gate checks

On `tool.pre`, in order, short-circuiting on first fire:

| # | Check | Data source | Cost |
|---|---|---|---|
| 1 | Duplicate read within Epoch | `knowledge_state` | O(1) hash lookup |
| 2 | Repeat of a previously-failed remedy | `remedy_signatures` | O(1) after signature computation |
| 3 | Policy violation in scope | compiled Policies | O(k), k = policies in scope |
| 4 | Action contradicts a `verified` Claim | `claims` + `claim_scope_idx` | O(log n) |
| 5 | Destructive action without a recorded rationale | rules | O(1) |

**No inference. No network. No model call.** The Gate is in the hot path; anything non-deterministic
there is both a latency risk and an injection surface (`2H` S9).

## 3B.2 Remedy signatures — the novel mechanism

The failure OpenWolf and every path-based system misses: an agent tries fix F on file A, it fails,
the session compacts, and the agent tries the same fix again — possibly on a different path, or
after the file moved, or with variables renamed.

A `remedy_signature` is content-keyed:

1. Parse the proposed edit with tree-sitter.
2. Normalise: alpha-rename identifiers, bucket literals (numeric magnitude class, string
   length class), strip comments and formatting.
3. Hash the normalised AST shape plus the normalised diff operation.

Two edits with the same signature are "the same fix" even if paths, names and formatting differ.
When a signature matches one recorded as having failed, the Gate warns with the prior outcome and
its evidence.

Budget: signature computation ≤2ms p95 for edits under 200 lines. Larger edits degrade to a
coarser signature and the precision is noted.

## 3B.3 Verdicts

| Verdict | Meaning | Default use |
|---|---|---|
| `allow` | Nothing fired | Always |
| `warn` | Something fired; message injected; action proceeds | **Default for all checks** |
| `block` | Action refused | Enterprise policy only, explicit opt-in |

**Default configuration never blocks** (TR6). The Gate's job is to make the agent smarter, not to
fight it. A blocked action that was actually correct costs more than a warning that was ignored.

Every verdict — including `allow` — is recorded. Recording allows is what makes the counterfactual
analysis possible: you need to know what the Gate saw and did not fire on.

## 3B.4 Warning format

```
⚠ this remedy signature failed before
  ep_01J8… · 2026-08-11 · tests still failed after the change
  differs only in identifier names from the prior attempt
  aexo_why(remedy="rs_7f3a…") for the full record
```

40–90 tokens. Names the evidence, gives the escape hatch, does not lecture.

## 3B.5 Degradation

If the Gate cannot answer within 15ms — daemon busy, derived state stale, structure unavailable —
it returns `allow` with `degraded: true`. The degradation is counted and surfaces in the
completeness metric.

A Gate that delays an agent is a Gate that gets disabled.

## 3B.6 Acceptance criteria

**AC-GATE-1.** Given a `tool.pre` for a file already read in this Epoch, when the Gate runs, then
it returns `warn` within 10ms at p99 and the message names when it was previously read.

**AC-GATE-2.** Given a subagent in a different Epoch reading a file the parent read, when the Gate
runs, then it returns `allow`, because knowledge state is per-Epoch.

**AC-GATE-3.** Given an edit that differs from a previously-failed edit only by identifier names
and whitespace, when the signature is computed, then it matches and the Gate warns naming the prior
failure.

**AC-GATE-4.** Given an edit that is semantically different but touches the same file, when the
signature is computed, then it does not match and the Gate does not warn on that basis.

**AC-GATE-5.** Given the Gate path under a 10,000-call trace, when it is inspected, then no
inference call, network call or credential access occurs.

**AC-GATE-6.** Given derived state is stale by more than the freshness threshold, when the Gate
runs, then it returns `allow` with `degraded: true` within 15ms and the degradation is counted.

**AC-GATE-7.** Given default configuration and any check firing, when the verdict is returned, then
it is `warn` and the harness receives exit 0.

**AC-GATE-8.** Given an enterprise policy enabling `block` for a specific rule, when that rule
fires, then the action is refused, the refusal is recorded with the rule ID, and all other rules
still only warn.

**AC-GATE-9.** Given 10,000 tool calls in a session, when Gate verdicts are queried, then every
call has a recorded verdict including `allow` results.

**AC-GATE-10.** Given an edit of 5,000 lines, when the signature is computed, then it completes
within budget using the coarser signature and the reduced precision is recorded.
