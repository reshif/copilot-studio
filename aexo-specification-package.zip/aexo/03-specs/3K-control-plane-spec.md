# 3K — Control Plane (Enterprise)

Ships in P5. Manages fleets of AEXO installations without becoming a single point of failure for
any developer's session.

## 3K.1 Principle

**The control plane can be entirely offline and every developer keeps working.** Local capture,
local gating, local projection all function without it. The control plane distributes policy,
aggregates metrics and provides organisational audit. It never sits in an agent's path.

## 3K.2 Responsibilities

| Function | Detail |
|---|---|
| Policy distribution | Signed policy bundles pulled by daemons on a schedule; local policies may add but not weaken org policies |
| Fleet health | Aggregated completeness, drop rates, degradation, version skew |
| Aggregate metrics | Org-level ESK, net token accounting, repeat-failure prevention |
| Audit aggregation | Attestations, policy changes, forgets, chain anchors from every node |
| Key management | KMS/HSM integration, BYOK, rotation orchestration |
| Identity | OIDC + SCIM; role and human-identity assertion |
| Retention governance | Org retention schedules pushed to nodes |
| Tenant management | Isolation boundaries, per-tenant keys |

## 3K.3 What it never does

- It never receives raw event payloads by default. Aggregation is over metrics and metadata.
  Payload forwarding is opt-in, per-project, and visible to the developer.
- It never issues an instruction that reaches an agent's context directly. Org policy reaches an
  agent only by being compiled locally and firing through the local Gate.
- It never becomes a synchronous dependency of anything on the hot path.

This posture is what makes AEXO deployable in organisations that cannot ship source-derived content
off the machine.

## 3K.4 Policy precedence

```
org policy (signed)  >  project policy  >  local policy
```

A local policy may add restrictions or add warnings. It may not disable an org policy. Attempts to
do so fail at compile time and are reported to the fleet health view.

## 3K.5 Acceptance criteria

**AC-CTL-1.** Given the control plane is unreachable for 7 days, when developers work normally,
then capture, gating and projection function fully, and the staleness of org policy is reported
locally.

**AC-CTL-2.** Given a signed org policy bundle with an invalid signature, when a daemon pulls it,
then it is rejected, the previous bundle remains active, and the rejection is reported.

**AC-CTL-3.** Given a local policy that attempts to disable an org policy, when it is compiled,
then compilation fails and the attempt appears in fleet health.

**AC-CTL-4.** Given default configuration, when control-plane traffic is inspected, then no event
payload content is transmitted.

**AC-CTL-5.** Given payload forwarding enabled for a project, when it is enabled, then the local
`aexo status` and the health notice both state that payloads are being forwarded and to where.

**AC-CTL-6.** Given key rotation is initiated org-wide, when it completes, then all nodes re-wrap
content keys, no payload becomes unreadable, and the rotation is recorded as events on every node.

**AC-CTL-7.** Given a node that has not reported for 30 days, when fleet health renders, then it is
shown as stale with its last-seen time rather than being silently dropped.
