# 34 — Derived State Builder

A deterministic fold of the event log into queryable state. Nothing here is authoritative; all of
it is reconstructible.

## 34.1 The fold contract

```
state(0)   = ∅
state(n)   = apply(state(n−1), event(n))
```

`apply` MUST be:
- **Deterministic** — same log, same state, byte for byte, on any machine.
- **Total** — every event kind has a handler; unknown kinds are recorded as no-ops with a counter,
  never an error. Forward compatibility matters because an older daemon may read a newer log.
- **Pure** — no clock reads, no random, no network, no filesystem outside the derived store.
- **Idempotent by sequence** — replaying an already-applied sequence is a no-op.

Non-determinism in the fold is a P0 bug, because it breaks the equivalence between rebuild and
incremental state, which is the property every audit claim rests on.

## 34.2 Tables

Full DDL in `06-appendix/schemas/derived-schema.sql`. Summary:

| Table | Grain | Purpose |
|---|---|---|
| `events_idx` | event | id → seq, kind, context, timestamps |
| `knowledge_state` | (epoch, artefact) | What this Epoch has already seen — the Gate's basis |
| `artefacts` | path@commit | Content hash, size, last touched |
| `episodes` | episode | Boundaries, outcome, participating actors |
| `evidence` | evidence | Observation records with source and trust |
| `claims` | claim | Statement, scope, band, validity interval |
| `claim_support` | (claim, evidence) | SUPPORTS / CONTRADICTS edges with weights |
| `claim_scope_idx` | (scope key, claim) | Candidate generation for contradiction (`2I.7`) |
| `decisions` | decision | What was chosen, alternatives, rationale ref |
| `policies` | policy | Compiled human-authored rules |
| `verifications` | (claim, run) | Result, timestamp, verifier version |
| `contradictions` | pair | Status, resolution, resolver |
| `remedy_signatures` | signature | Content-keyed failed-fix fingerprints (`29`) |
| `structure_*` | symbol/ref | Code intelligence (`35`) |
| `receipts` | receipt | What was injected, when, why, at what cost |
| `metrics_rollup` | (window, metric) | Pre-aggregated observability |
| `health` | event | Degradations, drops, quarantines |

## 34.3 Rebuild

| Mode | Trigger | Behaviour |
|---|---|---|
| Incremental | Normal operation | Fold the tail |
| From checkpoint | Restart | Load the last checkpoint, fold the tail |
| Full | Schema change, corruption, `aexo rebuild` | Genesis to head |

Checkpoints are written every 250,000 events as a consistent snapshot of the derived store plus the
sequence it covers. They bound restart time; they are never required for correctness.

**Weekly CI runs a full genesis rebuild on the reference corpora and asserts byte-identity with the
incrementally maintained state.** Without that test, fold determinism rots silently.

## 34.4 Read consistency

Readers see a monotonically advancing snapshot. The Projection Engine records the sequence its
bundle was built from, and that sequence appears on the receipt (`26`). This is what allows the
question "what did the system know when it said that?" to be answered exactly.

Staleness is bounded: the fold lags the durable tail by ≤50ms p95. If it exceeds 1s, a health event
fires and bundles carry a staleness marker.

## 34.5 Acceptance criteria

**AC-DER-1.** Given a 1M-event log, when derived state is built on three different machines and
operating systems, then the resulting stores are byte-identical after normalisation of file
ordering.

**AC-DER-2.** Given an incrementally maintained store and a full rebuild from genesis of the same
log, when compared, then they are identical.

**AC-DER-3.** Given an event kind unknown to this daemon version, when it is folded, then it is
counted as unhandled, the fold continues, and the chain and sequence are unaffected.

**AC-DER-4.** Given the fold is deliberately delayed by 2 seconds, when a bundle is generated, then
the bundle carries a staleness marker and a health event has been emitted.

**AC-DER-5.** Given any bundle receipt, when the recorded sequence is used to rebuild state to that
point, then the bundle is reproducible exactly.

**AC-DER-6.** Given a fold handler that reads the system clock, when the determinism test suite
runs, then the test fails and names the offending handler.
