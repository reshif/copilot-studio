# 3J — Policy Compiler

Compiles the Policy DSL into a form the Gate can evaluate in microseconds without inference.

## 3J.1 Language properties

Restating the security-critical guarantees from `2H` S4, because they are language properties, not
runtime checks:

- **Total.** No loops, no recursion, no unbounded constructs. Termination is a type-system
  property, not a timeout.
- **Pure.** The evaluator is constructed without filesystem, network or process capabilities. A
  Policy cannot exfiltrate because there is nothing to exfiltrate through.
- **Typed.** Scopes, actions, artefacts, symbols and bands are distinct types. A Policy that
  compares a band to a path fails to compile.
- **Human-authored only.** Enforced at authorisation, not convention.

## 3J.2 Shape

```
policy "no-secrets-in-source" {
  when   action is write
         and target matches "src/**"
         and content contains_pattern secret_like
  then   warn "writing secret-shaped content into source"
         cite  "SEC-014"
  except target matches "src/**/fixtures/**"
}
```

Constructs: `when` (predicate over the action and its context), `then` (verdict + message +
optional citation), `except` (narrowing), `test` (required examples).

Predicates available: action kind, target path/glob, target symbol, language, content pattern,
claim band in scope, mission, actor kind, time window, prior-failure signature match.

**No predicate can call out.** There is no `exec`, no `http`, no `read_file`.

## 3J.3 Required tests

Every Policy MUST carry at least one positive and one negative example:

```
test "fires on secret in src" {
  action write "src/config.py" content "AKIA..." → warn
}
test "does not fire in fixtures" {
  action write "src/tests/fixtures/keys.py" content "AKIA..." → allow
}
```

A Policy whose tests fail cannot be activated. Policies are the only imperative surface in the
system; an untested imperative is a bug with authority.

## 3J.4 Compilation output

A decision table plus a compiled predicate tree, indexed by scope so the Gate evaluates only
policies whose scope could match. Compilation is deterministic and the output is content-hashed;
the hash is recorded on every verdict so a warning can be traced to the exact compiled policy
version that produced it.

## 3J.5 Acceptance criteria

**AC-POL-1.** Given a Policy containing any I/O construct, when it is compiled, then compilation
fails naming the prohibited construct, and the Policy is not stored as active.

**AC-POL-2.** Given a Policy without both a positive and a negative test, when activation is
attempted, then it is refused.

**AC-POL-3.** Given a Policy whose tests fail, when activation is attempted, then it is refused and
the failing test is named.

**AC-POL-4.** Given adversarial input designed to maximise evaluation cost, when a compiled Policy
evaluates it, then evaluation completes within the Gate's budget, because the language admits no
unbounded construct.

**AC-POL-5.** Given 500 active Policies, when the Gate evaluates one action, then only
scope-matching Policies are evaluated and total Gate latency stays within its p99 budget.

**AC-POL-6.** Given a Gate warning produced by a Policy, when its provenance is queried, then the
compiled policy version hash, the source text and the author are returned.

**AC-POL-7.** Given a Policy is deactivated, when the Gate next evaluates, then it no longer fires,
and the deactivation is recorded as an event with actor and reason.
