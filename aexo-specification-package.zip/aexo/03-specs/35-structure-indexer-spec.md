# 35 — Structure Indexer

Implements the code intelligence plane (`27`). Answers structural questions cheaply so the agent
does not have to buy the answer with reads.

## 35.1 Precision tiers

Every structural answer carries a precision label. This is non-negotiable: an unlabelled structural
answer invites the agent to trust a guess.

| Tier | Source | Guarantee | Availability |
|---|---|---|---|
| `syntactic` | tree-sitter | Shape is correct; resolution is heuristic | Always |
| `indexed` | SCIP / LSIF | Resolution correct as of index time | If an indexer is configured |
| `live` | LSP | Resolution correct now | If a language server is running |
| `deep` | CodeQL / semantic | Dataflow-level | Enterprise, opt-in, batch |

Degradation is automatic and always downward with the label updated. **Never upward.** A
`syntactic` answer is never presented as `indexed`.

## 35.2 Mandatory tier

tree-sitter is compiled in. No external process, no network, no user setup. Grammars shipped for
the P0 language set: Python, TypeScript, JavaScript, Rust, Go, Java, C#, C, C++, Ruby, PHP, Kotlin,
Swift, SQL, Bash, YAML, TOML, JSON, Markdown, HCL, Dockerfile.

This matters for adoption: a memory tool that requires the user to stand up an indexer before it
does anything useful does not get adopted.

## 35.3 Incremental behaviour

1. Watcher reports a path change (debounced 300ms).
2. Compute content hash. If unchanged, stop.
3. Re-parse that file only. tree-sitter's incremental parse reuses the prior tree where possible.
4. Diff the symbol set. Emit `structure.symbol.*` events only for actual changes.
5. Invalidate the affected slices of `structure_refs`.

Budget: 50ms p95 for one file on REF-BIG (`2I`).

**Full reindex is only triggered by:** first run, grammar version change, or explicit request. A
branch switch triggers a batch incremental pass over the changed file set, not a full reindex.

## 35.4 Queries offered

| Query | Answer | Typical token saving vs. reading |
|---|---|---|
| `where_defined(symbol)` | Path, line, signature | 1 file read |
| `references(symbol)` | Sites with one-line context | 3–20 file reads |
| `outline(path)` | Symbol tree with signatures | 1 large file read |
| `signature(symbol)` | Signature + docstring | 1 file read |
| `neighbourhood(path)` | Imports in/out, sibling tests | 2–8 reads |
| `changed_since(ref)` | Symbol-level diff | variable, often large |
| `test_for(symbol)` | Likely covering tests | 2–5 reads |
| `impact(symbol)` | Transitive dependents, depth-capped | can be very large |

Every answer includes the precision label and the commit it was computed at.

**The saving claim is only made when the query is answered without a read that the agent would
otherwise have performed** — measured by the counterfactual harness (`44`), not asserted.

## 35.5 Storage

Structure lives in derived state, keyed by `(commit, path)`. Retention: the last N commits
(default 50) plus every commit referenced by a live Claim's provenance. This bounds growth while
keeping historical Claims interpretable — a Claim that says "this function validates input" is
meaningless if we can no longer say which version of the function it meant.

## 35.6 Acceptance criteria

**AC-SIDX-1.** Given a repository with no indexer configured, when a structural query is made, then
an answer is returned with precision `syntactic` and no external process is spawned.

**AC-SIDX-2.** Given a configured SCIP index and a live language server, when the same query is
made, then the answer with the highest available precision is returned and labelled accordingly.

**AC-SIDX-3.** Given a language server that stops responding, when a `live` query is attempted,
then it degrades to `indexed` or `syntactic` within the query's ceiling and the returned label
matches what was actually used.

**AC-SIDX-4.** Given a 500,000-file repository, when one file is edited, then reindexing completes
within 50ms at p95 and only that file's symbols are re-emitted.

**AC-SIDX-5.** Given a file edited such that no symbol changes (whitespace only), when reindexing
runs, then zero `structure.symbol.*` events are emitted.

**AC-SIDX-6.** Given a Claim whose provenance references commit X, when retention prunes structure
data, then commit X's structure for the referenced paths is retained.

**AC-SIDX-7.** Given a file in a language with no shipped grammar, when it changes, then it is
recorded as an opaque artefact with content hash only, and no structural claims are made about it.

**AC-SIDX-8.** Given a branch switch touching 4,000 files, when the watcher fires, then a batch
incremental pass runs and completes within 15 seconds on REF-BIG without a full reindex.
