# 38 — Verifier Runner

Turns Claims from assertions into things that can be falsified. This is what makes expiry
principled rather than calendar-based.

## 38.1 Verifier types

| Type | Example | Cost |
|---|---|---|
| `command` | `pytest tests/test_auth.py -q` | Variable |
| `structural` | "symbol `validate_token` exists in `src/auth/`" | Microseconds |
| `pattern` | "no call to `eval(` in `src/`" | Milliseconds |
| `artefact` | "`Dockerfile` still declares base image X" | Microseconds |
| `human` | Prompt a human to re-attest after N days | Human time |

Structural, pattern and artefact verifiers are answered from derived state at near-zero cost.
Prefer them; a Claim that can be checked structurally should not carry a command verifier.

## 38.2 Scheduling

Verification interval by band:

| Band | Default interval | On relevant change |
|---|---|---|
| `attested` | 180 days | re-verify |
| `verified` | 14 days | re-verify immediately |
| `supported` | 30 days | re-verify |
| `observed` | on retrieval only | — |

"Relevant change" means the watcher reports a change inside the Claim's scope. This is the key
efficiency: verification is event-driven, not periodic sweeping. A Claim about a file nobody has
touched in six months costs nothing to keep.

Global rate limit on command verifiers (default: 4 concurrent, ≤5% of CPU time budgeted), so
verification never competes with the developer's own builds.

## 38.3 Execution sandbox

Per `2H`: no network by default, read-only repository mount plus writable temp, CPU/memory limits,
wall-clock timeout (default 120s), no access to AEXO keys or config, no inherited environment
except an explicit allow-list.

A verifier requiring network must declare it, and the declaration is visible on the Claim and in
any bundle citing it.

## 38.4 Result handling

| Result | Effect |
|---|---|
| `pass` | Band held or raised to `verified`; `last_verified` updated |
| `fail` | Band drops to `observed`; a `claim.verification.failed` event; contradiction check enqueued; Claim flagged for review |
| `error` | Band unchanged; failure recorded; retried with backoff; after 3 consecutive errors the verifier is marked broken and the Claim's band decays as if unverified |
| `timeout` | Treated as `error` |

**A failing verifier does not delete the Claim.** It demotes it and surfaces it. Deletion on
failure would let a transient environment problem silently erase institutional knowledge.

## 38.5 Decay

A Claim past its verification interval without a successful run decays one band per interval,
floor `observed`. Decay is computed at read time from `last_verified` — not written by a sweep — so
it is correct even if the daemon was offline.

This is the mechanism the OpenWolf critique's gap 15 asks for, made principled: knowledge does not
expire because it is old, it expires because nothing has confirmed it recently.

## 38.6 Acceptance criteria

**AC-VER-1.** Given a Claim with a passing command verifier, when verification runs, then the band
becomes `verified`, `last_verified` is set, and an event records the verifier version and exit
code.

**AC-VER-2.** Given a Claim at `verified` whose verifier now fails, when verification runs, then
the band drops to `observed`, the Claim is flagged, and it is not deleted.

**AC-VER-3.** Given a verifier that attempts an undeclared network connection, when it runs, then
the connection fails, the result is `error`, and the Claim's band is unchanged.

**AC-VER-4.** Given a verifier that never terminates, when the timeout elapses, then the process
tree is killed, the result is `timeout`, and daemon resources return to baseline.

**AC-VER-5.** Given a Claim scoped to `src/billing/` and an edit inside that scope, when the
watcher fires, then verification is scheduled within one scheduler tick rather than waiting for the
periodic interval.

**AC-VER-6.** Given a `verified` Claim not re-verified for 45 days with a 14-day interval, when it
is read, then its effective band is `observed` by decay, computed at read time.

**AC-VER-7.** Given the daemon was offline for 60 days, when it restarts and Claims are read, then
decay is correct without any catch-up sweep having run.

**AC-VER-8.** Given 200 Claims due for command verification, when they are scheduled, then no more
than the configured concurrency run at once and total CPU stays within the configured share.

**AC-VER-9.** Given a Claim verifiable structurally, when a command verifier is proposed for it,
then a warning is recorded recommending the cheaper verifier, and both are permitted.
