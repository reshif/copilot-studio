# 3H — Evaluation Harness (`aexo-eval`)

The component that makes AEXO's central claim falsifiable. Gap 9 and gap 17 of the OpenWolf
critique — "token savings ≠ task improvement" and "effectiveness unproven" — are answered here or
not at all.

The prior-art gap is explicit: the closest published system states that the most valuable next
result is a measured one — the fraction of injected, previously-failed fixes that a gate actually
blocks — and that this benchmark does not yet exist in the developer-tool memory category. AEXO
builds it and publishes the harness, not merely the score.

## 3H.1 Designs supported

| Design | Use | Strength |
|---|---|---|
| **Shadow** | AEXO captures and computes verdicts but injects nothing | Establishes baseline behaviour and would-have-fired rates with zero risk |
| **Paired A/B** | Same task, same seed, same model, with and without projection | Direct causal comparison |
| **Counterfactual replay** | Replay a recorded session; compute what AEXO would have injected and what the agent would have avoided | Cheap, no model spend, but assumes agent behaviour is unchanged — an assumption reported, never hidden |
| **Seeded-defect** | ~30 repositories with deliberately injected previously-failed fixes | Measures repeat-failure prevention directly |
| **Longitudinal** | Real teams, opt-in telemetry, over months | External validity |

## 3H.2 Primary metrics

| Metric | Definition |
|---|---|
| **ESK** | Evidence Sufficiency per Kilotoken — the north star (`02`) |
| **Repeat-failure prevention rate** | Of injected previously-failed remedies, the fraction where the agent did not repeat the failure |
| **Task success delta** | Paired success-rate difference with confidence intervals |
| **Net token delta** | Avoided − injected − cache cost, per session |
| **Turns-to-resolution delta** | Paired |
| **Rediscovery rate** | Reads of content already known to this Epoch |
| **Injection precision** | Fraction of injected items the agent used or did not dispute |
| **Dispute rate** | Receipts disputed per 100 injections |

**ESK is reported with its denominator.** A system can improve ESK by injecting less and getting
lucky; the paired design is what distinguishes that from real improvement.

## 3H.3 The seeded corpus

~30 repositories spanning languages, sizes and domains. For each:

1. Identify a historical failed-fix-then-successful-fix pair from real commit history where
   possible; synthesise where not, and label which is which.
2. Construct a task whose naive approach reproduces the failed fix.
3. Record the failed attempt in AEXO under a prior Epoch.
4. Run the task with and without projection, paired, N seeds each.
5. Measure whether the failed remedy was repeated.

The corpus, the task definitions, and the harness are published. **A score without a reproducible
harness is a marketing claim** — and the category is full of them.

## 3H.4 Statistical discipline

- Pre-registered primary metric and analysis plan per experiment.
- Paired designs; report effect sizes with confidence intervals, not p-values alone.
- Report N, seeds, model version, model temperature, harness version and AEXO version on every
  result.
- Report negative results with the same prominence. Configurations where AEXO is net-negative are
  published as findings, because knowing when the system does not help is a product requirement.
- Model version drift is a confounder: a re-run against a newer model is a new experiment, not an
  update.

## 3H.5 Acceptance criteria

**AC-EVAL-1.** Given the seeded corpus and a full paired run, when results are produced, then every
result carries N, seeds, model version, harness version and AEXO version.

**AC-EVAL-2.** Given a paired A/B run, when the report is generated, then effect sizes and
confidence intervals are present, and no bare gross-savings figure appears anywhere in the report.

**AC-EVAL-3.** Given shadow mode enabled, when a session runs, then zero tokens are injected, all
would-have-fired verdicts are recorded, and the agent's context is byte-identical to a run with
AEXO absent.

**AC-EVAL-4.** Given a counterfactual replay, when its results are reported, then the behavioural-
invariance assumption is stated explicitly in the report body.

**AC-EVAL-5.** Given an experiment configuration, when it is executed twice with the same seeds and
model version, then the recorded AEXO-side decisions are identical.

**AC-EVAL-6.** Given a configuration where net token delta is negative, when the report is
generated, then the negative result is included with the same prominence as positive results.

**AC-EVAL-7.** Given the published harness and corpus, when a third party runs it on their own
infrastructure, then they can reproduce the reported metric definitions and compute their own
figures without access to AEXO's internal data.
