# 32 — Daemon (`aexo-daemon`)

One process per machine. Owns all writes. Holds the derived state. Answers the Gate and the
Projection Engine within budget.

## 32.1 Internal structure

```
                ┌──────────── aexo-daemon ────────────┐
 hook socket ──▶│ Acceptor  ─▶ MPSC queue ─▶ Writer   │──▶ segment files
 OTLP :4317  ──▶│                            │        │
 local API   ──▶│ Router ─┬─ Gate            │        │
                │         ├─ Projection      ▼        │
                │         ├─ Structure   Fold engine  │──▶ SQLite (derived)
                │         └─ Admission        │       │
                │  Watcher (fs events) ───────┘       │
                │  Scheduler (jobs, verifications)    │
                └─────────────────────────────────────┘
```

**Threads.** A small fixed pool, not a thread per connection:
- 1 acceptor thread per listener
- 1 writer thread (the only thread that touches segment files)
- N worker threads for reads, gating and projection (default `min(4, cores)`)
- 1 watcher thread
- 1 scheduler thread

**The single-writer rule is absolute.** It is what makes the hash chain correct without locking
protocols, and what makes the sequence number a total order rather than a convention.

## 32.2 The append path

1. **Accept** — deframe, validate envelope shape. Reject malformed with a health event; never
   crash on input.
2. **Redact** — apply the scrubber (`22.4`). Record redaction counts on the envelope.
3. **Identify** — assign event ID (ULID), sequence number, ingest timestamp.
4. **Canonicalise** — RFC 8785 JCS over the envelope.
5. **Chain** — `hash(n) = BLAKE3(JCS(envelope) || hash(n−1))`.
6. **Enqueue payload** — payloads over the inline threshold (default 4KB) go to the content-
   addressed blob store; the envelope references the content hash.
7. **Append** — write the framed envelope to the current segment.
8. **Group commit** — fsync at most every 5ms or every 256 events, whichever comes first.
9. **Fold** — apply the event to derived state (`34`).
10. **Notify** — wake any subscribers (dashboard streams, watchers).

Steps 1–7 are on the writer thread and are budgeted at 150µs p95. Step 8 is amortised. Step 9
happens on a fold thread reading the durable tail, so a slow fold never delays a write.

## 32.3 Backpressure

The MPSC queue has a bounded capacity (default 100,000 events).

| Queue depth | Behaviour |
|---|---|
| <50% | Normal |
| 50–80% | Emit a health event; begin sampling low-value event kinds (e.g. `harness.notification`) |
| 80–95% | Drop low-value kinds entirely; record exact counts by kind |
| >95% | Drop everything except `tool.pre`, `tool.post`, `session.*`, `claim.*`, `policy.*` |
| full | Hook spools instead; daemon logs a saturation event |

**Every drop is counted by kind and surfaces in the completeness metric.** Sampling is never
silent (gap 2 of the OpenWolf critique).

## 32.4 Lifecycle

- **Start-up:** acquire the exclusive lock on `$AEXO_HOME/`; verify the chain from the last anchor;
  drain spool; open or rebuild derived state; start listeners.
- **Chain verification on start-up is bounded** — from the last anchor only, target <500ms. Full
  verification is `aexo verify --full`.
- **Derived state versioning:** the derived schema carries a version. On mismatch, the daemon
  rebuilds rather than migrating, because rebuild is always available from the log and migration
  code is a permanent liability.
- **Shutdown:** stop accepting, drain the queue, fsync, seal the current segment if configured,
  release the lock. SIGTERM budget: 2s.
- **Crash:** the log is append-only with length-prefixed framing; a partial trailing frame is
  truncated on next start-up and the event is recovered from spool if present.

## 32.5 The lock

An OS-level exclusive lock file. If a second daemon starts, it fails fast with the PID of the
holder. If the lock is stale (holder PID gone), it is broken automatically after verifying no open
file handle remains on the current segment.

## 32.6 Scheduler

Owns all periodic work:

| Job | Cadence | Notes |
|---|---|---|
| Spool drain | 10s, and on start | |
| Group commit flush | 5ms | |
| Anchor write | 10,000 events or 1h | |
| Segment seal + compress | 128MB or 24h | zstd level 3 |
| Verification sweep | per Claim's verification interval | Rate-limited globally |
| Contradiction sweep | on Claim change, plus nightly full | |
| Episode boundary detection | on `session.end`, idle >20min, or 200 events | Enqueues reflection |
| Structure reindex | on watcher event, debounced 300ms | |
| Retention enforcement | daily | |
| Checkpoint derived state | every 250,000 events | Bounds rebuild time |

Jobs are enqueued, never run inline. The scheduler thread does no work itself.

## 32.7 Resource discipline

- The watcher is event-driven (`inotify` / `FSEvents` / `ReadDirectoryChangesW`). **Polling is
  prohibited.**
- Idle CPU ≤1% (`2I`). A daemon that shows up in `top` gets killed by its user, and a killed
  daemon captures nothing.
- Memory ceilings enforced by bounded caches with explicit eviction, not by hoping.
- On sustained memory pressure the daemon sheds caches before it sheds correctness, and reports it.

## 32.8 Acceptance criteria

**AC-DMN-1.** Given a running daemon, when a second daemon is started against the same
`$AEXO_HOME`, then it exits non-zero within 200ms naming the holding PID, and the first daemon is
unaffected.

**AC-DMN-2.** Given a daemon killed with SIGKILL mid-write, when it restarts, then the partial
trailing frame is truncated, `aexo verify` reports INTACT, and no committed event is lost.

**AC-DMN-3.** Given the event queue at 85% depth, when low-value events arrive, then they are
dropped, counts are recorded by kind, and the completeness metric reflects the loss within one
minute.

**AC-DMN-4.** Given 250,000 events since the last checkpoint, when a checkpoint is written and the
daemon is then restarted, then derived state is reconstructed from the checkpoint plus the tail and
is byte-identical to a full rebuild from genesis.

**AC-DMN-5.** Given a derived schema version mismatch on start-up, when the daemon starts, then it
rebuilds derived state from the log, reports progress, and serves reads only after the rebuild
completes or from a read-only snapshot of the prior state if configured.

**AC-DMN-6.** Given the daemon idle for one hour on REF-BIG, when CPU is sampled, then average
utilisation is ≤1% and no polling syscall pattern is observable.

**AC-DMN-7.** Given SIGTERM, when the daemon shuts down, then the queue is drained, all accepted
events are durable, the lock is released, and the process exits within 2s.

**AC-DMN-8.** Given a malformed frame on the hook socket, when it is received, then the daemon
emits a health event, closes that connection only, and continues serving all others.
