# 30 — Component Map

Every component in the system, its process boundary, language, and the specification that governs
it. Components marked **core** ship in P0–P3; **proof** ships in P4; **enterprise** ships in P5.

| ID | Component | Binary / process | Lang | Tier | Spec |
|---|---|---|---|---|---|
| C-01 | Capture runtime (`aexo-hook`) | short-lived per invocation | Rust | core | `31` |
| C-02 | Daemon (`aexo-daemon`) | long-lived, per machine | Rust | core | `32` |
| C-03 | Event store | in-daemon library | Rust | core | `33` |
| C-04 | Derived state builder | in-daemon library | Rust | core | `34` |
| C-05 | Structure indexer | in-daemon library + optional sidecars | Rust | core | `35` |
| C-06 | Episode consolidator | worker task | Python | core | `36` |
| C-07 | Claim engine | worker task | Python | core | `37` |
| C-08 | Verifier runner | worker task + sandbox | Rust + Python | core | `38` |
| C-09 | Contradiction engine | worker task | Python | core | `39` |
| C-10 | Projection engine | in-daemon library | Rust | core | `3A` |
| C-11 | Governance Gate | in-daemon library | Rust | core | `3B` |
| C-12 | MCP server (`aexo-mcp`) | long-lived or stdio | Rust | core | `3C` |
| C-13 | REST/gRPC server (`aexo-server`) | long-lived | Python/FastAPI | core | `3D` |
| C-14 | CLI (`aexo`) | short-lived | Rust | core | `3E` |
| C-15 | Reflection worker (`aexo-worker`) | long-lived | Python | core | `3F` |
| C-16 | Dashboard | static SPA + REST | TypeScript | proof | `3G` |
| C-17 | Evaluation harness (`aexo-eval`) | batch | Python | proof | `3H` |
| C-18 | Importers | CLI subcommands | Rust + Python | core | `3I` |
| C-19 | Policy compiler | in-daemon library | Rust | core | `3J` |
| C-20 | Control plane | service | Python/FastAPI | enterprise | `3K` |

## 30.1 Process boundaries and why they fall where they do

**Rust on the hot path, Python on the thinking path.** Anything invoked per tool call, per
keystroke or per gate decision is Rust: cold start dominates and the budgets in `2I` are
unreachable otherwise. Anything invoked per episode, per hour or per human request is Python:
iteration speed and library ecosystem dominate, and a 200ms start-up is irrelevant.

**The daemon owns all writes.** Exactly one process appends to the log per machine. This is what
makes the hash chain trivially correct without distributed consensus (`2C`). The Python workers
never write to the log directly; they submit candidate records over the local API and the daemon
appends them.

**The MCP server is thin.** It translates MCP calls into daemon calls and back. It holds no state.
This means a crash loses nothing and a restart is instant, which matters because harnesses restart
MCP servers frequently.

**The REST server is optional for local use.** A solo developer runs `aexo-daemon` and
`aexo-mcp` only. `aexo-server` appears when a dashboard, a team, or an integration needs it.

## 30.2 Interaction sequences

**Tool call, gated:**
```
harness → aexo-hook (PreToolUse)
          → unix socket → aexo-daemon
                          → Gate (C-11) → verdict
                          → Event store (C-03) append
          ← verdict
        ← exit 0 + hookSpecificOutput
```
Budget: 10ms p99 end to end.

**Tool result, capture only:**
```
harness → aexo-hook (PostToolUse) → socket → daemon → append → exit 0
```
The hook does not wait for durability. Budget: 8ms p99.

**Recall:**
```
agent → MCP tool call → aexo-mcp → daemon
                                   → Projection (C-10)
                                     → derived state (C-04)
                                     → structure (C-05)
                                   → bundle + receipt
```
Budget: 400ms p99.

**Reflection:**
```
daemon (episode boundary detected) → job queue
  → aexo-worker → Episode consolidator (C-06)
                → Claim engine (C-07) → candidates
                → daemon: submit candidates → admission → append
                → Contradiction engine (C-09) on affected scopes
                → Verifier runner (C-08) schedules verifications
```
No latency budget; this is asynchronous and never blocks an agent.

## 30.3 Failure isolation

| Component down | Consequence | Agent impact |
|---|---|---|
| C-01 hook | No capture for that call | None; harness proceeds |
| C-02 daemon | No capture, no gate, no recall | None; hooks queue to disk and exit 0 |
| C-08 verifier runner | Claims stop being re-verified; bands decay | Confidence drops over time — correct behaviour |
| C-12 MCP server | Recall unavailable | Agent works without memory |
| C-13 REST server | Dashboard and integrations down | None |
| C-15 worker | No new Claims form | Existing memory still projects |

**No component's failure blocks an agent.** This is TR6, enforced structurally: the only
synchronous dependency in the agent's path is the hook, and the hook's failure mode is `exit 0`.

## 30.4 Acceptance criteria

**AC-CMP-1.** Given every component stopped except the harness, when an agent runs a full task,
then the task completes with no error surfaced by the harness.

**AC-CMP-2.** Given the daemon is killed mid-session, when hooks continue firing, then every hook
exits 0 within its ceiling, events are queued to the spool directory, and on daemon restart the
spool is drained in order with no loss and no duplication.

**AC-CMP-3.** Given the process table during a normal session, when writers to the event log are
enumerated, then exactly one process has the log open for writing.

**AC-CMP-4.** Given a Python worker attempts to write to the log file directly, when it does so,
then the write is refused by an advisory lock and the attempt is recorded as a health event.
