# 31 — Capture Runtime (`aexo-hook`)

The most latency-sensitive component in the system and the one most likely to get AEXO uninstalled
if it is wrong.

## 31.1 Responsibilities

1. Read the harness's hook payload from stdin.
2. Normalise it into a Canonical Activity Event (`22`).
3. Deliver it to the daemon over the local transport.
4. For gating events, receive a verdict and translate it into the harness's control protocol.
5. Never fail in a way the agent notices.

It does **not** parse deeply, does not touch the repository, does not compute hashes over large
payloads, and does not talk to the network.

## 31.2 Invocation model

Invoked once per hook event by the harness, as a subprocess with a JSON payload on stdin.

**Start-up is the whole game.** Measured targets for the shipped binary:

| Platform | Cold (first invocation) | Warm (page cache hot) |
|---|---|---|
| Linux x86-64 | ≤6ms | ≤1.2ms |
| macOS arm64 | ≤9ms | ≤1.5ms |
| Windows x86-64 | ≤12ms | ≤2.5ms |

Achieved by: static linking where possible, no dynamic plugin loading, lazy config parsing,
zero-copy stdin read, and a deliberately tiny dependency set (`2E` dependency budget).

**Rejected alternative:** a persistent hook agent with a shim script. It removes start-up cost but
introduces a lifecycle to manage, a version-skew surface, and a second thing that can be in a bad
state. The binary is fast enough that the complexity is not warranted.

## 31.3 Transport

| Platform | Primary | Fallback |
|---|---|---|
| Linux/macOS | Unix domain socket at `$AEXO_HOME/run/daemon.sock` | Spool file |
| Windows | Named pipe `\\.\pipe\aexo-<hash>` | Spool file |

Framing: length-prefixed MessagePack. Chosen over JSON for encode cost and over Protobuf to avoid
a code-generation step in the hot path build.

**Connect timeout: 5ms. Read timeout: 15ms for gating events, 0 for capture-only events
(fire-and-forget with a best-effort flush).**

## 31.4 Spool fallback

If the daemon is unreachable:

1. Append the framed event to `$AEXO_HOME/spool/<pid>-<monotonic>.msgpack` using `O_APPEND`.
2. Exit 0.
3. For a gating event, return `allow` with `degraded: true`.

The daemon drains spool files on start-up and on a timer, ordering by the embedded monotonic
timestamp and deduplicating by event ID. A spool entry older than the configured retention
(default 7 days) is dropped with a health event, because stale capture is worse than no capture.

**Spool size cap: 256MB.** Beyond it, the hook drops events and increments a dropped counter that
surfaces in `aexo doctor` and in the injected health notice. Silence about data loss is the
failure mode the OpenWolf critique names in gap 2; AEXO makes loss loud.

## 31.5 Harness translation

### Claude Code

| Hook event | AEXO event kind | Gating |
|---|---|---|
| `SessionStart` | `session.start` | yes — returns `additionalContext` |
| `UserPromptSubmit` | `prompt.submit` | yes |
| `PreToolUse` | `tool.pre` | yes |
| `PostToolUse` | `tool.post` | no |
| `PreCompact` | `context.compact.pre` | no |
| `SessionEnd` | `session.end` | no |
| `SubagentStart` / `SubagentStop` | `agent.spawn` / `agent.exit` | no |
| `Notification` | `harness.notification` | no |
| *(remaining events)* | `harness.<name>` | no |

Blocking uses exit code 2 with a message on stderr. Exit 1 blocks nothing and is never used for
control. Advisory context uses `hookSpecificOutput.additionalContext` on exit 0.

**AEXO never uses exit 2 in default configuration.** The Gate advises; it does not block (TR6).
Exit 2 is available only under an explicitly enabled enterprise policy and is always recorded.

### Codex

Codex exposes five hook events, and `PreToolUse`/`PostToolUse` fire only for Bash. Consequently:

- A **shell command parser** is mandatory, not optional. `aexo-hook` classifies the command line
  into an intent (`read`, `write`, `search`, `test`, `build`, `vcs`, `network`, `other`) and
  extracts file arguments, so that a `cat`/`rg`/`sed` invocation produces the same canonical event
  a native read tool would.
- Coverage is therefore structurally lower than on Claude Code. The observability completeness
  metric (`2G`) reports this honestly rather than hiding it.

The parser handles: quoting, pipes, redirects, `&&`/`||`/`;` sequencing, common flags for the
top ~40 coreutils and dev tools, and `xargs`. Anything unrecognised is emitted as `other` with the
raw command retained — **never guessed**. A wrong classification is worse than an unknown one.

### Generic / OTel

Any harness that emits OpenTelemetry GenAI spans can be ingested by the daemon's OTLP receiver
without a hook at all (`28`). This is the escape hatch that keeps AEXO from being a Claude Code
accessory.

## 31.6 Redaction placement

The hook performs **no** redaction. Redaction happens once, on the daemon's single append path
(`22.4`). Putting it in the hook would mean shipping the pattern set to every invocation, paying
its compile cost per call, and having two places to keep correct.

The consequence — raw secrets briefly transit the socket — is acceptable because the socket is
local, mode `0600`, and owned by the invoking user. The spool file is the exception: it is written
with mode `0600` and its contents are redacted by the daemon at drain time before durable storage.
A spool file is treated as sensitive until drained.

## 31.7 Configuration

Read from `$AEXO_HOME/config.toml`, parsed lazily and cached in a memory-mapped, version-stamped
binary form written by the daemon. The hook reads the binary form (sub-100µs) and falls back to
parsing TOML only if the stamp is missing or stale.

## 31.8 Acceptance criteria

**AC-CAPR-1.** Given a Claude Code `PreToolUse` payload on stdin and a running daemon, when the
hook executes, then it exits 0 within 10ms at p99 and the emitted event validates against the
Canonical Activity Event schema.

**AC-CAPR-2.** Given no daemon is running, when any hook fires, then it exits 0 within its
ceiling, the event is present in the spool directory, and for a gating event the harness receives
an allow verdict marked degraded.

**AC-CAPR-3.** Given 10,000 spooled events across 40 spool files, when the daemon starts, then all
10,000 appear in the log exactly once, ordered by their embedded monotonic timestamps.

**AC-CAPR-4.** Given a spool directory at its 256MB cap, when further events arrive, then they are
dropped, the dropped counter increments, and the next `aexo doctor` and the next injected health
notice both report the loss.

**AC-CAPR-5.** Given a Codex Bash invocation `rg -n "TODO" src/ | head -20`, when the hook parses
it, then the intent is `search`, the path argument `src/` is extracted, and the pipe target is not
misclassified as a separate read.

**AC-CAPR-6.** Given a Bash command the parser does not recognise, when it is captured, then the
intent is `other`, the raw command is retained, and no file arguments are asserted.

**AC-CAPR-7.** Given the hook binary on each supported platform, when cold start-up is measured
100 times, then the median is within the platform target in §31.2.

**AC-CAPR-8.** Given a malformed or truncated JSON payload on stdin, when the hook executes, then
it exits 0, emits a `capture.malformed` health event, and does not crash or hang.

**AC-CAPR-9.** Given the daemon is killed while the hook is mid-write, when the hook's write
fails, then the hook falls back to spool and still exits 0 within its ceiling.

**AC-CAPR-10.** Given default configuration, when any Gate verdict is `warn`, then the hook exits
0 and never exit 2, and the warning is delivered as additional context.
