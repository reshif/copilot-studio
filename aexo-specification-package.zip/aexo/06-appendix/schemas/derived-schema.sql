-- AEXO derived state schema, v7
-- Nothing here is authoritative. All of it is a deterministic fold of the event log
-- and can be dropped and rebuilt at any time. Do not add a column whose value cannot
-- be recomputed from the log.

PRAGMA journal_mode = WAL;
PRAGMA synchronous  = NORMAL;
PRAGMA foreign_keys = ON;

CREATE TABLE schema_meta (
    key   TEXT PRIMARY KEY,
    value TEXT NOT NULL
);
-- rows: version=7, built_to_seq=<n>, built_at=<ts>, fold_impl_hash=<hash>

-- ---------------------------------------------------------------- events index

CREATE TABLE events_idx (
    seq        INTEGER PRIMARY KEY,
    id         TEXT    NOT NULL UNIQUE,
    kind       TEXT    NOT NULL,
    t_event    TEXT    NOT NULL,
    t_ingest   TEXT    NOT NULL,
    actor_kind TEXT    NOT NULL,
    actor_id   TEXT    NOT NULL,
    project    TEXT    NOT NULL,
    mission    TEXT,
    run        TEXT,
    agent      TEXT,
    epoch      TEXT,
    tenant     TEXT,
    trust      TEXT    NOT NULL,
    degraded   INTEGER NOT NULL DEFAULT 0,
    blob_hash  TEXT
);
CREATE INDEX ix_events_kind   ON events_idx(kind, seq);
CREATE INDEX ix_events_epoch  ON events_idx(epoch, seq);
CREATE INDEX ix_events_tenant ON events_idx(tenant, seq);

-- ------------------------------------------------- per-Epoch knowledge state
-- The Gate's basis. Scoped to Epoch, which is what makes subagent read-exemption
-- structural rather than a special case.

CREATE TABLE knowledge_state (
    epoch        TEXT    NOT NULL,
    artefact     TEXT    NOT NULL,
    content_hash TEXT    NOT NULL,
    first_seen   INTEGER NOT NULL,
    last_seen    INTEGER NOT NULL,
    read_count   INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (epoch, artefact, content_hash)
);

-- ---------------------------------------------------------------- artefacts

CREATE TABLE artefacts (
    project      TEXT NOT NULL,
    path         TEXT NOT NULL,
    commit_id    TEXT NOT NULL,
    content_hash TEXT NOT NULL,
    size         INTEGER,
    language     TEXT,
    last_seq     INTEGER NOT NULL,
    PRIMARY KEY (project, path, commit_id)
);

-- ---------------------------------------------------------------- episodes

CREATE TABLE episodes (
    id                 TEXT PRIMARY KEY,
    project            TEXT NOT NULL,
    mission            TEXT,
    run                TEXT,
    agent              TEXT,
    epoch              TEXT,
    seq_from           INTEGER NOT NULL,
    seq_to             INTEGER NOT NULL,
    opened_at          TEXT NOT NULL,
    closed_at          TEXT,
    close_reason       TEXT,
    outcome            TEXT NOT NULL,
    outcome_confidence TEXT NOT NULL,
    summary            TEXT,          -- advisory only; never citable as evidence
    summary_prompt_ver TEXT
);
CREATE INDEX ix_episodes_outcome ON episodes(project, outcome, closed_at);

-- ---------------------------------------------------------------- evidence

CREATE TABLE evidence (
    id                 TEXT PRIMARY KEY,
    source_type        TEXT NOT NULL
        CHECK (source_type IN ('event_range','verification','human_statement',
                               'structural_fact','episode_field','import')),
    source_ref         TEXT NOT NULL,
    trust              TEXT NOT NULL,
    observed_at        TEXT NOT NULL,
    scope_json         TEXT,
    independence_group TEXT,
    created_seq        INTEGER NOT NULL
);
CREATE INDEX ix_evidence_group ON evidence(independence_group);

-- ---------------------------------------------------------------- claims

CREATE TABLE claims (
    id                TEXT PRIMARY KEY,
    project           TEXT NOT NULL,
    tenant            TEXT,
    statement         TEXT NOT NULL,
    scope_json        TEXT NOT NULL,
    band              TEXT NOT NULL
        CHECK (band IN ('derived','observed','supported','verified','attested')),
    provenance_depth  INTEGER NOT NULL DEFAULT 0
        CHECK (provenance_depth BETWEEN 0 AND 2),
    trust             TEXT NOT NULL,
    verifier_json     TEXT,
    last_verified     TEXT,
    last_result       TEXT,
    consecutive_errs  INTEGER NOT NULL DEFAULT 0,
    valid_from        TEXT,
    valid_to          TEXT,
    recorded_from     TEXT NOT NULL,
    recorded_to       TEXT,
    superseded_by     TEXT REFERENCES claims(id),
    retired           INTEGER NOT NULL DEFAULT 0,
    retired_reason    TEXT,
    prompt_version    TEXT,
    retrieval_count   INTEGER NOT NULL DEFAULT 0,
    created_seq       INTEGER NOT NULL
);
CREATE INDEX ix_claims_band    ON claims(project, band, retired);
CREATE INDEX ix_claims_stale   ON claims(project, last_verified);
CREATE INDEX ix_claims_prompt  ON claims(prompt_version);

CREATE TABLE claim_support (
    claim_id    TEXT NOT NULL REFERENCES claims(id),
    evidence_id TEXT NOT NULL REFERENCES evidence(id),
    relation    TEXT NOT NULL CHECK (relation IN ('SUPPORTS','CONTRADICTS')),
    weight      REAL NOT NULL DEFAULT 1.0,
    PRIMARY KEY (claim_id, evidence_id)
);

-- Candidate generation index for contradiction detection. Without this, detection
-- is O(n^2) in claims; with it, only scope-overlapping candidates are compared.
CREATE TABLE claim_scope_idx (
    scope_key TEXT NOT NULL,
    claim_id  TEXT NOT NULL REFERENCES claims(id),
    PRIMARY KEY (scope_key, claim_id)
);
CREATE INDEX ix_scope_claim ON claim_scope_idx(claim_id);

-- ---------------------------------------------------------------- judgement

CREATE TABLE verifications (
    id           TEXT PRIMARY KEY,
    claim_id     TEXT NOT NULL REFERENCES claims(id),
    ran_at       TEXT NOT NULL,
    result       TEXT NOT NULL CHECK (result IN ('pass','fail','error','timeout')),
    verifier_ver TEXT,
    exit_code    INTEGER,
    duration_ms  INTEGER,
    created_seq  INTEGER NOT NULL
);
CREATE INDEX ix_verif_claim ON verifications(claim_id, ran_at);

CREATE TABLE contradictions (
    id           TEXT PRIMARY KEY,
    claim_a      TEXT NOT NULL REFERENCES claims(id),
    claim_b      TEXT NOT NULL REFERENCES claims(id),
    tier         INTEGER NOT NULL CHECK (tier BETWEEN 1 AND 4),
    class        TEXT    NOT NULL
        CHECK (class IN ('supersession','refinement','contradiction','apparent')),
    status       TEXT    NOT NULL
        CHECK (status IN ('open','resolved','dismissed')),
    raised_at    TEXT NOT NULL,
    resolved_at  TEXT,
    resolved_by  TEXT,
    resolution   TEXT,
    reason       TEXT,
    created_seq  INTEGER NOT NULL
);
CREATE INDEX ix_contra_open ON contradictions(status, raised_at);

CREATE TABLE decisions (
    id            TEXT PRIMARY KEY,
    project       TEXT NOT NULL,
    statement     TEXT NOT NULL,
    alternatives  TEXT,
    rationale_ref TEXT,
    actor_kind    TEXT NOT NULL,
    actor_id      TEXT NOT NULL,
    decided_at    TEXT NOT NULL,
    created_seq   INTEGER NOT NULL
);

CREATE TABLE policies (
    id            TEXT PRIMARY KEY,
    project       TEXT NOT NULL,
    tenant        TEXT,
    name          TEXT NOT NULL,
    source        TEXT NOT NULL,
    compiled_hash TEXT NOT NULL,
    scope_key     TEXT NOT NULL,
    active        INTEGER NOT NULL DEFAULT 0,
    origin        TEXT NOT NULL CHECK (origin IN ('org','project','local')),
    author_id     TEXT NOT NULL,        -- MUST be a human identity
    activated_at  TEXT,
    created_seq   INTEGER NOT NULL
);
CREATE INDEX ix_policies_active ON policies(project, active, scope_key);

-- Content-keyed failed-fix fingerprints. The signature is computed over an
-- alpha-renamed, literal-bucketed AST shape, so a repeat attempt is recognised
-- even when paths, identifiers and formatting have all changed.
CREATE TABLE remedy_signatures (
    signature    TEXT PRIMARY KEY,
    project      TEXT NOT NULL,
    precision    TEXT NOT NULL CHECK (precision IN ('exact','coarse')),
    first_seen   INTEGER NOT NULL,
    last_seen    INTEGER NOT NULL,
    attempts     INTEGER NOT NULL DEFAULT 1,
    failures     INTEGER NOT NULL DEFAULT 0,
    last_outcome TEXT,
    episode_ref  TEXT
);

CREATE TABLE gate_verdicts (
    seq        INTEGER PRIMARY KEY,
    epoch      TEXT,
    check_kind TEXT NOT NULL,
    verdict    TEXT NOT NULL CHECK (verdict IN ('allow','warn','block')),
    rule_id    TEXT,
    policy_ver TEXT,
    degraded   INTEGER NOT NULL DEFAULT 0,
    latency_us INTEGER,
    later_correct INTEGER   -- NULL until resolved; feeds false-warning rate
);
CREATE INDEX ix_gate_kind ON gate_verdicts(check_kind, verdict, seq);

-- ---------------------------------------------------------------- structure

CREATE TABLE structure_symbols (
    project   TEXT NOT NULL,
    commit_id TEXT NOT NULL,
    path      TEXT NOT NULL,
    symbol    TEXT NOT NULL,
    kind      TEXT NOT NULL,
    signature TEXT,
    line_from INTEGER,
    line_to   INTEGER,
    precision TEXT NOT NULL CHECK (precision IN ('syntactic','indexed','live','deep')),
    PRIMARY KEY (project, commit_id, path, symbol, line_from)
);
CREATE INDEX ix_sym_lookup ON structure_symbols(project, symbol);

CREATE TABLE structure_refs (
    project    TEXT NOT NULL,
    commit_id  TEXT NOT NULL,
    symbol     TEXT NOT NULL,
    path       TEXT NOT NULL,
    line       INTEGER NOT NULL,
    ref_kind   TEXT NOT NULL,
    precision  TEXT NOT NULL,
    PRIMARY KEY (project, commit_id, symbol, path, line)
);

-- ---------------------------------------------------------------- projection

CREATE TABLE receipts (
    receipt_id       TEXT PRIMARY KEY,
    at_seq           INTEGER NOT NULL,
    epoch            TEXT,
    injection_point  TEXT NOT NULL,
    total_tokens     INTEGER NOT NULL,
    lifetime_cost    REAL,
    expected_turns   INTEGER,
    cache_position   TEXT,
    cache_mut_cost   REAL NOT NULL DEFAULT 0,
    ttl_regime       TEXT,
    budget           INTEGER NOT NULL,
    degraded         INTEGER NOT NULL DEFAULT 0,
    disputed         INTEGER NOT NULL DEFAULT 0,
    created_seq      INTEGER NOT NULL
);

CREATE TABLE receipt_items (
    receipt_id TEXT NOT NULL REFERENCES receipts(receipt_id),
    item_type  TEXT NOT NULL,
    item_id    TEXT NOT NULL,
    tokens     INTEGER NOT NULL,
    band       TEXT,
    reserved   INTEGER NOT NULL DEFAULT 0,
    score_json TEXT,
    PRIMARY KEY (receipt_id, item_type, item_id)
);

-- ---------------------------------------------------------------- observability

CREATE TABLE health (
    seq       INTEGER PRIMARY KEY,
    kind      TEXT NOT NULL,
    severity  TEXT NOT NULL CHECK (severity IN ('info','warning','critical')),
    detail    TEXT,
    at        TEXT NOT NULL,
    resolved  INTEGER NOT NULL DEFAULT 0
);
CREATE INDEX ix_health_open ON health(resolved, severity, seq);

CREATE TABLE completeness (
    harness     TEXT NOT NULL,
    event_kind  TEXT NOT NULL,
    window_from TEXT NOT NULL,
    captured    INTEGER NOT NULL DEFAULT 0,
    dropped     INTEGER NOT NULL DEFAULT 0,
    degraded    INTEGER NOT NULL DEFAULT 0,
    unsupported INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (harness, event_kind, window_from)
);

CREATE TABLE metrics_rollup (
    window_from TEXT NOT NULL,
    window_to   TEXT NOT NULL,
    metric      TEXT NOT NULL,
    value       REAL NOT NULL,
    denominator REAL,        -- ESK and rate metrics MUST record their denominator
    PRIMARY KEY (window_from, metric)
);
