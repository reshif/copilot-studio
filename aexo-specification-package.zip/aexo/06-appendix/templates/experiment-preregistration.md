# Experiment pre-registration template

Filed **before** the experiment runs. Timestamped and published alongside results. A result whose
pre-registration was written afterwards is not a result.

---

## Identification

- **Experiment ID:**
- **Date registered:**
- **Registrant:**
- **Design:** D1 shadow | D2 paired A/B | D3 counterfactual replay | D4 seeded defect | D5 field

## Hypothesis

State it so that it can fail.

> H1: <specific, directional, quantified>

**This hypothesis is falsified if:** <specific observable outcome>

## Primary metric

- **Metric:**
- **Definition:** (precise enough to reimplement)
- **Denominator:** (required for ESK and all rate metrics)

Exactly one primary metric. Everything else is secondary and will be reported as exploratory.

## Secondary metrics

## Conditions

| Factor | Value |
|---|---|
| Corpus / repositories | |
| N (tasks) | |
| Seeds per arm | |
| Model and version | |
| Temperature | |
| Harness and version | |
| AEXO version | |
| Configuration (arms) | |

## Analysis plan

- Pairing:
- Effect size measure:
- Confidence interval method:
- Multiple-comparison correction:
- Exclusion rules: (defined now, not after seeing the data)

## Stopping rule

When does the experiment end? Fixed N is preferred. If sequential, state the boundary.

## Known confounds and how they are handled

| Confound | Handling |
|---|---|
| Task difficulty | Paired design |
| Model drift | Version pinned; a re-run on a new model is a new experiment |
| Ordering effects | Randomised |
| Evaluator bias | Blinded |
| Synthetic vs mined defects | Reported separately |

## Assumptions that must be disclosed in the report

For D3 (counterfactual replay), this MUST include the behavioural-invariance assumption: that the
agent's actions would have been unchanged by the injection being modelled. It is false in general
and the report must say so.

## Commitment

- [ ] All results will be published, including null and negative ones
- [ ] The harness will be published
- [ ] Deviations from this plan will be disclosed as deviations, not presented as the plan
