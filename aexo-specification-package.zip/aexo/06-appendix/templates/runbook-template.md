# RB-NN · <Symptom as a user would describe it>

**Severity:** critical | high | medium | low
**Typical cause:**
**Expected time to resolve:**

## Symptom

What the user or operator actually sees. Use their words, not internal terminology — this is how
the runbook gets found.

## Do not

Anything destructive or irreversible that a reasonable person might try first. Put this before the
diagnosis, not after. For example: "do not rebuild before determining whether the chain is intact".

## Diagnose

```bash
aexo doctor
# ... specific commands
```

| Cause | Distinguishing signal | Action |
|---|---|---|
| | | |

## Act

Numbered steps, in order, with the reason each step comes where it does.

1.
2.

## Verify

The specific command and the specific output that means it is fixed. Not "check that it works".

## If it recurs

What to escalate, what to capture first, and which risk register entry this maps to.
