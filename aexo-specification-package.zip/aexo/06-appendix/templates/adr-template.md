# ADR-NNN — <Title>

**Status:** proposed | accepted | superseded by ADR-NNN
**Date:** YYYY-MM-DD
**Deciders:** <names>
**Affects:** <spec files, components>

## Context

What forces are at play? What constraint, budget or requirement makes this a decision rather than a
default? State the problem in a way that would still make sense to someone who joins in a year.

If this touches a performance budget (`2I`), a trade rejection (TR1–TR7) or the dependency budget
(`2E`), say so here explicitly.

## Options considered

### Option A — <name>
- **What it is:**
- **Pros:**
- **Cons:**
- **Cost:** (build, run, maintain)

### Option B — <name>
...

### Option C — do nothing
Always considered. State what happens if we simply don't.

## Decision

<The chosen option, stated in one sentence.>

Because: <the deciding factor — not a list, the single thing that tipped it>.

## Consequences

**Accepted costs.** What we are now stuck with. Be specific and unflattering.

**Foreclosed options.** What this makes harder or impossible later.

**New obligations.** Tests that must now exist, budgets that must now be enforced, documentation
that must now be maintained.

## Revisit when

Concrete, observable triggers — not "periodically". For example: "when concurrent readers exceed
64", "if hook p99 exceeds 10ms on any platform", "if a harness ships equivalent functionality
natively".

## Acceptance criteria

**AC-ADR-NNN-1.** Given ..., when ..., then ...
