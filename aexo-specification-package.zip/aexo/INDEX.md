# AEXO — Package Index

Complete research and specification package. Read in the order below, or jump by need.

## If you have 20 minutes

1. `00-executive/00-executive-summary.md`
2. `01-research/13-token-economics.md` — the corrected cost model that changes the product's shape
3. `02-architecture/20-architecture-overview.md`
4. `04-delivery/47-estimates-and-budget.md` — the honest scope reconciliation

## If you are deciding whether to fund this

`00-executive/` in full → `01-research/11-competitive-analysis.md` →
`01-research/12-prior-art-matrix.md` → `04-delivery/44-evaluation-and-benchmarks.md` →
`04-delivery/45-risk-register.md` → `04-delivery/47-estimates-and-budget.md`

## If you are going to build it

`02-architecture/` in full → `03-specs/` for your component →
`04-delivery/42-task-backlog.md` → `04-delivery/43-acceptance-test-catalog.md`

## If you are migrating from OpenWolf

`05-operations/52-migration-from-openwolf.md` first — it maps all 17 gaps to their resolutions —
then `05-operations/50-setup-guide.md`.

---

## Contents

### 00-executive
| File | What it is |
|---|---|
| `00-executive-summary.md` | The whole argument in a few pages |
| `01-problem-statement.md` | What is broken, with evidence |
| `02-thesis-and-north-star.md` | The thesis and ESK |
| `03-scope-and-non-goals.md` | Principles P1–P12, trade rejections TR1–TR7 |
| `04-glossary.md` | Every term used precisely |

### 01-research
| File | What it is |
|---|---|
| `10-research-landscape.md` | The 2026 agent-memory landscape |
| `11-competitive-analysis.md` | Who is doing what, and where the gaps are |
| `12-prior-art-matrix.md` | 33-row feature matrix |
| `13-token-economics.md` | **The key artefact.** Lifetime multipliers, prefix mutation cost, why warn-only is net-negative |
| `14-harness-landscape.md` | Claude Code, Codex, MCP 2026-07-28, OTel GenAI |
| `15-code-intelligence-landscape.md` | tree-sitter, SCIP/LSIF, LSP, CodeQL |
| `16-security-threat-landscape.md` | Threats T1–T9, memory poisoning as OWASP ASI06 |
| `17-standards-and-compliance.md` | EU AI Act, ISO 42001, SOC 2, W3C PROV |
| `18-open-questions.md` | Q1–Q12, unresolved |
| `19-bibliography.md` | Full sources with URLs |

### 02-architecture
| File | What it is |
|---|---|
| `20-architecture-overview.md` | Five planes, control plane, structure plane |
| `21-domain-model.md` | Entities and relationships |
| `22-event-layer-spec.md` | Canonical events, chain, redaction |
| `23-experience-model-spec.md` | Episodes, Evidence, Claims, Decisions, Policies |
| `24-provenance-and-evidence-graph.md` | PROV-DM extended with SUPPORTS/CONTRADICTS |
| `25-validity-supersession-contradiction.md` | Bands, decay, conflict classes |
| `26-projection-engine-spec.md` | Selection, budgets, receipts |
| `27-code-intelligence-plane.md` | Precision tiers |
| `28-capture-adapters-spec.md` | Per-harness adapters and OTel ingest |
| `29-governance-gate-spec.md` | Checks, verdicts, remedy signatures |
| `2A-trust-and-taint-model.md` | The lattice |
| `2B-multi-agent-identity-model.md` | Project → Mission → Run → Agent → Epoch → Action |
| `2C-storage-and-consistency.md` | Bitemporality, single writer, rebuild |
| `2D-api-surface-spec.md` | REST, gRPC, MCP surface |
| `2E-technology-selection.md` | ADR-001 … ADR-014, dependency budget |
| `2F-deployment-topologies.md` | T1–T6 with sizing |
| `2G-observability-spec.md` | Completeness as an SLO, `aexo doctor` |
| `2H-security-architecture.md` | Controls S1–S14 |
| `2I-performance-budgets.md` | Every latency, throughput and token budget |

### 03-specs
| File | Component |
|---|---|
| `30-component-map.md` | All 20 components, boundaries, failure isolation |
| `31-capture-runtime-spec.md` | `aexo-hook` |
| `32-daemon-spec.md` | `aexo-daemon` |
| `33-event-store-spec.md` | Log, segments, blobs, integrity |
| `34-derived-state-spec.md` | The fold |
| `35-structure-indexer-spec.md` | Code intelligence |
| `36-episode-consolidator-spec.md` | Episodes |
| `37-claim-engine-spec.md` | Candidate → admission |
| `38-verifier-runner-spec.md` | Verification and decay |
| `39-contradiction-engine-spec.md` | Detection and classification |
| `3A-projection-engine-spec.md` | Selection and injection |
| `3B-governance-gate-spec.md` | The Gate |
| `3C-mcp-server-spec.md` | MCP surface |
| `3D-rest-server-spec.md` | FastAPI server |
| `3E-cli-spec.md` | `aexo` |
| `3F-reflection-worker-spec.md` | The only model-calling component |
| `3G-dashboard-spec.md` | Deliberately unflattering views |
| `3H-eval-harness-spec.md` | Making the claim falsifiable |
| `3I-importers-spec.md` | Migration in |
| `3J-policy-compiler-spec.md` | The DSL |
| `3K-control-plane-spec.md` | Enterprise fleet |

### 04-delivery
| File | What it is |
|---|---|
| `40-roadmap-and-phases.md` | P0–P5 with testable exit gates |
| `41-work-breakdown-structure.md` | Areas, dependency spine, Definition of Done |
| `42-task-backlog.md` | 240 tasks with IDs, deps, estimates, DoD tests |
| `43-acceptance-test-catalog.md` | **212 acceptance tests in Given/When/Then form** |
| `44-evaluation-and-benchmarks.md` | Designs D1–D5, seeded-defect benchmark, pre-registered predictions |
| `45-risk-register.md` | Scored risks with triggers |
| `46-team-and-raci.md` | Roles, staffing curve, decision rights |
| `47-estimates-and-budget.md` | The honest reconciliation and four options |

### 05-operations
| File | What it is |
|---|---|
| `50-setup-guide.md` | Install through first session |
| `51-runbooks.md` | RB-01 … RB-11 |
| `52-migration-from-openwolf.md` | All 17 gaps mapped; import that never launders authority |
| `53-slos-and-health.md` | SLOs, health taxonomy, `aexo doctor` reference output |

### 06-appendix
| File | What it is |
|---|---|
| `schemas/canonical-activity-event.schema.json` | The envelope |
| `schemas/claim.schema.json` | Claims, with the depth cap in the schema |
| `schemas/episode.schema.json` | Episodes |
| `schemas/evidence.schema.json` | Evidence, with non-citable sources absent by construction |
| `schemas/receipt.schema.json` | Injection receipts |
| `schemas/derived-schema.sql` | Full DDL, v7 |
| `schemas/policy-dsl-grammar.ebnf` | The grammar, with a note on what is deliberately absent |
| `templates/adr-template.md` | |
| `templates/policy-template.aexo` | |
| `templates/claim-template.md` | |
| `templates/experiment-preregistration.md` | |
| `templates/runbook-template.md` | |

---

## Conventions used throughout

- **RFC 2119** MUST / SHOULD / MAY.
- Every spec ends with numbered natural-language **acceptance criteria** (`AC-<AREA>-<N>`).
- Task IDs: `AEXO-<AREA>-<NNN>`. Acceptance test IDs: `AT-<AREA>-<NNN>`.
- ADRs follow Context → Options → Decision → Consequences → Revisit-when.
- Where a decision was contested, the rejected option and the reason are recorded rather than
  omitted.
