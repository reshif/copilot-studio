# 10 — Research Landscape

*Survey conducted August 2026. Reference numbers resolve in `19-bibliography.md`.*

## 10.1 How the field organises itself

Agent memory research has stratified into five threads that rarely talk to each other. AEXO
sits deliberately at the intersection of threads 2, 3, 4 and 5.

**Thread 1 — Retrieval-oriented conversational memory.**
The dominant commercial paradigm: extract salient facts, embed them, retrieve top-k at query
time. MemGPT/Letta pioneered an operating-system metaphor with paging between context and
external storage [7]. Mem0 layers user/session/agent scopes over vector, graph and key-value
stores [4]. Zep's Graphiti engine adds temporal awareness so facts carry validity intervals and
history is preserved rather than overwritten [16]. A-MEM organises memory as a Zettelkasten of
dynamically linked notes [24]. Memanto pairs a typed semantic schema with information-theoretic
retrieval [1].

*What AEXO takes:* typed memory (Memanto), temporal validity on facts (Zep), scoping (Mem0).
*What AEXO rejects:* LLM-in-the-loop extraction as the authoritative path, and top-k passage
retrieval as the primary interface. Both introduce nondeterminism where determinism is cheap.

**Thread 2 — Project memory for coding agents.**
A much younger thread, and the one AEXO is actually competing in. Two systems define it.
*Codified Context* [20] pairs a Markdown "constitution" of conventions with on-demand
specification documents retrieved by keyword, served over MCP, with a drift detector that fires
at session start from git divergence. *projectmem* [5-pm] records development as an append-only
JSONL log of typed events (issue / attempt / fix / decision / note), deterministically projects
it into a compact summary, and — the distinguishing move — adds a deterministic pre-action gate
that warns before an agent repeats a previously-failed fix or touches a file with a record of
churn. Its authors name the design point **Memory-as-Governance**: memory that acts on the
agent's next action rather than merely answering it.

*What AEXO takes:* the whole substrate. Append-only typed events, deterministic projection,
plain-text legibility, git-native storage, MCP as the interface, secret redaction at the append
path, cross-project promotion of library-level lessons, and above all the pre-action gate.
*Where AEXO goes further:* provenance and contradiction, a trust lattice, verification-driven
expiry, cache-aware economics, multi-harness telemetry capture, and a controlled effectiveness
result — which the projectmem authors themselves identify as the single most valuable missing
piece and as a benchmark the category currently lacks.

**Thread 3 — Event sourcing for agent systems.**
Independently and concurrently, event sourcing has been proposed as the substrate for
autonomous SE agents: an append-only log of intentions and effects from which state is
deterministically projected [ESAA]. Anthropic's Managed Agents architecture arrives at the same
shape from an operations direction: the session is an append-only event log that lives *outside*
the harness and outside the context window, interrogable by positional slice via `getEvents()`,
so a crashed harness can be rebooted and resumed from the last event, and so context management
can be arbitrary and swappable because durability is guaranteed elsewhere [ANT-MA].

This convergence is the strongest signal in the survey. Three independent groups, from
research, from open source, and from a frontier lab's production infrastructure, arrived at
"append-only event log, derived projections, context as an object outside the window."

*What AEXO takes:* the architecture, and the specific insight that the session log should be
**sliceable and re-interrogable**, not merely summarisable. AEXO's Projection Engine is the
generalisation: instead of positional slices, semantic and relevance-bounded slices.

**Thread 4 — Learning from failure, and pre-action guardrails.**
Reflexion stores verbal feedback on failed trials in an episodic buffer that improves the next
trial without weight updates [17]. Recent work shows agents can attribute cascading failure to
a root cause and recover — but retrospectively [26]. On the intervention side, AGrail is a
lifelong boolean pre-action gate whose safety checks self-optimise [11]; ToolSafe performs
step-level pre-execution reasoning [12]; LlamaFirewall layers jailbreak, alignment and
insecure-code checks at runtime [3]; Meta-Policy Reflexion consolidates reflections into
predicate-like rules with admissibility checks [23]. These share the *timing* — before the
action — but their gates are model-trained and therefore nondeterministic, and they target
generic safety categories rather than a specific project's recorded failures.

*What AEXO takes:* Reflexion's episodic buffer, externalised and persisted; the guardrail
thread's timing. *What AEXO adds:* determinism. AEXO's gate is a lookup against a project's own
verified history, so it is reproducible, explainable, and unit-testable.

**Thread 5 — Provenance and trust.**
The 2026 survey of evidence tracing and execution provenance in LLM agents [PROV-SURVEY] gives
the mapping AEXO needs. W3C PROV-DM supplies Entity / Activity / Agent and the relations
`used`, `wasGeneratedBy`, `wasDerivedFrom`, `wasRevisionOf`, `wasAttributedTo`. The survey shows
these map cleanly onto agent artefacts — retrieved passages, tool outputs, memory items,
generated claims — but that PROV has **no vocabulary for support or contradiction**. Those
relations are agent-specific: evidence *supports* a claim; a tool output *contradicts* a memory
item. PROV-AGENT [PROV-AGENT] extends PROV for agentic workflows and integrates MCP.

*What AEXO takes:* PROV-DM as the base vocabulary for the Evidence Graph, extended with
`SUPPORTS`, `CONTRADICTS`, `VERIFIES` and `SUPERSEDES` — exactly the gap the survey identifies.
This gives AEXO an interoperable, standards-anchored provenance model rather than a bespoke one,
which matters materially for enterprise audit.

## 10.2 The findings that changed the design

Five research findings altered AEXO's architecture from the naive version.

**Finding 1 — Context management is now a platform primitive, and it works.**
Compaction, context editing (clearing spent tool results), memory tools and context-awareness
feedback are shipped features. Vendor-reported evaluations attribute a substantial performance
lift to context editing alone, more when paired with a memory tool, and very large token
reduction on hundred-turn runs [ANT-CE]. Programmatic tool calling lets code consume intermediate
tool outputs and return only the final result, keeping bulk out of the window entirely.

*Design consequence:* AEXO must not duplicate these. It should (a) *feed* compaction better
inputs, (b) *record* what compaction discarded so it can be re-supplied on demand, and (c) expose
experience as a **queryable object the agent can filter programmatically** rather than as a dump.
This is why the Projection Engine exposes both an "assembled bundle" mode and a "query tool"
mode.

**Finding 2 — Compaction has a sharp, asymmetric failure mode.**
A summary that drops a critical fact is worse than no summary, because later steps trust it and
cannot recover what was lost. The published guidance is to tune compaction prompts for recall
first, precision second [ANT-CE]. Separately, "context collapse" is documented: repeated
self-rewriting drives context toward brevity and erodes domain detail over iterations.

*Design consequence:* AEXO's post-compaction behaviour is not "mark files as unread." It is
"the durable record still holds the full evidence; here is a receipt of what you had, and a tool
to pull any of it back." AEXO also never rewrites its own store in a loop — Principle P2.

**Finding 3 — Irreversible context decisions are the wrong shape.**
The Managed Agents write-up is explicit: it is difficult to know which tokens future turns will
need, so irreversible retain/discard decisions cause failures. The structural fix is to store
context as an object outside the window that can be re-interrogated [ANT-MA].

*Design consequence:* AEXO's duplicate-read denial mode is demoted from headline feature to an
optional, off-by-default policy. Recoverability beats suppression.

**Finding 4 — Code intelligence has become a cost and accuracy control plane.**
Precomputed structure exposed as tools, with agents querying narrow facts rather than reading
broadly, is now a repeatable pattern. A 2026 study of a tree-sitter-derived knowledge graph
exposed over MCP reports roughly an order-of-magnitude reduction in agent token use and about
halved tool calls across a multi-repository corpus [CI-2026]. SCIP has largely displaced LSIF for
precise cross-repository navigation, using human-readable symbol identifiers over Protobuf, and
decouples indexing from serving [SCIP]. The counter-current is real too: SCIP requires full graph
reconstruction on repository update, which motivates tree-sitter-based file-incremental indexing
for the hot path [SCIP-RFC].

*Design consequence:* AEXO adopts a **two-tier** structure plane — tree-sitter for incremental,
always-available, language-agnostic structure, and SCIP/LSP for precise cross-references where
an index exists. It builds neither.

**Finding 5 — Persistent memory is a distinct, severe attack surface.**
Memory and context poisoning is a separate OWASP Agentic AI Top 10 category (ASI06) because its
controls differ from prompt-injection controls: the attack and its effect are temporally
decoupled, and poisoned entries are retrieved as the agent's own prior experience, giving them
outsized influence. Published attack success rates against production-shaped agent memory reach
the 80–99% range, and entry-by-entry LLM detection misses the large majority of poisoned items
because they look benign in isolation [MEM-SEC].

*Design consequence:* detection is a second line. The first line is the trust lattice: content
whose provenance is untrusted cannot structurally become a directive, no matter how it is
phrased. Plus provenance-depth limits to stop self-derived belief compounding.

## 10.3 What the field has not solved

The gaps below are where AEXO can make an original contribution.

1. **No accepted effectiveness benchmark for coding-agent memory.** Memory benchmarks that exist
   (LoCoMo, LongMemEval and its V2, BEAM, MemoryAgentBench, MemoryArena, RealMem) are largely
   conversational or QA-shaped [MEM-BENCH]. A benchmark of memory in LLM agents finds no current
   architecture masters all of accurate retrieval, test-time learning, long-range understanding
   and conflict resolution [8]. Nothing measures "repeat failures prevented per N commits" for a
   software project.
2. **No contradiction resolution.** Every surveyed system stores facts. None reconciles a scoped
   conflict between two learned rules.
3. **No verification-driven validity.** Temporal knowledge graphs track *when we learned* a fact
   and sometimes *when it stopped being asserted*. None re-executes a check to decide whether it
   is *still true*.
4. **No net-of-cache economics.** Every token-savings claim in the category is gross.
5. **Weak treatment of observability completeness.** Every hook-based system silently
   under-observes, and none reports by how much.
6. **Independent benchmarking is showing large gaps between vendor-reported and reproduced
   numbers.** At least one independent harness reports a managed memory product scoring far above
   its own open-source edition on the same benchmark [MEM-BENCH]. The lesson is to publish
   reproducible harnesses, not scores.

## 10.4 Positioning statement

AEXO is **Memory-as-Governance with provenance**. It takes the emerging consensus substrate —
local-first, event-sourced, plain-text, MCP-native, deterministic pre-action gate — and adds the
four things that substrate is missing before it can be trusted for years of autonomous
operation: an evidence graph, a validity model driven by verification, a contradiction engine,
and a trust boundary that survives adversarial repository content.
