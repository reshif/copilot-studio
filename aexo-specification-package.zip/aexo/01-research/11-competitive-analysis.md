# 11 — Competitive and Adjacent Systems Analysis

## 11.1 Direct competitors (coding-agent project memory)

### projectmem
Local-first, event-sourced, plain-text, MCP-native, with a deterministic pre-action gate and
cross-project library gotchas. Three Python dependencies, sub-5MB, no database engine, no
embeddings, secret redaction on by default, self-contained D3 dashboard. Reports estimated
per-session token load dropping from a 5,000–20,000 range with no memory layer to roughly
800–1,500 in MCP mode.

*Strengths:* the design is correct, minimal, and shipping. The Memory-as-Governance framing is
the right framing. The single-append-path discipline (redaction, promotion, timestamp hygiene
all funnel through one function) is a pattern AEXO should copy verbatim.

*Limits AEXO exploits:* single-user and local only; no provenance graph beyond the event
pointer; gate keys on file path rather than change content; no contradiction handling; no
validity or expiry model; no cache economics; token figures are self-study estimates rather than
a controlled benchmark; no multi-agent or subagent identity model.

*Strategic read:* projectmem is the reference implementation of the substrate. AEXO should be
**compatible with it** — able to import a `.projectmem/events.jsonl` — and compete on the
judgement, provenance and enterprise layers rather than on the substrate.

### Codified Context
Markdown constitution of conventions plus keyword-retrieved specification documents over MCP,
with git-divergence drift detection at session start.

*Limits:* passive prevention (the agent must choose to read); drift fires at session boundary
rather than per action; no failure history.

### OpenWolf (the system this project supersedes)
Hook-driven, `.wolf/` state directory, duplicate-read detection, anatomy index, memory ledger,
`cerebrum.md` rules, daemon reflection jobs. See `05-operations/52-migration-from-openwolf.md`
for the full gap analysis and import path.

## 11.2 Adjacent: general agent memory platforms

| System | Model | Where it wins | Why it does not solve our problem |
|---|---|---|---|
| Mem0 | Vector + graph + KV, three scopes | Managed, strong benchmark numbers, easy adoption | Conversational/personalisation shaped; cloud-hosted; nondeterministic extraction; no engineering-correctness semantics |
| Zep / Graphiti | Temporal knowledge graph | Fact validity intervals, history preservation, enterprise data integration | Hosted; embedding-retrieved; no verification of continued truth; no action gate |
| Letta / MemGPT | OS-style paging, self-editing memory | Elegant abstraction, influential | Recursive summarisation loses fidelity; mutable self-edited state is exactly the belief-hardening risk |
| A-MEM | Zettelkasten note network | Emergent structure | LLM-generated links; no provenance; no governance |
| Cognee | Open-source graph memory infra | Good substrate, self-hostable | Infrastructure, not a coding-agent product; you still build everything above it |
| Graphlit / Supermemory / MemMachine | Managed context platforms with connectors | Fast time-to-value, permissions, citations | Cloud dependency; general-purpose; the hard parts (validity, contradiction) remain yours |

**Read:** none of these is a competitor for the *engineering-correctness* use case. Several are
credible *components* — specifically, an optional semantic-recall index. AEXO's architecture
keeps that a pluggable, opt-in accessory behind a stable interface so that a customer who
already runs one can point AEXO at it.

## 11.3 Adjacent: code intelligence

| System | Nature | Relationship to AEXO |
|---|---|---|
| tree-sitter | Incremental parser, ~all languages | **Dependency.** Hot-path structure. |
| SCIP (Sourcegraph) | Protobuf index format, human-readable symbol IDs, replaces LSIF | **Dependency.** Ingest when present. |
| LSIF | Older graph format, still what some platforms consume natively | Ingest via conversion only |
| Language Server Protocol | Live, precise, per-language | **Dependency.** Query on demand for definitive answers. |
| CodeQL / Joern (CPG) | Deep semantic and dataflow analysis | Optional evidence source for high-value claims |
| Glean | Facebook-scale code knowledge | Enterprise ingest adapter, post-v1 |
| Local repo-map tools (aider-style, CodeGraph, KotaDB) | Tree-sitter + SQLite/embedded graph | Overlapping; AEXO's structure plane is a thin version of these joined to experience |
| ArgosBrain-class local engines | Rust, SCIP+LSP+tree-sitter unified graph over MCP | Closest structural analogue; complementary — they own structure, AEXO owns experience |

**Strategic read:** the structure plane is commoditising fast. Building it is a losing
investment; integrating it is a compounding one. AEXO's defensible asset is the join between
*structure* and *experience*: "this function has failed three times when changed together with
that config key" is a statement neither a code graph nor an event log can make alone.

## 11.4 Adjacent: guardrails and governance

LlamaFirewall (jailbreak, alignment, insecure-code layers), AGrail (self-optimising lifelong
pre-action gate), ToolSafe (step-level pre-execution reasoning), Meta-Policy Reflexion
(predicate rules with admissibility checks).

These occupy the same *timing slot* as AEXO's Gate. Coexistence, not competition: a deployment
should run a generic safety guardrail **and** AEXO's project-specific deterministic gate. AEXO's
Gate interface is designed to be chainable so that both can veto.

## 11.5 Adjacent: observability

LangSmith, Langfuse, Phoenix, Honeycomb, Datadog LLM observability. All are converging on
OpenTelemetry GenAI conventions.

**This is an opportunity, not a competition.** AEXO ingesting OTel GenAI spans means every
harness that emits them becomes a capture source for free. It also means AEXO can *export* to
these platforms, so an enterprise's existing observability investment shows agent experience
alongside everything else. Position: "AEXO is what your traces mean, not another place to look
at them."

## 11.6 Where AEXO could lose

Honest failure scenarios, with mitigations.

**L1 — A model vendor ships this.** Memory tools, compaction and session logs are already
platform primitives; a vendor could plausibly ship provenance-carrying project memory.
*Mitigation:* be cross-vendor and cross-harness from day one; be the layer that works when a
team runs three different agents. Vendor-native memory is single-vendor by construction.

**L2 — Models get good enough that memory is unnecessary.** The harness-assumptions-go-stale
argument is real: features added for one model generation became dead weight in the next.
*Mitigation:* AEXO's durable value is the *record*, not the crutch. Audit, provenance and
reproducibility do not become unnecessary as models improve — they become more necessary.

**L3 — Nobody adopts because setup friction exceeds perceived value.** The category's actual
killer.
*Mitigation:* one command to install, backfill from git history so day one is not empty, work
with zero configuration, and make the value visible immediately through the dashboard.

**L4 — We build the beautiful architecture and never prove it works.** The exact failure the
source review identified in OpenWolf (zero recorded sessions).
*Mitigation:* the eval harness is Phase 0 scope, not Phase 4. Shadow mode from week one.
