# 15 — Code Intelligence Landscape

## 15.1 Why AEXO must not build this

The OpenWolf review's eighth gap is correct and important: a home-grown anatomy index (file,
description, symbols, line ranges, hash) is useful for orientation and useless for the questions
that matter — what calls this, what depends on this type, where does this data flow, which test
proves this behaviour, which implementation satisfies this interface, which config enables this
branch, which service consumes this schema.

Those questions have mature answers. The field moved decisively between mid-2025 and mid-2026
from "ask the model, grep the repo, read files" toward "precompute structure, expose it as tools,
let agents query narrow facts." A 2026 study of a tree-sitter-derived knowledge graph exposed
over MCP reports roughly an order-of-magnitude reduction in agent token consumption and about
half the tool calls across a 31-repository corpus. The index stopped being a developer
convenience and became a cost, latency and accuracy control plane.

**AEXO's position: own experience, integrate structure.** The defensible asset is the *join*.

## 15.2 The options, assessed

### tree-sitter — the hot-path default
Incremental, error-tolerant parsing across essentially every language, with fast reparse on
edit. Gives symbols, ranges, scopes, imports, call sites within a file, and cheap
file-incremental updates.

*Verdict:* **Required.** This is the always-available tier. It is the only option that survives
a broken build, an unfamiliar language, a partial checkout, or a mid-edit file.

*Limit:* syntactic, not semantic. It cannot resolve which `process()` a call refers to across
modules.

### SCIP — the precision tier
Sourcegraph's Protobuf-based indexing format that replaced LSIF, centred on human-readable
string symbol identifiers rather than opaque numeric IDs. Decouples indexing from serving, so
sub-second symbol lookups work across large codebases without a live language server. Indexers
exist for major ecosystems (`scip-typescript`, `scip-java` covering Java/Scala/Kotlin, and
others), generated locally or in CI.

*Verdict:* **Ingest when available.** Do not require it.

*Limit and the counter-argument:* SCIP indexing is repository-scale, not file-scale. At least one
production RFC argues for removing SCIP precisely because it requires full graph reconstruction
on every update, which blocks true file-incremental indexing, and proposes tree-sitter
replacement. This is the empirical basis for AEXO's two-tier design: tree-sitter incrementally in
the hot path, SCIP refreshed on a slower cadence (CI, or idle) for precision.

### LSIF — legacy
Older graph encoding, superseded by SCIP, but still what some platforms consume natively; SCIP
provides CLI conversion to LSIF.

*Verdict:* ingest via conversion only. No native investment.

### Language Server Protocol — the live tier
Precise, per-language, authoritative, and already installed on most developer machines. AEXO can
speak LSP as a client and ask definitive questions on demand.

*Verdict:* **Query on demand for high-value claims.** Never in the hook hot path (LSP responses
are tens to hundreds of milliseconds). Use it during Episode consolidation and Claim
verification, where latency is irrelevant.

### CodeQL / Joern (code property graphs) — the deep tier
Dataflow, taint tracking, inter-procedural reachability. Expensive, powerful.

*Verdict:* **Optional evidence source.** Attach to a Claim's verifier when the Claim warrants it
("this input reaches this sink"). Enterprise phase.

### Glean — the scale tier
Facebook-scale code knowledge storage and querying.

*Verdict:* enterprise ingest adapter, post-v1, demand-driven.

### Repo-map / embedded-graph tools
The aider-style repo map, CodeGraph/Caveman-style indexers, KotaDB and similar embedded
tree-sitter+SQLite/graph tools; and unified local engines (SCIP + LSP + tree-sitter served over
MCP, typically in Rust, targeting sub-50ms symbol lookups).

*Verdict:* **Overlapping and commoditising.** AEXO's structure plane should be a thin, replaceable
implementation behind a stable interface, so that a customer already running one of these can
point AEXO at it instead. Ship a default; never lock it in.

### Embeddings / semantic search
*Verdict:* **opt-in accessory only.** Determinism, legibility and zero read-time model cost are
worth more at the core than fuzzy recall. Where broad semantic recall genuinely helps — free-text
search over episode narratives — a local, optional index is complementary rather than competing.
This mirrors the explicit design position of the closest prior art.

## 15.3 The AEXO structure plane

```
                    ┌───────────────────────────────────────────┐
                    │  Structure Provider Interface (stable)     │
                    │  symbols_at · defs · refs · callers ·      │
                    │  implements · type_of · imports · owns     │
                    └───┬──────────┬──────────┬──────────┬───────┘
                        │          │          │          │
                 tree-sitter    SCIP/LSIF    LSP      CodeQL/CPG
                 (always)      (when built) (on demand) (opt-in)
                        │          │          │          │
                        └──────────┴────┬─────┴──────────┘
                                        ▼
                          Resolution policy: best available
                          answer + a precision label
                          (`syntactic` | `indexed` | `live` | `deep`)
```

**Every structural answer AEXO returns carries its precision label.** A Claim grounded in a
`syntactic` answer gets lower confidence than one grounded in a `live` LSP answer. This is not
cosmetic: it is how the confidence model stays honest when the underlying index is weak.

## 15.4 The join that only AEXO can make

Structure alone answers "what calls `charge()`". Experience alone answers "changes to
`charge()` failed twice". The product is the conjunction:

| Query the join enables | Structure alone | Experience alone |
|---|---|---|
| "Which callers of this function have historically broken when it changed?" | ✗ | ✗ |
| "Which tests actually demonstrated this Claim, and do they still exist?" | ✗ | ✗ |
| "This edit touches a symbol under a Policy scope — warn." | ✗ | partial (path-only) |
| "The architecture generation this Claim was learned under no longer exists (the module was split)." | ✗ | ✗ |
| "Two files are co-changed in 80% of the failures we recorded." | ✗ | partial |
| "This config key enables the branch the failing test covers." | partial | ✗ |

The fourth row is the mechanism for **automatic staleness detection**: when the structure plane
reports that the symbols a Claim was scoped to have been renamed, moved, split or deleted, the
Claim's scope no longer resolves and it is automatically flagged `scope_unresolved` and demoted.
No calendar TTL required. See `02-architecture/25-validity-supersession-contradiction.md`.

## 15.5 Storage of structural facts

Structural facts are **derived**, and therefore disposable and rebuildable (Principle P1). They
live in a separate, droppable store keyed by `(repo, commit_sha, provider, provider_version)` so
that:

- rebuilding is always safe,
- answers are reproducible against a specific commit,
- a Claim can record *which structural snapshot* it was grounded in, and detect divergence later.

Never store structure in the event log. Store the *event* "structure snapshot X was built from
commit Y by provider Z"; store the snapshot itself in the derived tier.
