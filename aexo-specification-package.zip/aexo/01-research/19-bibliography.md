# 19 — Bibliography and Sources

All sources consulted August 2026. Content in this package is paraphrased; no source text is
reproduced.

## Primary architectural sources

**[ANT-MA]** Martin, L., Cemaj, G., Cohen, M. — *Scaling Managed Agents: Decoupling the brain from
the hands.* Anthropic Engineering, 8 April 2026.
https://www.anthropic.com/engineering/managed-agents
Session as an append-only log outside the harness and outside the context window; `getEvents()`
positional slicing; harness and sandbox as replaceable cattle; credential isolation from the
sandbox; TTFT improvements from decoupling.

**[ANT-CE]** Anthropic — *Effective context engineering for AI agents* and the context-engineering
cookbook (memory, compaction, tool clearing).
https://www.anthropic.com/engineering/effective-context-engineering-for-ai-agents ·
https://platform.claude.com/cookbook/tool-use-context-engineering-context-engineering-tools

**[5-pm]** Malo, R. C., Qiu, T. — *PROJECTMEM: A Local-First, Event-Sourced Memory and Judgment
Layer for AI Coding Agents.* arXiv:2606.12329, June 2026. https://arxiv.org/abs/2606.12329
The closest prior art. Memory-as-Governance; typed event log; deterministic projection; pre-action
gate; cross-project promotion; secret redaction; MCP hardening patterns.

**[20]** Vasilopoulos, A. — *Codified context: Infrastructure for AI agents in a complex codebase.*
arXiv:2602.20478, 2026.

**[ESAA]** dos Santos Filho, E. B. — *ESAA: Event Sourcing for Autonomous Agents in LLM-Based
Software Engineering.* arXiv:2602.23193, 2026.

## Agent memory systems

**[7]** Packer, C. et al. — *MemGPT: Towards LLMs as Operating Systems.* arXiv:2310.08560.
**[4]** Chhikara, P. et al. — *Mem0: Building Production-Ready AI Agents with Scalable Long-Term
Memory.* arXiv:2504.19413.
**[16]** Rasmussen, P., Paliychuk, P., Beauvais, T., Ryan, J., Chalef, D. — *Zep: A Temporal
Knowledge Graph Architecture for Agent Memory.* arXiv:2501.13956.
**[24]** Xu, W. et al. — *A-MEM: Agentic Memory for LLM Agents.* arXiv:2502.12110.
**[1]** Abtahi, S. M. et al. — *Memanto: Typed Semantic Memory with Information-Theoretic
Retrieval for Long-Horizon Agents.* arXiv:2604.22085.
**[22]** Wang, S. et al. — *MemMachine: A Ground-Truth-Preserving Memory System.* arXiv:2604.04853.
**[14]** Park, J. S. et al. — *Generative Agents.* UIST 2023; arXiv:2304.03442.
**[25]** Zhong, W. et al. — *MemoryBank.* AAAI 2024; arXiv:2305.10250.
**[19]** Sumers, T. R., Yao, S., Narasimhan, K., Griffiths, T. L. — *Cognitive Architectures for
Language Agents.* arXiv:2309.02427.
**[10]** Li, Z. et al. — *MemCog: From Memory-as-Tool to Memory-as-Cognition.* arXiv:2605.28046.

## Learning from failure and guardrails

**[17]** Shinn, N. et al. — *Reflexion.* NeurIPS 2023; arXiv:2303.11366.
**[26]** Zhu, K. et al. — *Where LLM Agents Fail and How They Can Learn from Failures.*
arXiv:2509.25370.
**[6]** Ehsani, R. et al. — *Where Do AI Coding Agents Fail? An Empirical Study of Failed Agentic
Pull Requests in GitHub.* arXiv:2601.15195.
**[11]** Luo, W. et al. — *AGrail: A Lifelong Agent Guardrail.* arXiv:2502.11448.
**[12]** Mou, Y. et al. — *ToolSafe.* arXiv:2601.10156.
**[3]** Chennabasappa, S. et al. — *LlamaFirewall.* arXiv:2505.03574.
**[23]** Wu, C., Qu, Z. — *Meta-Policy Reflexion.* arXiv:2509.03990.
**[21]** Wang, H. et al. — *AI Agentic Programming: A Survey.* arXiv:2508.11126.

## Provenance and trust

**[PROV-SURVEY]** *From Agent Traces to Trust: A Survey of Evidence Tracing and Execution
Provenance in LLM Agents.* arXiv:2606.04990, 2026. https://arxiv.org/abs/2606.04990
Establishes the PROV↔agent mapping and identifies SUPPORT/CONTRADICT as the relations PROV
lacks.
**[PROV-AGENT]** *PROV-AGENT: Unified Provenance for Tracking AI Agent Interactions in Agentic
Workflows.* arXiv:2508.02866.
**[W3C-PROV]** W3C — *PROV-DM / PROV-O.* 2013 Recommendation.

## Security

**[MEM-SEC]** *A Survey on the Security of Long-Term Memory in LLM Agents.* arXiv:2604.16548, 2026.
**[MEMSAD]** *MEMSAD: Gradient-Coupled Anomaly Detection for Memory Poisoning in
Retrieval-Augmented Agents.* arXiv:2605.03482.
**[MEMGUARD]** *MemGuard: Preventing Memory Contamination in Long-Term Memory-Augmented LLMs.*
arXiv:2605.28009.
**[AGENTLAB]** *AgentLAB: Benchmarking LLM Agents against Long-Horizon Attacks.* arXiv:2602.16901.
**[OWASP-ASI]** OWASP — *Top 10 for Agentic Applications, 2026.* ASI06 Memory and Context
Poisoning.
**[MCP-SEC]** Hou, X., Zhao, Y., Wang, S., Wang, H. — *Model Context Protocol (MCP): Landscape,
Security Threats, and Future Research Directions.* arXiv:2503.23278.
Industry write-ups consulted for practitioner framing: mem0.ai AI Memory Security best practices;
vectorize.io on AI memory poisoning; christian-schneider.net on persistent memory poisoning.

## Benchmarks and evaluation

**[8]** Hu, Y., Wang, Y., McAuley, J. — *Evaluating Memory in LLM Agents via Incremental Multi-Turn
Interactions* (MemoryAgentBench). arXiv:2507.05257.
**[MEM-BENCH]** LongMemEval (Wu et al., ICLR 2025) and *LongMemEval-V2*, arXiv:2605.12493;
LoCoMo (Maharana et al., 2024); BEAM; MemoryArena, arXiv:2602.16313; RealMem; AMA-Bench,
arXiv:2602.22769; MemDelta (controlled baselines and hidden confounds), arXiv:2606.29914.
Independent benchmarking context: benchd.ai; mem0.ai state-of-agent-memory 2026 survey.
**[LOCA]** *LOCA-bench: Benchmarking Language Agents Under Controllable and Extreme Context
Growth.* arXiv:2602.07962.
**[15]** Pollertlam, N., Kornsuwannawit, W. — *Beyond the Context Window: A Cost-Performance
Analysis of Fact-Based Memory vs. Long-Context LLMs for Persistent Agents.* arXiv:2603.04814.
**[18]** Siddiq, M. L. et al. — *Large Language Models for Software Engineering: A Reproducibility
Crisis.* arXiv:2512.00651.
Terminal-Bench 2.0 and τ²-Bench referenced via arXiv:2607.08716.

## Code intelligence

**[SCIP]** Sourcegraph — *SCIP: a better code indexing format than LSIF.*
https://sourcegraph.com/blog/announcing-scip
**[SCIP-RFC]** *RFC 001 — Remove SCIP Dependency and Implement Tree-sitter Based File-Incremental
Indexing.* github.com/orgs/sheeptechnologies/discussions/4
**[CI-2026]** West, A. — *Code Intelligence & Code-Graph Indexing for AI Agents* (survey, June
2026). https://anthonywest.co.uk/research/code-intelligence-indexing-2026-openai
**[LOCAGENT]** *LocAgent: Graph-Guided LLM Agents for Code Localization.* arXiv:2503.09089.
**[REPOGRAPH]** Ouyang, S. et al. — *RepoGraph.* ICLR 2025.
GitLab code intelligence docs (LSIF/SCIP conversion); Sourcegraph SCIP indexer documentation.

## Protocols, harnesses and observability

**[MCP-2026]** Model Context Protocol — *The 2026-07-28 Specification* and changelog.
https://blog.modelcontextprotocol.io/posts/2026-07-28/ ·
https://modelcontextprotocol.io/specification/2026-07-28/changelog
SEP-2322 (Multi Round-Trip Requests), SEP-2260 (server requests bound to client requests),
SEP-2663 (Tasks extension).
**[MCP-TIMELINE]** Konishi, H. — *MCP Specification Version Timeline.*
https://hidekazu-konishi.com/entry/mcp_specification_version_timeline.html
**[CC-HOOKS]** Claude Code hooks references consulted:
https://www.morphllm.com/claude-code-hooks ·
https://hidekazu-konishi.com/entry/claude_code_hooks_complete_guide.html ·
https://blakecrosley.com/blog/claude-code-hooks-explained · https://pushary.com/blog/claude-code-hooks-explained
**[CODEX-HOOKS]** Sakasegawa — *Harness Engineering Best Practices 2026.*
https://nyosegawa.com/en/posts/harness-engineering-best-practices-2026/
**[OTEL-GENAI]** OpenTelemetry GenAI semantic conventions; practitioner analyses:
https://dev.to/azena-ai/opentelemetrys-genai-semantic-conventions-are-not-stable-yet-heres-what-actually-shipped-in-2026-3mke ·
https://veraexmachina.com/tech/opentelemetry-genai-agent-observability-production/ ·
https://greptime.com/blogs/2026-05-09-opentelemetry-genai-semantic-conventions

## Token economics

Anthropic prompt caching documentation (5-minute and 1-hour TTLs; write multipliers; cached reads
excluded from ITPM): https://platform.claude.com/docs/en/build-with-claude/prompt-caching
Google Cloud Vertex AI Claude prompt-caching documentation (write multipliers).
Amazon Bedrock 1-hour prompt-caching GA announcement, 26 January 2026.
Cache TTL regression analysis: anthropics/claude-code issue #46829;
https://brandonwie.dev/posts/anthropic-prompt-cache-ttl ;
https://www.keepmyprompts.com/en/blog/claude-cache-ttl-cut-2026-reclaim-api-bill
Cross-provider cache cost comparison: https://ofox.ai/blog/prompt-caching-cost-math-anthropic-vs-openai-2026/ ;
https://www.respan.ai/articles/claude-prompt-caching

## Compliance

EU AI Act phasing and the May 2026 AI Omnibus timeline change:
https://www.brightdefense.com/news/eu-ai-act-pushes-iso-iec-42001-into-ai-compliance-planning/ ;
https://truvocyber.com/blog/iso-42001-and-eu-ai-act ; https://www.accorian.com/iso-42001-vs-the-eu-ai-act/
ISO/IEC 42001:2023 and its mapping to AI Act articles; SOC 2 / ISO 27001 procurement context:
https://www.vanta.com/collection/iso-42001/iso-42001-and-eu-ai-act ;
https://omnithium.ai/blog/ai-agent-compliance-soc2-iso-eu-ai-act.html

## Platform and framework selection

Python framework comparisons (FastAPI, Litestar/msgspec, BlackSheep, Granian, Uvicorn):
https://uvik.net/blog/python-api-framework/ ; https://byteiota.com/litestar-vs-fastapi-python-speed-test-2026-analysis/ ;
https://markaicode.com/alternatives/fastapi-alternatives/
Embedded storage landscape (SQLite, DuckDB, RocksDB, LanceDB, Kùzu, Turso/Limbo):
https://kestra.io/blogs/embedded-databases ; https://1bench.dev/databases/embedded
