# 12 — Prior Art Capability Matrix

Design capabilities, not head-to-head task accuracy — these systems are not measured on a common
benchmark. Entries reflect published descriptions as of August 2026.
Legend: ● full · ◐ partial · ○ none · — not applicable

| Capability | MemGPT/Letta | Mem0 | Zep | A-MEM | Reflexion | AGrail | LlamaFirewall | Codified Ctx | projectmem | OpenWolf | **AEXO (target)** |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Local-first / offline | ◐ | ○ | ○ | ◐ | ● | ◐ | ● | ● | ● | ● | **●** |
| Plain-text, no vector DB required | ○ | ○ | ○ | ● | ● | ○ | — | ● | ● | ● | **●** |
| Append-only immutable log | ○ | ○ | ◐ | ○ | ◐ | ○ | ○ | ○ | ● | ○ | **●** |
| Tamper-evident (hash chain / signing) | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| Deterministic projection | ○ | ○ | ○ | ○ | ○ | ○ | — | ◐ | ● | ◐ | **●** |
| Pre-action judgement gate | ○ | ○ | ○ | ○ | ◐ | ● | ● | ○ | ● | ◐ | **●** |
| Gate is deterministic (no model call) | — | — | — | — | ○ | ○ | ○ | — | ● | ● | **●** |
| Typed experience schema | ○ | ◐ | ◐ | ◐ | ○ | ○ | ○ | ◐ | ● | ○ | **●** |
| Provenance / evidence graph | ○ | ○ | ◐ | ○ | ○ | ○ | ○ | ○ | ◐ | ○ | **●** |
| Support **and** contradiction edges | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| Contradiction detection & resolution | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| Scoped claims (component/env/version) | ○ | ◐ | ◐ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| Bitemporal (valid vs transaction time) | ○ | ○ | ◐ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| Verification-driven expiry | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| Trust lattice / taint propagation | ○ | ○ | ○ | ○ | ○ | ○ | ◐ | ○ | ○ | ○ | **●** |
| Provenance-depth limit on self-derived belief | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| Query-aware (not recency-only) projection | ◐ | ● | ● | ● | ○ | — | — | ◐ | ◐ | ○ | **●** |
| Token-budgeted context assembly | ◐ | ◐ | ◐ | ○ | ○ | — | — | ◐ | ● | ● | **●** |
| Cache-aware assembly & net accounting | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| Delta injection (diff since last seen) | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| Evidence receipts + agent dispute channel | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| MCP-native | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ● | ● | ○ | **●** |
| Multi-harness capture | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ◐ | ◐ | ○ | **●** |
| OTel GenAI ingest | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| Observability completeness measured | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| Shell / non-tool activity capture | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ◐ | ○ | **●** |
| Multi-agent / subagent identity model | ○ | ◐ | ◐ | ○ | ○ | ○ | ○ | ○ | ○ | ◐ | **●** |
| Cross-project / cross-repo memory | ○ | ◐ | ◐ | ○ | ○ | ○ | ○ | ○ | ● | ○ | **●** |
| Team sync without central server | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ◐ | ○ | ○ | **●** |
| Secret redaction at write path | ○ | ◐ | ◐ | ○ | ○ | ○ | ◐ | ○ | ● | ○ | **●** |
| Crypto-shred erasure on immutable log | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| Multi-tenant / RBAC / SSO | ○ | ● | ● | ○ | ○ | ○ | ○ | ○ | ○ | ○ | **●** |
| Controlled effectiveness benchmark | ○ | ◐ | ◐ | ◐ | ● | ● | ● | ○ | ○ | ○ | **●** |

## Reading the matrix

Three columns of the AEXO row are **uncontested** — no surveyed system has them at all:

1. Support/contradiction edges with a resolution engine
2. Verification-driven expiry
3. Cache-aware net accounting and delta injection

Three more are contested by exactly one system each and are where the real work is:

4. Deterministic pre-action gate (projectmem has it; AEXO must be at least as good and
   content-aware rather than path-aware)
5. Trust lattice (LlamaFirewall partially, for a different threat)
6. Controlled effectiveness benchmark (the guardrail thread has this discipline; the memory
   thread does not)

Everything else in the AEXO column is table stakes that some system already demonstrates. Those
are integration and engineering tasks, not research risk.
