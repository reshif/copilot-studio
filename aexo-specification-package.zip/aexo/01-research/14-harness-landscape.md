# 14 — Harness, Protocol and Capture Landscape

The single biggest structural weakness of first-generation memory layers is that capture is
bound to one harness's tool names. This file surveys every available capture surface as of
August 2026 and defines AEXO's coverage strategy.

## 14.1 Claude Code hooks

The richest surface available. As of the August 2026 reference, the hooks system documents
**31 events**, falling into three cadences:

- **Per session:** `SessionStart` (matchers include startup / resume / clear / compact),
  `SessionEnd`
- **Per turn:** `UserPromptSubmit`, `Stop`, `StopFailure`
- **Per tool call:** `PreToolUse`, `PostToolUse`, plus batch and failure variants

Plus condition-triggered events for compaction, subagents, permissions, config changes, tasks,
worktrees, elicitation and MCP interactions.

Mechanics that matter for AEXO:

- Hooks read JSON on stdin and answer via exit code or JSON on stdout.
- **Exit 0 allows; exit 2 blocks** on blocking-capable events. Exit 1 blocks nothing — the
  classic footgun, and a likely cause of silent memory failure in naive implementations.
- `PreToolUse` fires **before** the permission-mode check, so a `permissionDecision: "deny"`
  blocks even under permission-bypass modes. Hooks can tighten policy beyond settings; they can
  never loosen it.
- Matchers: `*`/empty matches all; plain names or `|`-lists are exact; anything else is treated
  as a regex. MCP tools appear as `mcp__<server>__<tool>`, so `mcp__.*` captures all MCP traffic
  — a large coverage win over tool-name allowlists.
- Context can be injected via `hookSpecificOutput.additionalContext`.

**AEXO strategy:** register on the five load-bearing events (`SessionStart`, `UserPromptSubmit`,
`PreToolUse`, `PostToolUse`, `Stop`) plus `PreCompact`, `SubagentStop`, `SessionEnd`, and the MCP
matcher. Every hook must return in single-digit milliseconds — see §14.6.

## 14.2 OpenAI Codex hooks

An experimental hooks system arrived in the Rust CLI in March 2026, covering the same five
lifecycle events (`SessionStart`, `PreToolUse`, `PostToolUse`, `UserPromptSubmit`, `Stop`),
configured in `~/.codex/hooks.json` or `<repo>/.codex/hooks.json` behind a config flag. Schema is
close to Claude Code's, with matcher filtering, context feedback via
`hookSpecificOutput.additionalContext`, and blocking via `permissionDecision`.

**The critical difference:** `Pre/PostToolUse` targets **only the Bash tool** (the schema pins the
tool name). Because Codex performs file operations through Bash, practical coverage is comparable
— but AEXO cannot match `Write`/`Edit` directly and must **parse shell command lines** to derive
file operations.

**AEXO consequence:** a shell-command parser is not an optional enhancement; it is required for
Codex parity. It also happens to close the largest coverage gap in Claude Code (`cat`, `sed`,
`rg`, compilers, scripts).

## 14.3 Model Context Protocol

The current specification is **2026-07-28**, the largest revision since launch.

What changed that AEXO must build against:

- **Stateless core.** The protocol no longer assumes a persistent connection; it scales on
  ordinary HTTP infrastructure. Server-side session affinity is no longer required.
- **Per-request protocol version** and a new `server/discover` RPC replace the handshake.
- **Multi Round-Trip Requests (MRTR)** replace server-initiated requests. A server returns an
  `InputRequiredResult` (`resultType: "input_required"`) carrying `inputRequests`; the client
  retries the original request with `inputResponses`. All results now carry a required
  `resultType` field, and results from older servers that omit it are treated as `complete`.
- **Server-initiated requests may only be issued while actively processing a client request.**
  Previously a recommendation, now a requirement — so a user is never prompted out of nowhere.
- **Extensions framework**: MCP Apps (final since January 2026), Tasks (moved out of core into an
  extension; polling via `tasks/get` replaces the blocking `tasks/result`), and Enterprise
  Managed Authorization.
- **Deprecated:** Roots, Sampling, Logging — remaining during a twelve-month window, with new
  implementations advised toward tool parameters, direct provider APIs, and stderr/OpenTelemetry
  respectively.
- **Removed:** SSE stream resumability and message redelivery from Streamable HTTP.
- **Elicitation safety:** form mode must not be used for credentials; URL mode is required for
  those.
- A formal **feature lifecycle and deprecation policy** with a twelve-month minimum window.

**AEXO consequences:**
1. The MCP server is **stateless** — every tool call carries the identifiers it needs. This is
   fortunate; it matches the event-sourced design exactly.
2. Do **not** build on Sampling. AEXO's reflection jobs call a provider API directly.
3. Do **not** build on Logging. Emit OpenTelemetry.
4. Use MRTR for the human-approval flow when promoting a Claim to a Policy.
5. Pin the negotiated version and honour the deprecation policy; expose the version in
   `aexo doctor`.

## 14.4 OpenTelemetry GenAI conventions — the harness-agnostic capture path

This is AEXO's strategic bet for coverage.

State of play: as of mid-2026 every `gen_ai.*` attribute, span, metric and event carries
"Development" stability — **none is Stable**, despite widespread claims otherwise. In the v1.42.0
release (12 June 2026) the GenAI conventions moved out of the main semantic-conventions
repository into a dedicated GenAI repository; this is an organisational change for release
cadence, not a graduation. OpenTelemetry itself graduated from the CNCF in May 2026.

What the conventions model, and why it matters:

- The whole agent execution is a **span tree**, not isolated LLM calls:
  `invoke_agent` → (`chat` | `execute_tool`)*
- `gen_ai.operation.name` spans the lifecycle: `create_agent`, `invoke_agent`, `invoke_workflow`,
  `execute_tool`, `retrieval`, `plan`, plus **memory operations**.
- Load-bearing attributes include `gen_ai.request.model`, `gen_ai.usage.input_tokens`,
  `gen_ai.usage.output_tokens`, `gen_ai.response.finish_reasons`.
- **MCP conventions moved into the same GenAI repository**, so MCP tool calls share the trace
  vocabulary of the agent that issues them.
- Coding agents including VS Code Copilot, OpenAI Codex and Claude Code (beta) already emit
  GenAI traces.

**Why this is the strategic bet:** an OTel ingest endpoint makes AEXO a capture target for *any*
harness that emits the conventions, present or future, without writing an adapter. It also makes
AEXO exportable into the customer's existing observability stack rather than being another silo.

**The risk, and the mitigation:** the conventions are pre-stable and names can change between
versions. AEXO pins a convention version, normalises on ingest into its own canonical event
schema, and keeps a translation table per pinned version. A collector-side normaliser can map
OpenInference and OpenLLMetry attribute profiles onto the standard names before they reach AEXO.

## 14.5 Other capture surfaces

| Surface | Mechanism | Coverage gained | Cost |
|---|---|---|---|
| Git hooks | `post-commit`, `post-merge`, `pre-commit`, plus reflog scan | Commits, merges, reverts, force-pushes (strong failed-approach signal) | Trivial |
| Filesystem watcher | `fanotify` (Linux), `FSEvents` (macOS), `ReadDirectoryChangesW` (Windows) | Every mutation regardless of who made it — the ground truth for reconciliation | Low; needs debouncing |
| Shell instrumentation | Wrapper on `PROMPT_COMMAND`/`preexec`, or a PTY shim | Interactive human commands and agent Bash calls | Medium; opt-in |
| Test / CI | JUnit XML, TAP, `cargo test --format json`, CI webhooks | Verification evidence — the highest-value evidence class | Low |
| LSP client | AEXO speaks LSP to a running server | Precise definitions/references on demand | Medium |
| SCIP / LSIF index | Ingest generated index files | Cross-repository precision | Low when index exists |
| Issue tracker / PR | Read-only API adapters | Decisions, human rationale, ADRs | Medium; enterprise phase |
| Code review | PR comment ingestion | Human judgement as trusted evidence | Medium |

## 14.6 The latency budget — a hard constraint

Hooks sit in the agent's critical path. A `PreToolUse` hook runs before **every** tool call.

Observed reality: a Python process with imports typically cold-starts in 150–400 ms. At 300 tool
calls per session that is 45–120 seconds of pure added latency, per session, per agent. This is
unacceptable and is the reason harness-integrated memory layers get uninstalled.

**Budget (hard requirements):**

| Path | p50 | p99 | Hard ceiling |
|---|---|---|---|
| `PreToolUse` gate decision | ≤ 3 ms | ≤ 10 ms | 25 ms, then fail open |
| `PostToolUse` capture | ≤ 2 ms | ≤ 8 ms | 20 ms, then drop to async queue |
| `SessionStart` bundle assembly | ≤ 120 ms | ≤ 400 ms | 1,000 ms, then ship a minimal bundle |
| MCP tool query | ≤ 50 ms | ≤ 200 ms | 2,000 ms |

**Architectural consequence:** the hook binary is a **statically linked Rust client** that writes
to a Unix domain socket held open by a resident daemon, or falls back to an append to a local
queue file. It performs no parsing, no I/O beyond the socket, no dynamic linking, and no
interpreter start. The Python control plane never sits in the hook path.

This single decision — Rust for the capture path — is the difference between a system people keep
installed and one they disable in week three.

## 14.7 Coverage strategy summary

```
             ┌─── Claude Code hooks (31 events) ─────┐
             ├─── Codex hooks (5, Bash-shaped) ──────┤
             ├─── MCP server (2026-07-28, stateless) ┤
             ├─── OTel GenAI ingest (any harness) ───┤
             ├─── Shell instrumentation ─────────────┼──►  Canonical Activity Event
             ├─── Filesystem watcher ────────────────┤          (normalised)
             ├─── Git hooks + reflog ────────────────┤
             ├─── Test / CI results ─────────────────┤
             └─── LSP / SCIP structure ──────────────┘
                                │
                                ▼
                   Reconciliation loop compares observed
                   events against filesystem + git ground
                   truth and emits `coverage_gap` events
                                │
                                ▼
                   Observability Completeness (an SLO)
```

The reconciliation loop is what makes this honest. AEXO does not claim complete observability; it
**measures its own incompleteness** and reports it. That number is injected into the agent's
context so the agent knows how much to trust what it is told.
