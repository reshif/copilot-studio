# 18 — Open Questions and Research Risks

Questions the research did not settle. Each carries an owner, a decision deadline, and the
evidence that would close it. None blocks Phase 0.

## Q1 — What is the actual repeat-failure rate in real projects?
Everything in the value proposition rests on F2 being common. The literature establishes the
*pattern* qualitatively (failed agentic PRs showing repeated application of the same fix without
evolution) but gives no base rate.
**Closes with:** instrumentation-only deployment across ≥10 repositories for 4 weeks, counting
Episodes whose remedy matches a prior failed remedy.
**Owner:** Research lead. **Deadline:** end of Phase 0.
**If the rate is low:** the Gate is de-prioritised and the product's centre of gravity moves to
cache-stable context assembly and the audit/provenance value.

## Q2 — Does delta injection actually beat plain re-reading in practice?
The economics say yes. But a diff without surrounding context may cost the agent more reasoning
turns than it saves in tokens — a bad trade under the lifetime multiplier.
**Closes with:** A/B on the eval corpus measuring turns-to-resolution, not just tokens.
**Owner:** Projection lead. **Deadline:** Phase 3 mid-point.

## Q3 — How much does structure-query substitution really save?
The published order-of-magnitude figure comes from a single 2026 study on a specific corpus with
a specific graph design. Our corpus and design differ.
**Closes with:** replication on our corpus before the number is used in any external claim.
**Owner:** Structure lead. **Deadline:** Phase 3.

## Q4 — What is the right confidence function?
Confidence must be deterministic (P3). Candidate inputs: count of supporting evidence, evidence
independence, verification recency, contradiction pressure, source trust, scope-resolution
health. The *functional form* is unresolved. Options: a weighted log-odds sum; a Dempster–Shafer
combination; a simple monotone lattice with named bands.
**Bias:** start with named bands (`unverified` / `supported` / `verified` / `authoritative`) plus
a numeric score used only for ranking, never for gating. Bands are explainable; a float is not.
**Closes with:** an ablation on the eval corpus measuring how often each variant surfaces the
correct Claim in the top-k projection.
**Owner:** Judgement lead. **Deadline:** Phase 2.

## Q5 — How aggressive should contradiction detection be?
Two Claims with overlapping scope and opposite polarity are a clear contradiction. But most real
conflicts are *scope-qualification* problems ("never retry 504" vs "provider A requires 504
retry" vs "retries allowed only after durable queue insertion") — three statements that are
mutually compatible once scoped properly. Over-eager detection produces alert fatigue;
under-eager produces a pile of advice.
**Closes with:** a hand-labelled contradiction corpus of ≥200 Claim pairs drawn from real
projects, scored for precision and recall.
**Owner:** Judgement lead. **Deadline:** Phase 2.

## Q6 — Can we make CRDT-style merge work for team memory over plain git?
Append-only logs with content-addressed IDs and hybrid logical clocks *should* merge
deterministically. The unknown is whether derived state (Claims, contradiction resolutions)
converges usefully after a merge, or whether it needs a rebase-and-recompute step.
**Bias:** merge is over the *event log only*; all derived state is recomputed post-merge. Slower,
obviously correct.
**Closes with:** a simulation harness with concurrent divergent branches.
**Owner:** Storage lead. **Deadline:** Phase 5.

## Q7 — How stable are the OpenTelemetry GenAI conventions really?
Every `gen_ai.*` attribute is at Development stability with no 1.0, and names can change between
versions. AEXO is betting significant capture strategy on them.
**Mitigation already chosen:** pin, normalise on ingest, keep a per-version translation table.
**Residual risk:** a rename storm costs a sprint. Accepted.
**Owner:** Capture lead. **Review:** quarterly.

## Q8 — What happens when the model provider ships this?
Compaction, memory tools and durable session logs are already platform primitives, and the
Managed Agents session interface is very close to AEXO's event layer in shape.
**Position:** cross-vendor, cross-harness, and the provenance/audit layer are the durable
differentiators. Vendor-native memory is single-vendor by construction and does not answer "why
do we believe this."
**Owner:** Product. **Review:** continuous.

## Q9 — Is the pre-action gate's false-positive rate tolerable?
A deterministic check can flag a file whose past failure is no longer relevant to a superficially
similar but valid change. Prior art makes its warning advisory for exactly this reason.
**Closes with:** measuring warning-acceptance rate in shadow mode before the Gate is ever
allowed to be non-advisory.
**Owner:** Judgement lead. **Deadline:** Phase 2.
**Design hedge:** warning classes with acceptance below threshold auto-suppress (Rule R4).

## Q10 — Rust for capture: does the team have it?
The latency budget makes a compiled hook client close to mandatory. If Rust expertise is absent,
the fallback is Go (slightly larger binaries, adequate start-up) or a resident daemon with a
shell-only client (`nc`-style socket write), which is the cheapest possible fallback.
**Closes with:** a Phase 0 spike measuring hook latency in all three.
**Owner:** Engineering lead. **Deadline:** week 2.

## Q11 — Where does the LLM legitimately belong?
Settled that it may not be authoritative (P3). Unsettled: whether it should be in the loop at all
for Episode boundary detection, Claim candidate extraction, and contradiction *triage*.
**Bias:** yes for all three, as candidate generators whose output is always reviewable and always
marked. No for confidence, gating, and promotion.
**Owner:** Architecture. **Deadline:** Phase 1.

## Q12 — What is the minimum viable eval corpus?
The category has no accepted benchmark. Building one is a genuine research contribution and a
genuine cost.
**Bias:** start with ~30 seeded repositories carrying injected, previously-failed fixes, plus
replay of real traces from design partners. Publish the harness, not just the score, because
independent benchmarking has already shown large divergence between vendor-reported and
reproduced numbers in this category.
**Owner:** Research lead. **Deadline:** Phase 0 design, Phase 4 delivery.
