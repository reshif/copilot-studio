# 17 — Standards, Interoperability and Compliance

## 17.1 Standards AEXO conforms to

| Standard | Version / status | How AEXO uses it |
|---|---|---|
| **Model Context Protocol** | 2026-07-28 (stateless core, Extensions framework) | Primary agent-facing interface. Stateless server; MRTR for approvals; Tasks extension for long jobs |
| **OpenTelemetry GenAI semantic conventions** | Development stability; own repo since v1.42.0 (June 2026) | Capture ingest **and** export. Pinned version with a normalisation table |
| **W3C PROV-DM / PROV-O** | Recommendation | Base vocabulary for the Evidence Graph (Entity/Activity/Agent; `used`, `wasGeneratedBy`, `wasDerivedFrom`, `wasRevisionOf`, `wasAttributedTo`) |
| **PROV extensions for agents** | PROV-AGENT and the 2026 agent-provenance survey | The extension points: `SUPPORTS`, `CONTRADICTS` — relations PROV has no vocabulary for |
| **OpenAPI 3.1** | Stable | REST surface |
| **JSON Schema 2020-12** | Stable | Event and Claim schemas; MCP tool parameter schemas |
| **SCIP** | Sourcegraph, active | Structural index ingest |
| **Language Server Protocol** | 3.17+ | Live structure queries |
| **RFC 8785 (JCS)** | Stable | Canonical JSON for hashing — deterministic serialisation before the chain hash |
| **RFC 3161 / Sigstore** | Stable | Optional timestamping and signing of log anchors |
| **SLSA provenance** | v1.0 | Format alignment for build/CI evidence attestations |
| **CycloneDX / SPDX** | Stable | Dependency scope resolution for cross-project Claims |
| **SemVer 2.0** | Stable | Dependency version ranges in Claim scopes |

### The PROV mapping, concretely

The 2026 agent-provenance survey establishes that PROV covers most of what agent systems need
and is missing exactly two things. AEXO's graph is therefore:

| AEXO relation | PROV equivalent | Notes |
|---|---|---|
| `Evidence` | `prov:Entity` | Tool outputs, test results, commits, passages, human statements |
| `Episode`, `Action` | `prov:Activity` | Bounded work; individual operations |
| `Agent`, `Human`, `Job` | `prov:Agent` | Actors |
| `DERIVED_FROM` | `prov:wasDerivedFrom` | Claim ← Evidence, Episode ← Actions |
| `GENERATED_BY` | `prov:wasGeneratedBy` | Evidence ← Action |
| `USED` | `prov:used` | Action → Evidence consumed |
| `REVISION_OF` | `prov:wasRevisionOf` | Claim v2 ← Claim v1 |
| `ATTRIBUTED_TO` | `prov:wasAttributedTo` | Claim → Actor |
| `SUPPORTS` | **none** | Evidence → Claim. Central to attribution; PROV has no justification semantics |
| `CONTRADICTS` | **none** | Evidence/Claim → Claim. Requires semantic comparison, not bookkeeping |
| `VERIFIES` | **none** | Verification run → Claim; refreshes validity |
| `SUPERSEDES` | partially `wasRevisionOf` | Scoped replacement, distinct from revision |

Being PROV-anchored rather than bespoke is a material enterprise advantage: an auditor's existing
provenance tooling can consume an AEXO export.

## 17.2 The compliance surface

AEXO is a developer tool, not a high-risk AI system. But it is bought by organisations that must
answer AI governance questions, and it *produces* exactly the artefacts those questions demand.
That is a positioning opportunity, not just an obligation.

### EU AI Act
Obligations phase in. Prohibited practices and AI literacy applied from February 2025; GPAI
obligations from August 2025; transparency rules from August 2026. Following the AI Omnibus
political agreement of 7 May 2026, certain high-risk system obligations moved to 2 December 2027,
with AI embedded in regulated products such as lifts and toys applying from 2 August 2028.
Penalties reach up to €35 million or 7% of global annual turnover for prohibited practices.

**AEXO's exposure:** almost certainly **limited risk** as a coding-assistant support tool. Legal
counsel confirms per deployment; AEXO does not self-classify for customers.

**AEXO's opportunity:** the Act's operational articles — risk management (9), data governance
(10), technical documentation (11), **record-keeping (12)**, transparency (13), human oversight
(14), quality management (17) — are exactly the areas where organisations struggle to produce
evidence, and where audits fail not from bad intent but because evidence is scattered across
silos. An immutable, timestamped, attributable record of every AI-assisted change, with the
reasoning and evidence attached, is a **record-keeping and transparency artefact generated as a
by-product of normal work.** AEXO ships an "AI governance evidence export" for this reason.

### ISO/IEC 42001
The AI management system standard (published December 2023). Not formally recognised as a
harmonised EU AI Act standard as of 2026, so certification is not legal compliance — but it maps
directly onto the seven articles above and is following SOC 2 and ISO 27001 from optional
differentiator to baseline procurement requirement, particularly for AI-native vendors selling
into healthcare, financial services, government and enterprise SaaS.

**AEXO's plan:** ISO 42001 readiness in Phase 5, certification pursued when enterprise pipeline
justifies it. Ship the control mapping document regardless — it accelerates every customer's own
programme and is a sales asset.

### SOC 2 Type II
Baseline. Target: readiness by end of Phase 5, observation window starting at enterprise GA.

### GDPR / data protection
The hard problem: **an append-only log versus the right to erasure.**

AEXO's answer is **crypto-shredding**. Every event's content payload is encrypted under a
per-subject content key. The event envelope (id, chain hash, timestamps, type, relations) stays
in the chain; the payload is opaque ciphertext. Erasure destroys the key. Result:

- The hash chain remains intact and verifiable.
- The payload becomes permanently unrecoverable.
- The audit record still proves *that* an event occurred, its position in history, and its
  relations — without disclosing its content.

This resolves the standard immutability/erasure deadlock and is a genuine differentiator in
enterprise procurement.

Also required: data minimisation at capture (redact by default), configurable retention tiers,
data residency controls, DPA-ready processing records, and an explicit statement that the core
path makes **no network calls** and emits **no telemetry**.

### Sector overlays
- **FedRAMP / air-gapped:** the local-first architecture already satisfies the hard constraint;
  package an offline installer with no external dependency resolution.
- **Financial services:** immutable, attributable audit trail with retention controls maps
  cleanly onto records-retention obligations.
- **Export control / IP:** source code never leaves the boundary in the local deployment; in the
  enterprise deployment, configure whether payloads or only envelopes are centralised.

## 17.3 The reproducibility argument

There is a documented reproducibility problem in LLM-assisted software engineering: it is hard
to establish what was changed, by what, and why. Because AEXO records every AI-assisted change
as an immutable, timestamped, attributable event with the supporting evidence attached, the log
**doubles as an automatic provenance trail** for reproducible, auditable AI-assisted development
— captured as a by-product of normal work and reviewable with standard version-control tools.

This is worth stating plainly in the product narrative. It is a value proposition that survives
model improvement, unlike token savings.

## 17.4 Compliance-driven requirements (feeding the backlog)

| ID | Requirement |
|---|---|
| CR-1 | Every event MUST record actor identity, timestamp (transaction time), and causal parent |
| CR-2 | The log MUST be tamper-evident and independently verifiable offline |
| CR-3 | Content payloads MUST be individually encryptable and individually destroyable |
| CR-4 | Retention policy MUST be configurable per event class and per tenant |
| CR-5 | An export MUST exist producing PROV-O and a human-readable governance report |
| CR-6 | The core path MUST make no network calls and emit no telemetry by default |
| CR-7 | Every automated decision affecting agent behaviour MUST be explainable to a named rule and its evidence |
| CR-8 | Human overrides MUST be recorded with actor and reason |
| CR-9 | Data residency MUST be configurable; payloads MUST be pinnable to a region |
| CR-10 | An auditor MUST be able to answer "what did the system believe on date D, and why" |
