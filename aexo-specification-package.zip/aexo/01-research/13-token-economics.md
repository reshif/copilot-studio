# 13 — Token Economics: The Model Everyone Gets Wrong

This is the most consequential research artefact in the package. It changes what AEXO builds,
what it measures, and where it is allowed to inject text.

## 13.1 Price primitives (August 2026)

Verified against provider documentation and independent analyses. Multipliers are relative to
the model's base input token price `p`.

| Operation | Rate | Notes |
|---|---|---|
| Standard input | `1.00 p` | — |
| Cache **read** | `~0.10 p` | ~90% discount; matched by OpenAI's current flagships |
| Cache **write**, short TTL (5 min) | `1.25 p` | Default TTL |
| Cache **write**, extended TTL (1 hour) | `2.00 p` | Available on Claude API, Bedrock, Vertex for current models |
| Cache read against rate limits | **excluded** from input-tokens-per-minute on current models | A throughput multiplier, separate from cost |

Two operational facts that must be designed around:

- **The cache is positional and exact.** Any difference in the prefix — whitespace, reordered
  tool definitions, a string-vs-typed-array system block, a changed digest — invalidates the
  cache from that point onward.
- **TTL is a moving target.** The effective default TTL for at least one major harness changed
  from one hour to five minutes in early March 2026 with no announcement, and reconstructions of
  large call corpora attribute cost increases in the 17–32% range to that change alone. Any
  model of savings that assumes a stable TTL is unsound.

## 13.2 The naive model and why it is wrong

Every first-generation memory layer computes:

```
saving = tokens_of_prevented_read × base_input_price
```

This is wrong in **both directions**, which is why nobody notices.

### It understates savings inside a session

Context is resubmitted on every turn. A chunk of `R` tokens introduced at turn `t` in a session
that runs `T` more turns is written to cache once and read on each subsequent turn:

```
lifetime_cost(R, T) ≈ R × (1.25p)          # one cache write
                    + R × (0.10p × (T−1))  # cache reads thereafter
                    = R × p × (1.25 + 0.10(T−1))
```

| Remaining turns `T` | Effective multiplier | Interpretation |
|---|---|---|
| 1 | 1.25 p | Slightly worse than a plain read |
| 10 | 2.15 p | Twice the naive estimate |
| 30 | 4.15 p | Four times |
| 60 | 7.15 p | Seven times |

**Preventing a 4,000-token read early in a 40-turn session is worth roughly 4,000 × 5.15 =
20,600 token-equivalents, not 4,000.** Naive accounting understates real savings by 2–7× in
long-horizon runs. This is the strongest available argument for the product — and no shipping
system makes it.

### It ignores the cost of the memory layer itself

The same multiplier applies to injected context. A digest of `B` tokens injected at session
start in a `T`-turn session costs:

```
injection_cost(B, T) ≈ B × p × (1.25 + 0.10(T−1))
```

A 1,200-token digest in a 40-turn session costs about **6,300 token-equivalents**, every session.
If it prevents fewer than roughly 1,200 tokens of reads (at the same multiplier), it is
**net negative**. Fixed digests that are not query-relevant routinely fall below this line.

### It ignores cache invalidation, which dominates everything

If AEXO mutates content that sits inside an already-cached prefix of `P` tokens, the next call
re-writes instead of reads:

```
invalidation_cost(P) ≈ P × (1.25p − 0.10p) = 1.15 × P × p
```

**Worked example.** Prefix (system prompt + tools + project instructions + prior turns) is
30,000 tokens. AEXO updates its injected digest once mid-session.

```
invalidation_cost = 1.15 × 30,000 = 34,500 token-equivalents
```

To break even, that single mutation must prevent about **6,700 tokens of re-reads** in a 40-turn
session — or about 34,500 tokens in a single-turn one. A typical duplicate-read prevention saves
2,000–6,000 tokens. **One badly-placed prefix mutation can wipe out an entire session's savings
and then some.**

## 13.3 The corrected model

```
NET_SAVINGS =   Σ  prevented_read_tokens × p × (1.25 + 0.10 × (turns_remaining − 1))
              − Σ  injected_tokens       × p × (1.25 + 0.10 × (turns_remaining − 1))
              − Σ  invalidated_prefix_tokens × 1.15 p
              − Σ  ignored_warning_tokens × p × (1.25 + 0.10 × (turns_remaining − 1))
              − Σ  idle_gap_reheat_tokens × 1.15 p
```

Every term is measurable. The last term captures a subtle case: if a session idles past the
cache TTL, the whole prefix is re-written; AEXO can observe idle gaps and either recommend the
extended TTL or shrink the prefix. That is a saving AEXO can *create* without touching a single
file read.

`turns_remaining` is unknown at injection time. AEXO estimates it from the session's historical
turn-count distribution for that repository and records both the estimate and, post hoc, the
realised value, so reported savings can be restated on truth rather than forecast.

## 13.4 The eight design rules this forces

**R1 — Never mutate an established prefix mid-session.** All within-session injection goes into
the *tail*: as a tool result, or appended to the user turn. Prefix injection is permitted exactly
once, at session start, before the first cacheable write.

**R2 — Order context by volatility.** Within any injected block: immutable identity → stable
policy → slowly-changing structure → volatile session state. This keeps the longest possible
stable prefix even when the block is regenerated.

**R3 — Prefer tools over dumps.** A tool the agent calls when it needs something costs zero
tokens when it is not needed and does not enter the prefix. A digest costs its full lifetime
multiplier whether or not it was relevant. The default posture is a small orientation block plus
rich query tools, not a large digest. This matches the wider consensus that just-in-time
retrieval beats pre-loading on both quality and cost.

**R4 — Warnings must be cheap and rare.** A warning the agent ignores is pure loss at the full
lifetime multiplier. Warn only where the deterministic evidence is strong. Track
warning-acceptance rate and auto-suppress warning classes that fall below threshold.

**R5 — Delta beats denial beats duplication.** Denying a read forces the agent to work blind or
route around AEXO. Duplicating the read pays full cost. Supplying the *diff* since last seen pays
a fraction and preserves recoverability. Delta injection is the default; denial is an off-by-
default policy.

**R6 — Batch, do not drip.** Ten small injections cost ten cache writes plus ten stretches of
reads. One consolidated injection at a natural boundary costs one. Injection points are
constrained to session start, post-compaction, and explicit tool calls.

**R7 — Idle-gap awareness is a feature.** Detect gaps approaching the TTL and surface the
recommendation (extend TTL, or shrink prefix). Report the cost of observed reheats.

**R8 — Never publish a gross savings figure.** Product UI, dashboards and marketing report net
savings with the components broken out. This is Trade Rejection TR5.

## 13.5 What this means for the duplicate-read feature

The OpenWolf review noted that the installation ran in warn-only mode, so the actual
token-saving branch was unreachable — the product's central proposition was not happening. The
economics above say something stronger: **warn-only mode is net negative.** You pay the warning
tokens at the lifetime multiplier and the agent reads anyway.

The three viable modes, in order of expected value:

1. **Delta** (default) — intercept, supply the diff since the agent's last delivered view.
   Positive expected value in almost all cases.
2. **Silent observe** — record, inject nothing, feed the accounting and the eval harness.
   Exactly zero cost. This is the correct default for the first two weeks of any deployment.
3. **Deny** (opt-in, per-path policy) — highest saving, highest risk, requires that the agent
   still has a way to get the content (an explicit "I really need it" tool).

Warn-only exists solely as an experimental mode behind a flag, labelled as costing tokens.

## 13.6 Where the *real* money is

Ranked by expected value per engineering week:

| Lever | Mechanism | Est. impact | Confidence |
|---|---|---|---|
| **Preventing repeat failed fixes** | Gate + failure history | 10–60 minutes of agent time and thousands of tokens per prevented incident; compounding | High (mechanism proven, magnitude unmeasured) |
| **Cache-stable context layout** | R1/R2/R6 discipline | Avoids 1.15 × prefix invalidations; can be 20–30% of a session bill | High |
| **Just-in-time tools over digests** | R3 | Removes the fixed injection tax from every session | High |
| **Delta injection** | R5 | 70–95% of a re-read's tokens | Medium-high |
| **Structure queries replacing file reads** | Code intelligence plane | Published work reports order-of-magnitude token reduction and ~halved tool calls with a tree-sitter graph over MCP | Medium (single study, our corpus differs) |
| **Idle-gap / TTL advice** | R7 | Recovers the 17–32% class of loss from TTL mismatch | Medium |
| **Duplicate-read denial** | Legacy feature | Small, and risky | Low |

The ordering is the product roadmap. Note that the top item saves *outcomes*, not tokens — which
is the entire argument of this package.

## 13.7 Instrumentation requirements

To compute the corrected model, AEXO MUST record per turn:

- `input_tokens`, `output_tokens`, `cache_creation_input_tokens`, `cache_read_input_tokens` as
  reported by the provider (never estimated when the real value is available)
- the cache TTL in force, and any observed change in it
- wall-clock gap since the previous turn (for reheat detection)
- prefix length and a prefix content hash, to detect invalidations AEXO caused
- every token AEXO injected, tagged with its injection point and purpose
- turn index and, at session end, total turns

Estimates are retained alongside measurements and never overwrite them. This discipline is
inherited directly from OpenWolf's token accounting, which was one of its genuinely good parts.
